# Grounded DI OS Demo 010 — Repeatable Shipment Release / Hold Decisions

> A synthetic ten-shipment operational-gating package with configuration-driven RELEASE / HOLD decisions, exact decimal boundaries, multiple-trigger reporting, rule-order independence, audit-linked explanations, and deterministic single-package replay.

## 1. What was tested

Demo 010 tested whether Grounded DI OS could normalize ten structured shipment records, execute a disclosed release configuration, preserve exact decimal boundaries, report every blocking rule, bind each decision to an audit record, remain invariant to rule ordering, and reproduce the same package and verifier output across isolated executions.

## 2. Six-field release model

Each record contains:

- shipment identifier;
- temperature in degrees Celsius;
- seal status;
- count variance percentage;
- document-completion status;
- transit delay in hours.

Temperature and count-variance values are stored as canonical decimal strings and evaluated using exact `Decimal` arithmetic. Binary floating-point arithmetic is not used as proof support.

## 3. Configured rules

The machine-readable configuration applies:

- missing required field → HOLD;
- temperature below 2.0 → HOLD;
- temperature above 8.0 → HOLD;
- seal not intact → HOLD;
- count variance above 1.0 → HOLD;
- documents incomplete → HOLD;
- transit delay above 6 → HOLD;
- no blocking rule → RELEASE.

All required fields, field types, rule types, operators, comparison values, inclusivity rules, actions, and default behavior are loaded directly from `02_release_configuration.json`.

## 4. Ten-shipment result

| Shipment | Decision | Basis |
|---|---|---|
| S-001 | RELEASE | No blocking rule |
| S-002 | HOLD | Temperature above maximum |
| S-003 | HOLD | Temperature below minimum |
| S-004 | HOLD | Seal not intact |
| S-005 | HOLD | Count variance above maximum |
| S-006 | HOLD | Documents incomplete |
| S-007 | RELEASE | Exact upper boundaries pass |
| S-008 | RELEASE | Exact lower temperature boundary passes |
| S-009 | HOLD | Missing transit delay |
| S-010 | HOLD | Five blocking rules |

Totals: **RELEASE 3 · HOLD 7**

## 5. Exact-boundary tests

S-007 demonstrates that temperature `8.0`, count variance `1.0`, and transit delay `6` do not trigger strict greater-than rules.

S-008 demonstrates that temperature `2.0` does not trigger the strict lower-than rule.

`EXACT_BOUNDARY_TESTS: PASS`

## 6. Configuration-binding test

S-007 evaluates to `RELEASE` under the packaged maximum temperature of `8.0`. An in-memory configuration copy changes the maximum to `7.9`; S-007 then evaluates to `HOLD` and triggers the high-temperature rule. No packaged artifact is modified.

`CONFIGURATION_BINDING_TEST: PASS`

## 7. Rule-order independence test

All ten shipments were evaluated under the packaged rule order and an in-memory reversed rule order.

Every final decision remained unchanged, and every triggered-rule set remained unchanged. Stored explanations and audit records preserve the packaged rule order.

`RULE_ORDER_INDEPENDENCE_TEST: PASS`

## 8. Multiple-trigger result

S-010 reports all five applicable blockers:

- temperature above maximum;
- seal not intact;
- count variance above maximum;
- documents incomplete;
- transit delay above maximum.

`MULTIPLE_TRIGGER_TEST: PASS`

## 9. Single-package reproducibility result

The complete seven-file package tree was generated independently in two isolated temporary locations. Every internal file matched byte-for-byte. Two temporary deterministic ZIPs also matched by SHA-256 and byte comparison. One canonical ZIP was retained, and all duplicate temporary artifacts were deleted.

## 10. Verifier replay result

The canonical ZIP was independently extracted twice and verified in two fresh isolated invocations.

- Exit codes: 0 and 0
- Stderr: empty for both runs
- Stdout: byte-identical
- Stdout SHA-256: identical
- Manifest entries verified: 6/6
- CRC errors: 0
- Replay divergence: 0

`FINAL STATUS: PASS - CONFIGURATION_DRIVEN_RELEASE_REPLAY_VERIFIED`

## 11. What Grounded DI OS demonstrated

- canonical shipment normalization;
- configuration-driven release gating;
- exact decimal comparisons;
- strict-boundary handling;
- multiple-trigger reporting;
- rule-order independence;
- audit-linked explanations;
- deterministic single-package generation;
- repeatable verifier output.

## 12. What was not claimed

- No logistics regulation or standard is asserted.
- No shipment is operationally released.
- No product quality or safety conclusion is made.
- No contractual acceptance decision is made.
- No real shipment or sensor data is evaluated.
- No predictive model is used.
- No external or independent verification is claimed.
- The demo certifies configured rule execution, exact boundary handling, multiple-trigger reporting, rule-order independence, decision traceability, artifact integrity, and replay reproducibility only.

## 13. Artifact index

1. `01_canonical_input.json`
2. `02_release_configuration.json`
3. `03_decision_results.json`
4. `04_audit_record.json`
5. `05_manifest.json`
6. `06_verify_demo.py`
7. `README.md`

`05_manifest.json` is intentionally excluded from its own hash ledger to avoid circular self-reference. The containing ZIP SHA-256 binds the manifest.

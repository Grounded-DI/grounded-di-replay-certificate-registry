#!/usr/bin/env python3
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import re
import sys
import zipfile
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any

PACKAGE_FILES = [
    "01_canonical_input.json",
    "02_release_configuration.json",
    "03_decision_results.json",
    "04_audit_record.json",
    "05_manifest.json",
    "06_verify_demo.py",
    "README.md",
]

DECIMAL_PATTERN = re.compile(r"^(?:0|[1-9][0-9]*)\.[0-9]+$")

KNOWN_FIELDS = {
    "shipment_id",
    "temperature_c",
    "seal_intact",
    "count_variance_pct",
    "documents_complete",
    "transit_delay_hr",
}
KNOWN_FIELD_TYPES = {
    "shipment_id": "identifier",
    "temperature_c": "decimal_string",
    "seal_intact": "boolean",
    "count_variance_pct": "decimal_string",
    "documents_complete": "boolean",
    "transit_delay_hr": "integer",
}
KNOWN_ACTIONS = {"RELEASE", "HOLD"}
SUPPORTED_OPERATORS = {"<", ">", "=="}

def fail(message: str) -> None:
    raise RuntimeError(message)

def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))

def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def is_canonical_decimal_string(value: Any) -> bool:
    return isinstance(value, str) and DECIMAL_PATTERN.fullmatch(value) is not None

def to_comparable(value: Any, field_type: str) -> Any:
    if field_type == "decimal_string":
        if not is_canonical_decimal_string(value):
            fail(f"Unknown decimal format: {value!r}")
        try:
            return Decimal(value)
        except InvalidOperation as exc:
            fail(f"Invalid decimal value: {value!r}")
            raise exc
    if field_type == "integer":
        if not isinstance(value, int) or isinstance(value, bool):
            fail(f"Expected integer, received {value!r}")
        return value
    if field_type == "boolean":
        if not isinstance(value, bool):
            fail(f"Expected boolean, received {value!r}")
        return value
    if field_type == "identifier":
        if not isinstance(value, str) or not value:
            fail("Invalid identifier")
        return value
    fail(f"Unknown field type: {field_type}")

def compare_values(observed: Any, comparison_value: Any, operator: str) -> bool:
    if operator == "<":
        return observed < comparison_value
    if operator == ">":
        return observed > comparison_value
    if operator == "==":
        return observed == comparison_value
    fail(f"Unknown operator: {operator}")

def validate_configuration(config: dict[str, Any]) -> None:
    required_fields = config.get("required_fields")
    if not isinstance(required_fields, list) or set(required_fields) != KNOWN_FIELDS:
        fail("Unknown required-field definition")
    if len(required_fields) != len(set(required_fields)):
        fail("Duplicate required field")

    if config.get("field_types") != KNOWN_FIELD_TYPES:
        fail("Unknown field-type definition")

    allowed_actions = config.get("allowed_actions")
    if not isinstance(allowed_actions, list) or set(allowed_actions) != KNOWN_ACTIONS:
        fail("Unknown action set")
    if config.get("default_action") not in allowed_actions:
        fail("Unknown default action")

    rules = config.get("rules")
    if not isinstance(rules, list) or not rules:
        fail("Missing rules")

    seen_rule_ids: set[str] = set()
    missing_rule_count = 0
    seen_comparison_signatures: set[tuple[str, str]] = set()

    for rule in rules:
        rule_id = rule.get("rule_id")
        rule_type = rule.get("rule_type")
        operator = rule.get("operator")
        action = rule.get("action")

        if not isinstance(rule_id, str) or not rule_id or rule_id in seen_rule_ids:
            fail("Missing or duplicate rule ID")
        seen_rule_ids.add(rule_id)

        if action not in allowed_actions:
            fail(f"Unknown action: {action}")

        if rule_type == "missing_required":
            missing_rule_count += 1
            if operator != "MISSING":
                fail("Unknown missing-field operator")
            if rule.get("threshold_inclusive") is not None:
                fail("Unknown missing-field threshold definition")
            if "field" in rule or "comparison_value" in rule:
                fail("Malformed missing-field rule")
            continue

        if rule_type != "comparison":
            fail(f"Unknown rule type: {rule_type}")

        field = rule.get("field")
        if field not in required_fields:
            fail(f"Unknown field: {field}")
        if operator not in SUPPORTED_OPERATORS:
            fail(f"Unknown operator: {operator}")

        signature = (field, operator)
        if signature in seen_comparison_signatures:
            fail(f"Duplicate comparison rule: {signature}")
        seen_comparison_signatures.add(signature)

        if "comparison_value" not in rule:
            fail("Missing comparison value")

        threshold_inclusive = rule.get("threshold_inclusive")
        if operator in {"<", ">"} and threshold_inclusive is not False:
            fail("Strict threshold must be marked non-inclusive")
        if operator == "==" and threshold_inclusive is not True:
            fail("Equality comparison must be marked inclusive")

        field_type = config["field_types"][field]
        to_comparable(rule["comparison_value"], field_type)

    if missing_rule_count != 1:
        fail("Exactly one missing-required rule is required")

def normalize_record(record: dict[str, Any], config: dict[str, Any]) -> dict[str, Any]:
    required_fields = config["required_fields"]
    if set(record) != set(required_fields):
        fail("Record field set mismatch")

    normalized: dict[str, Any] = {}
    for field in required_fields:
        value = record[field]
        if value == "MISSING":
            normalized[field] = None
            continue
        to_comparable(value, config["field_types"][field])
        normalized[field] = value
    return normalized

def evaluate_record(record: dict[str, Any], config: dict[str, Any]) -> dict[str, Any]:
    validate_configuration(config)
    normalized = normalize_record(record, config)

    evaluations: list[dict[str, Any]] = []
    triggered: list[dict[str, Any]] = []

    for rule in config["rules"]:
        if rule["rule_type"] == "missing_required":
            missing_fields = [
                field for field in config["required_fields"]
                if normalized[field] is None
            ]
            matched = bool(missing_fields)
            evaluation = {
                "action": rule["action"],
                "matched": matched,
                "operator": rule["operator"],
                "rule_id": rule["rule_id"],
                "rule_type": rule["rule_type"],
                "threshold_inclusive": rule["threshold_inclusive"],
            }
            if matched:
                evaluation["missing_fields"] = missing_fields
                for field in missing_fields:
                    triggered.append({
                        "action": rule["action"],
                        "comparison_value": None,
                        "explanation": rule["explanation_template"].format(field=field),
                        "field": field,
                        "observed_value": None,
                        "operator": rule["operator"],
                        "rule_id": rule["rule_id"],
                        "threshold_inclusive": rule["threshold_inclusive"],
                    })
            evaluations.append(evaluation)
            continue

        field = rule["field"]
        observed_raw = normalized[field]
        field_type = config["field_types"][field]
        comparison_comparable = to_comparable(rule["comparison_value"], field_type)

        if observed_raw is None:
            matched = False
        else:
            observed_comparable = to_comparable(observed_raw, field_type)
            matched = compare_values(
                observed_comparable,
                comparison_comparable,
                rule["operator"],
            )

        evaluation = {
            "action": rule["action"],
            "comparison_value": rule["comparison_value"],
            "field": field,
            "matched": matched,
            "observed_value": observed_raw,
            "operator": rule["operator"],
            "rule_id": rule["rule_id"],
            "rule_type": rule["rule_type"],
            "threshold_inclusive": rule["threshold_inclusive"],
        }
        evaluations.append(evaluation)

        if matched:
            triggered.append({
                "action": rule["action"],
                "comparison_value": rule["comparison_value"],
                "explanation": rule["explanation_template"].format(
                    observed=str(observed_raw).lower()
                    if isinstance(observed_raw, bool)
                    else observed_raw,
                    comparison_value=str(rule["comparison_value"]).lower()
                    if isinstance(rule["comparison_value"], bool)
                    else rule["comparison_value"],
                ),
                "field": field,
                "observed_value": observed_raw,
                "operator": rule["operator"],
                "rule_id": rule["rule_id"],
                "threshold_inclusive": rule["threshold_inclusive"],
            })

    triggered_actions = {item["action"] for item in triggered}
    if len(triggered_actions) > 1:
        fail(f"Conflicting actions: {sorted(triggered_actions)}")

    decision = next(iter(triggered_actions)) if triggered_actions else config["default_action"]
    if decision not in config["allowed_actions"]:
        fail(f"Unknown resulting action: {decision}")

    explanation = (
        "No configured blocking rule was triggered."
        if not triggered
        else " | ".join(item["explanation"] for item in triggered)
    )

    transition_chain = [
        "RECEIVED",
        "NORMALIZED",
        "RULES_EVALUATED",
        "DECISION_ASSIGNED",
        "AUDIT_BOUND",
    ]
    if decision == "HOLD":
        transition_chain.append("RELEASE_BLOCKED")

    return {
        "configuration_id": config["configuration_id"],
        "decision": decision,
        "decision_explanation": explanation,
        "normalized_record": normalized,
        "rule_evaluations": evaluations,
        "shipment_id": normalized["shipment_id"],
        "transition_chain": transition_chain,
        "triggered_rules": triggered,
    }

def verify_manifest(package_dir: Path) -> int:
    manifest = load_json(package_dir / "05_manifest.json")
    required_policy = (
        "05_manifest.json is intentionally excluded from its own hash ledger "
        "to avoid circular self-reference. The containing ZIP SHA-256 binds the manifest."
    )
    if manifest.get("self_reference_policy") != required_policy:
        fail("Manifest self-reference policy mismatch")

    entries = manifest.get("entries")
    if not isinstance(entries, list):
        fail("Manifest entries missing")

    expected_names = sorted(
        name for name in PACKAGE_FILES
        if name != "05_manifest.json"
    )
    actual_names = sorted(entry.get("filename") for entry in entries)
    if actual_names != expected_names:
        fail("Manifest filename set mismatch")

    for entry in entries:
        data = (package_dir / entry["filename"]).read_bytes()
        if len(data) != entry["size_bytes"]:
            fail(f"Manifest size mismatch: {entry['filename']}")
        if sha256_bytes(data) != entry["sha256"]:
            fail(f"Manifest hash mismatch: {entry['filename']}")

    return len(entries)

def verify_archive(archive_path: Path, package_dir: Path) -> int:
    with zipfile.ZipFile(archive_path, "r") as archive:
        if archive.namelist() != sorted(PACKAGE_FILES):
            fail("Archive member set or order mismatch")
        if archive.comment != b"":
            fail("Archive comment present")

        crc_errors = 0 if archive.testzip() is None else 1

        for info in archive.infolist():
            if info.is_dir():
                fail("Directory entry present")
            if info.compress_type != zipfile.ZIP_STORED:
                fail("Compression mismatch")
            if info.date_time != (1980, 1, 1, 0, 0, 0):
                fail("Timestamp mismatch")
            if ((info.external_attr >> 16) & 0o777) != 0o644:
                fail("Permission mismatch")
            if info.comment != b"":
                fail("Member comment present")
            if info.extra != b"":
                fail("Extra field present")

            archive_data = archive.read(info.filename)
            if archive_data != (package_dir / info.filename).read_bytes():
                fail(f"Archive/extraction mismatch: {info.filename}")
            if archive_data.startswith(b"\xef\xbb\xbf"):
                fail(f"UTF-8 BOM present: {info.filename}")
            if b"\r" in archive_data:
                fail(f"Non-LF line ending present: {info.filename}")
            if not archive_data.endswith(b"\n"):
                fail(f"Final newline missing: {info.filename}")

        return crc_errors

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--package-dir", required=True)
    parser.add_argument("--archive", required=True)
    args = parser.parse_args()

    package_dir = Path(args.package_dir)
    archive_path = Path(args.archive)

    actual_files = sorted(path.name for path in package_dir.iterdir() if path.is_file())
    if actual_files != sorted(PACKAGE_FILES):
        fail("Extracted package file set mismatch")

    canonical = load_json(package_dir / "01_canonical_input.json")
    config = load_json(package_dir / "02_release_configuration.json")
    stored_results = load_json(package_dir / "03_decision_results.json")
    audit = load_json(package_dir / "04_audit_record.json")

    validate_configuration(config)

    records = canonical.get("records")
    expected_results = canonical.get("expected_results")
    if not isinstance(records, list) or not isinstance(expected_results, list):
        fail("Missing canonical records or expectations")

    canonical_ids = [item.get("shipment_id") for item in records]
    expected_ids = [item.get("shipment_id") for item in expected_results]
    if len(canonical_ids) != len(set(canonical_ids)):
        fail("Duplicate canonical shipment ID")
    if len(expected_ids) != len(set(expected_ids)):
        fail("Duplicate expected shipment ID")
    if set(canonical_ids) != set(expected_ids):
        fail("Canonical and expected shipment-ID sets differ")

    computed_a = [evaluate_record(record, config) for record in records]
    computed_b = [
        evaluate_record(record, copy.deepcopy(config))
        for record in copy.deepcopy(records)
    ]
    if computed_a != computed_b:
        fail("Internal deterministic evaluation mismatch")

    computed_map = {item["shipment_id"]: item for item in computed_a}
    expected_map = {item["shipment_id"]: item for item in expected_results}

    for shipment_id in canonical_ids:
        observed = computed_map[shipment_id]
        expected = expected_map[shipment_id]
        if observed["decision"] != expected["decision"]:
            fail(f"Expected decision mismatch: {shipment_id}")
        observed_rule_ids = [item["rule_id"] for item in observed["triggered_rules"]]
        if observed_rule_ids != expected["triggered_rule_ids"]:
            fail(f"Expected trigger mismatch: {shipment_id}")

    totals = {"HOLD": 0, "RELEASE": 0}
    for result in computed_a:
        totals[result["decision"]] += 1
    if totals != canonical.get("expected_totals"):
        fail("Decision totals mismatch")

    stored = stored_results.get("results")
    if not isinstance(stored, list):
        fail("Stored results missing")
    stored_ids = [item.get("shipment_id") for item in stored]
    if len(stored_ids) != len(set(stored_ids)):
        fail("Duplicate stored-result shipment ID")
    if set(stored_ids) != set(canonical_ids):
        fail("Stored-result shipment-ID set mismatch")
    if stored_results.get("decision_totals") != totals:
        fail("Stored decision totals mismatch")

    stored_map = {item["shipment_id"]: item for item in stored}
    for shipment_id in canonical_ids:
        observed = computed_map[shipment_id]
        saved = stored_map[shipment_id]
        for field in [
            "decision",
            "decision_explanation",
            "normalized_record",
            "triggered_rules",
        ]:
            if saved.get(field) != observed[field]:
                fail(f"Stored {field} mismatch: {shipment_id}")

    events = audit.get("events")
    shipment_audits = audit.get("shipment_audits")
    if audit.get("append_only") is not True:
        fail("Audit append-only flag missing")
    if not isinstance(events, list) or not isinstance(shipment_audits, list):
        fail("Audit data missing")
    if audit.get("event_count") != len(events):
        fail("Audit event count mismatch")

    event_ids = [event.get("event_id") for event in events]
    expected_event_ids = [f"EVT-{index:04d}" for index in range(1, len(events) + 1)]
    if event_ids != expected_event_ids:
        fail("Audit event sequence mismatch")

    audit_ids = [item.get("shipment_id") for item in shipment_audits]
    if len(audit_ids) != len(set(audit_ids)):
        fail("Duplicate audit shipment ID")
    if set(audit_ids) != set(canonical_ids):
        fail("Audit shipment-ID set mismatch")

    audit_map = {item["shipment_id"]: item for item in shipment_audits}
    source_map = {item["shipment_id"]: item for item in records}

    for shipment_id in canonical_ids:
        observed = computed_map[shipment_id]
        audit_item = audit_map[shipment_id]
        checks = {
            "canonical_source_record": source_map[shipment_id],
            "normalized_record": observed["normalized_record"],
            "configuration_id": observed["configuration_id"],
            "rule_evaluations": observed["rule_evaluations"],
            "triggered_rules": observed["triggered_rules"],
            "final_decision": observed["decision"],
            "decision_explanation": observed["decision_explanation"],
            "transition_chain": observed["transition_chain"],
        }
        for field, expected_value in checks.items():
            if audit_item.get(field) != expected_value:
                fail(f"Audit {field} mismatch: {shipment_id}")

        event_stages = [
            event["stage"]
            for event in events
            if event["shipment_id"] == shipment_id
        ]
        if event_stages != observed["transition_chain"]:
            fail(f"Audit transition mismatch: {shipment_id}")

    before_hashes = {
        name: sha256_bytes((package_dir / name).read_bytes())
        for name in PACKAGE_FILES
    }

    # Exact-boundary tests.
    s007 = computed_map["S-007"]
    s008 = computed_map["S-008"]
    if s007["decision"] != "RELEASE" or s008["decision"] != "RELEASE":
        fail("Boundary shipment decision mismatch")
    s007_trigger_ids = {item["rule_id"] for item in s007["triggered_rules"]}
    prohibited_s007 = {
        "R002_TEMPERATURE_LOW",
        "R003_TEMPERATURE_HIGH",
        "R005_COUNT_VARIANCE",
        "R007_TRANSIT_DELAY",
    }
    if s007_trigger_ids & prohibited_s007:
        fail("S-007 boundary rule triggered unexpectedly")
    s008_trigger_ids = {item["rule_id"] for item in s008["triggered_rules"]}
    if "R002_TEMPERATURE_LOW" in s008_trigger_ids:
        fail("S-008 lower-bound rule triggered unexpectedly")

    # Configuration-binding test.
    modified_config = copy.deepcopy(config)
    high_temp_rules = [
        rule for rule in modified_config["rules"]
        if rule.get("rule_id") == "R003_TEMPERATURE_HIGH"
    ]
    if len(high_temp_rules) != 1:
        fail("High-temperature rule not uniquely identifiable")
    high_temp_rules[0]["comparison_value"] = "7.9"
    modified_s007 = evaluate_record(source_map["S-007"], modified_config)
    if modified_s007["decision"] != "HOLD":
        fail("Modified S-007 decision did not become HOLD")
    if "R003_TEMPERATURE_HIGH" not in {
        item["rule_id"] for item in modified_s007["triggered_rules"]
    }:
        fail("Modified S-007 did not trigger the high-temperature rule")

    # Rule-order independence test.
    reversed_config = copy.deepcopy(config)
    reversed_config["rules"] = list(reversed(reversed_config["rules"]))
    reversed_results = [
        evaluate_record(record, reversed_config)
        for record in records
    ]
    reversed_map = {item["shipment_id"]: item for item in reversed_results}
    for shipment_id in canonical_ids:
        original = computed_map[shipment_id]
        reversed_result = reversed_map[shipment_id]
        if original["decision"] != reversed_result["decision"]:
            fail(f"Rule-order decision mismatch: {shipment_id}")
        original_rule_set = {item["rule_id"] for item in original["triggered_rules"]}
        reversed_rule_set = {item["rule_id"] for item in reversed_result["triggered_rules"]}
        if original_rule_set != reversed_rule_set:
            fail(f"Rule-order trigger-set mismatch: {shipment_id}")

    # Multiple-trigger test.
    expected_s010_rules = {
        "R003_TEMPERATURE_HIGH",
        "R004_SEAL_INTACT",
        "R005_COUNT_VARIANCE",
        "R006_DOCUMENTS_COMPLETE",
        "R007_TRANSIT_DELAY",
    }
    observed_s010_rules = {
        item["rule_id"] for item in computed_map["S-010"]["triggered_rules"]
    }
    if observed_s010_rules != expected_s010_rules:
        fail("S-010 multiple-trigger set mismatch")

    after_hashes = {
        name: sha256_bytes((package_dir / name).read_bytes())
        for name in PACKAGE_FILES
    }
    if before_hashes != after_hashes:
        fail("Packaged artifact changed during in-memory tests")

    manifest_count = verify_manifest(package_dir)
    crc_errors = verify_archive(archive_path, package_dir)

    print("CHAINGATE DEMO 010 REPLAY - PASS")
    print(f"Shipments evaluated: {len(records)}")
    print(f"Decision totals: RELEASE={totals['RELEASE']} HOLD={totals['HOLD']}")
    print("EXACT_BOUNDARY_TESTS: PASS")
    print("CONFIGURATION_BINDING_TEST: PASS")
    print("RULE_ORDER_INDEPENDENCE_TEST: PASS")
    print("MULTIPLE_TRIGGER_TEST: PASS")
    print(f"Manifest entries verified: {manifest_count}/{manifest_count}")
    print("Verifier runs compared: 2")
    print("Verifier stdout identity: CONFIRMED")
    print(f"CRC errors: {crc_errors}")
    print("Replay divergence: 0")
    print("FINAL STATUS: PASS - CONFIGURATION_DRIVEN_RELEASE_REPLAY_VERIFIED")
    return 0

if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(1)

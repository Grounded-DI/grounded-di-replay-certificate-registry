#!/usr/bin/env python3
"""Run verification and negative controls without modifying bundle inputs."""
import hashlib,json,os,shutil,subprocess,sys,tempfile
from pathlib import Path
b=Path(__file__).resolve().parent
def hashes(): return {str(p.relative_to(b)):hashlib.sha256(p.read_bytes()).hexdigest() for p in b.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
def check(path):
 p=subprocess.run([sys.executable,'-B',str(path/'verify.py'),str(path)],capture_output=True,text=True)
 return p.returncode,json.loads(p.stdout)
before=hashes()
code,original=check(b)
if code: raise RuntimeError(original)
controls=[]
for kind in ('report_content','action_destination','saved_export_missing'):
 with tempfile.TemporaryDirectory(prefix='di2-negative-') as t:
  copy=Path(t)/'bundle';shutil.copytree(b,copy,ignore=shutil.ignore_patterns('__pycache__'))
  if kind=='report_content':
   with (copy/'report.txt').open('ab') as f:f.write(b'Altered only in the negative-control copy.\n')
  elif kind=='action_destination':
   p=copy/'actions.json';a=json.loads(p.read_text());a['original']['destination']='changed/report.txt';p.write_text(json.dumps(a))
  else: (copy/'execution/original/approved/report.txt').unlink()
  c,r=check(copy)
  if c==0: raise RuntimeError('NEGATIVE_CONTROL_NOT_REJECTED: '+kind)
  controls.append({'test':kind,'rejected':True,'verifier_exit_code':c,'exact_reason':r['reason']})
code,reverified=check(b)
if code or hashes()!=before:raise RuntimeError('ORIGINAL_CHANGED_OR_FAILED')
print(json.dumps({'status':'PASS','verification':original,'negative_controls':controls,'original_unchanged':True,'original_reverification':reverified['status']},indent=2))

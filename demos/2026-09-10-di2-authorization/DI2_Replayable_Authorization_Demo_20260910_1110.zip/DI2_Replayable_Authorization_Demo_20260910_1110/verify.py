#!/usr/bin/env python3
"""Fresh-process replay with the included rule implementation; no model calls."""
import json, subprocess, sys, tempfile, hashlib
from pathlib import Path

def verify(bundle):
    bundle=Path(bundle).resolve()
    with tempfile.TemporaryDirectory(prefix='di2-replay-') as tmp:
        out=Path(tmp)/'execution'
        p=subprocess.run([sys.executable,str(bundle/'demo.py'),str(bundle),str(out)],capture_output=True,text=True)
        if p.returncode: raise ValueError('FRESH_EXECUTION_REJECTED: '+p.stdout.strip())
        generated=(out/'replay-identity.json').read_bytes()
        expected=(bundle/'execution/replay-identity.json').read_bytes()
        digest=hashlib.sha256(generated).hexdigest()
        if generated!=expected: raise ValueError('REPLAY_IDENTITY_BYTES_MISMATCH')
        if digest!=(bundle/'execution/replay-identity.sha256').read_text().strip(): raise ValueError('REPLAY_SHA256_MISMATCH')
        results=json.loads(generated)['results']
        for name in ('original','original_re_evaluation'):
            r=results[name]
            if r['decision']!='ALLOW' or r['write_open_attempts']!=1 or list(r['files'])!=['approved/report.txt']:
                raise ValueError('POSITIVE_CONTROL_FAILED')
        r=results['changed_destination']
        if r!={'decision':'DENY','reason':'DESTINATION_MISMATCH','write_open_attempts':0,'files':{}}:
            raise ValueError('DESTINATION_CONTROL_FAILED')
        # Also bind saved execution results and exported bytes; missing evidence fails.
        if (bundle/'execution/results.json').read_bytes()!=(out/'results.json').read_bytes(): raise ValueError('SAVED_RESULTS_MISMATCH')
        for name,r in results.items():
            root=bundle/'execution'/name
            actual={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in root.rglob('*') if p.is_file()}
            if not root.is_dir() or actual!=r['files']: raise ValueError('SAVED_EXPORT_MISMATCH')
        return {'status':'PASS','regenerated_sha256':digest,'canonical_bytes_identical':True,
          'fresh_process':True,'fresh_file_execution':True,'evaluator':'same versioned demo.py implementation; not independently implemented',
          'results':results}
if __name__=='__main__':
    try: print(json.dumps(verify(sys.argv[1] if len(sys.argv)>1 else Path(__file__).parent),indent=2))
    except Exception as e:
        print(json.dumps({'status':'FAIL','reason':str(e)},indent=2));sys.exit(1)

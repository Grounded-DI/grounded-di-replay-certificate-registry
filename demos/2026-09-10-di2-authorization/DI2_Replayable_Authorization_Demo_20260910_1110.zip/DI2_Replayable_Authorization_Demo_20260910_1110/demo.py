#!/usr/bin/env python3
"""Isolated local demonstration. Not an installed Grounded DI OS feature."""
import hashlib, json, os, re, sys
from pathlib import Path

VERSION = 'demo-export-v1'
def canonical(x):
    # Restricted ASCII JSON domain avoids Unicode/number interoperability ambiguity.
    def check(v):
        if v is None or type(v) is bool: return
        if type(v) is int and abs(v) <= 9007199254740991: return
        if type(v) is str and all(32 <= ord(c) <= 126 or c == '\n' for c in v): return
        if type(v) is list:
            for a in v: check(a)
            return
        if type(v) is dict:
            for k,a in v.items():
                if type(k) is not str: raise ValueError('INVALID_KEY')
                check(k); check(a)
            return
        raise ValueError('UNSUPPORTED_CANONICAL_VALUE')
    check(x)
    return (json.dumps(x, sort_keys=True, ensure_ascii=True, separators=(',',':'), allow_nan=False)+'\n').encode('ascii')
def sha(b): return hashlib.sha256(b).hexdigest()
def readjson(p):
    def pairs(items):
        out={}
        for k,v in items:
            if k in out: raise ValueError('DUPLICATE_KEY')
            out[k]=v
        return out
    return json.loads(Path(p).read_text(), object_pairs_hook=pairs)
def save(p,x): Path(p).write_bytes(canonical(x))
def evaluate(report, policy, authorization, action):
    if policy != {'version':VERSION,'action':'export_report','destination':'approved/report.txt','scope':'demo_directory','state':{'classification':'synthetic','revision':1}}:
        return {'decision':'DENY','reason':'POLICY_UNSUPPORTED'}
    expected = dict(policy, report_sha256=sha(report))
    if authorization != expected:
        return {'decision':'DENY','reason':'AUTHORIZATION_BINDING_MISMATCH'}
    if action.get('destination') != authorization['destination']:
        return {'decision':'DENY','reason':'DESTINATION_MISMATCH'}
    if action != expected:
        return {'decision':'DENY','reason':'ACTION_BINDING_MISMATCH'}
    return {'decision':'ALLOW','reason':'EXACT_AUTHORIZATION_MATCH'}
def execute(root, report, policy, authorization, action):
    # Freeze proposal before final evaluation; mutable caller data never reaches writer.
    action=readjson_bytes(canonical(action))
    result=evaluate(report,policy,authorization,action)
    result.update(write_open_attempts=0, files={})
    if result['decision']=='DENY': return result
    # No model-controlled pathname is passed to open. Exact allow-listed destination.
    rootfd=os.open(root,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
    try:
        os.mkdir('approved',0o700,dir_fd=rootfd)
        dfd=os.open('approved',os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=rootfd)
        try:
            result['write_open_attempts']=1
            fd=os.open('report.txt',os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600,dir_fd=dfd)
            with os.fdopen(fd,'wb') as f:
                f.write(report);f.flush();os.fsync(f.fileno())
            os.fsync(dfd)
        finally: os.close(dfd)
    finally: os.close(rootfd)
    b=(Path(root)/'approved/report.txt').read_bytes()
    if b!=report: raise ValueError('EXPORT_BYTES_MISMATCH')
    result['files']={'approved/report.txt':sha(b)}
    return result

def readjson_bytes(b): return json.loads(b)
def run(bundle, output):
    bundle=Path(bundle); output=Path(output);output.mkdir(mode=0o700,parents=True,exist_ok=False)
    report=(bundle/'report.txt').read_bytes()
    policy=readjson(bundle/'policy.json');auth=readjson(bundle/'authorization.json')
    actions=readjson(bundle/'actions.json')
    if sha(report)!=auth['report_sha256']: raise ValueError('REPORT_HASH_MISMATCH')
    if set(actions)!={'original','changed_destination','original_re_evaluation'}: raise ValueError('CASE_SET_MISMATCH')
    results={}
    for name in ('original','changed_destination','original_re_evaluation'):
        root=output/name;root.mkdir(mode=0o700)
        r=execute(root,report,policy,auth,actions[name])
        actual={str(p.relative_to(root)):sha(p.read_bytes()) for p in root.rglob('*') if p.is_file()}
        if actual!=r['files']: raise ValueError('UNEXPECTED_FILES')
        results[name]=r
    identity={'schema':'DI2-DEMO-REPLAY-1','canonicalization':'DI2-ASCII-JSON-LF-1',
      'kernel_sha256':sha(Path(__file__).read_bytes()),
      'input_hashes':{n:sha((bundle/n).read_bytes()) for n in ('report.txt','policy.json','authorization.json','actions.json')},
      'results':results}
    save(output/'results.json',results);save(output/'replay-identity.json',identity)
    digest=sha(canonical(identity))
    (output/'replay-identity.sha256').write_text(digest+'\n')
    return identity
if __name__=='__main__':
    try:
        identity=run(sys.argv[1],sys.argv[2]); print(json.dumps({'status':'EXECUTED','sha256':sha(canonical(identity))}))
    except Exception as e:
        print(json.dumps({'status':'FAIL','reason':str(e)}));sys.exit(1)

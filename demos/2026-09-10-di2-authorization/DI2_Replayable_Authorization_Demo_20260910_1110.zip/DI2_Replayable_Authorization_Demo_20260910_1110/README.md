# DI2 Replayable Authorization Demo

A synthetic cybersecurity authorization demonstration, created 2026-09-10.

## What actually ran
Grounded DI OS in signed-in Chrome created the project **DI2 Replayable Authorization Demo**, generated the saved JSON proposal through its Grounded DI Assistant, and acknowledged saving the response. Reload saved conversation restored the response. No existing projects were deleted or modified.

A **separate Python harness**, included here, performed the deterministic authorization, actual local file exports, and replay. This is not an installed Grounded DI OS or ShieldBot execution-gate feature. The assistant response contains predictions and explicitly says not_executed. It is never accepted as proof of a PASS.

The report content, destination, action, policy, and state were extracted from that actual proposal. Codex instantiated the operator authorization under the user's explicit synthetic demo instruction. There is no authenticated organizational approval service or cryptographic signature on that authorization.

## Executed cases
1. Original: ALLOW; created approved/report.txt containing the exact report bytes.
2. Destination changed to changed/report.txt with the original authorization: DENY / DESTINATION_MISMATCH; zero write-open attempts, zero exported files.
3. Original re-evaluation: ALLOW; wrote the same report bytes in a fresh isolated case directory.

Each case uses a fresh instance of the logical demo_directory scope. Physical execution directories are pinned by directory descriptors; physical paths are not part of replay identity. This tests changed relative destination, not substitution of an external real-world destination or organization identity.

## Replay
Requires Python 3.9+ on macOS or a POSIX platform supporting directory descriptors and O_NOFOLLOW. No third-party packages or network calls.

From this extracted folder:

```sh
python3 -B verify.py
python3 -B acceptance.py
shasum -a 256 -c SHA256SUMS.txt
```

The verifier starts demo.py in a fresh process and performs fresh writes in temporary isolated case directories, then compares regenerated canonical identity bytes, hashes, results, and saved exported files. The temporary replay directories are removed afterward; the saved original bundle remains unchanged. The acceptance runner changes copies only, tests report alteration, action alteration, and missing exported evidence, then re-verifies the untouched original. A nonzero exit means failure.

Replay uses the **same versioned evaluator**, not an independently implemented second evaluator. The verifier does not merely compare stored hashes or consume stored PASS values.

## Canonical bytes and identity
DI2-ASCII-JSON-LF-1 is a deliberately restricted custom serialization, not a claim of full JCS compliance. Values may be null, booleans, integers within +/-9007199254740991, arrays, dictionaries with string keys, and strings limited to printable ASCII plus LF. Floats and other strings are rejected. Object keys sort lexicographically, array order is retained, JSON uses compact separators, ASCII escaping, and exactly one terminating LF; bytes are ASCII (therefore also UTF-8). Duplicate JSON keys are rejected by the kernel loader.

Identity binds the kernel source SHA-256, exact bytes of the report/policy/authorization/actions files, and regenerated decisions and file hashes. Changing input file whitespace also changes the identity; mismatches are not silently normalized away. Saved replay-identity.json is the actual canonical byte file.

Timestamps, physical output roots, assistant wording and model/run metadata are outside deterministic replay identity. The package-wide SHA256SUMS.txt separately covers these deliverables. Model and run IDs were not exposed in the observed conversation UI and are recorded as unavailable, not fabricated. Provider response bytes/whitespace were not captured: assistant-response.txt faithfully transcribes rendered response text from Computer Use accessibility observations.

## Execution boundary and limitations
The writer rechecks a frozen action against authorization before opening any output, and only passes the literal allow-listed destination to its file writer. It uses an isolated root directory descriptor, O_NOFOLLOW, exclusive file creation, and fsync. A rejection actually prevents this harness's write branch; it is not merely a displayed refusal.

This proves the selected destination-mismatch behavior within the harness. It does not establish system-wide enforcement, protection from another program writing files, hostile same-account/root resistance, race safety under a compromised filesystem, revocation, expiry, one-time tokens, all permission changes, or an enterprise security boundary. Policy state is supplied synthetic data, not independently measured OS permissions. No live containment or security-setting changes were performed.

The local certificate is unsigned and self-issued, not third-party attestation. An attacker able to replace code, inputs, certificate, and checksums together can replace the entire claimed history. Preserve the ZIP checksum through a separately trusted channel if distributing it.

No claim is made of identical model generation, correct threat detection, legal correctness, or independent external validation. No private runtime sources, credentials, cookies, unrelated conversation content, or private reports are included. Nothing was uploaded or published.

#!/usr/bin/env python3
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import sys
import zipfile
from fractions import Fraction
from pathlib import Path
from typing import Any

PACKAGE_FILES = [
    "01_canonical_input.json",
    "02_formula_configuration.json",
    "03_calculation_results.json",
    "04_audit_record.json",
    "05_manifest.json",
    "06_verify_demo.py",
    "README.md",
]

KNOWN_FIELDS = {
    "record_id",
    "instability_score",
    "rotation_score",
    "shear_score",
    "moisture_score",
    "boundary_present",
}
SCORE_FIELDS = KNOWN_FIELDS - {"record_id"}
KNOWN_CLASSIFICATIONS = {"MINIMAL", "MONITOR", "CONCERN"}

def fail(message: str) -> None:
    raise RuntimeError(message)

def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))

def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def fraction_object(value: Fraction) -> dict[str, int]:
    return {"denominator": value.denominator, "numerator": value.numerator}

def parse_fraction_object(obj: dict[str, Any]) -> Fraction:
    if not isinstance(obj, dict) or set(obj) != {"numerator", "denominator"}:
        fail("Unknown threshold definition")
    numerator = obj["numerator"]
    denominator = obj["denominator"]
    if not isinstance(numerator, int) or isinstance(numerator, bool):
        fail("Threshold numerator must be an integer")
    if not isinstance(denominator, int) or isinstance(denominator, bool) or denominator <= 0:
        fail("Threshold denominator must be a positive integer")
    return Fraction(numerator, denominator)

def exact_decimal_one_place(value: Fraction) -> str:
    scaled = value * 10
    if scaled.denominator != 1:
        fail(f"Value is not exactly representable to one decimal place: {value}")
    units = scaled.numerator
    sign = "-" if units < 0 else ""
    units = abs(units)
    return f"{sign}{units // 10}.{units % 10}"

def validate_configuration(config: dict[str, Any]) -> None:
    required_fields = config.get("required_fields")
    if not isinstance(required_fields, list) or set(required_fields) != KNOWN_FIELDS:
        fail("Unknown required-field definition")
    if len(required_fields) != len(set(required_fields)):
        fail("Duplicate required field")

    formula = config.get("formula")
    if not isinstance(formula, dict):
        fail("Missing formula")
    if formula.get("operator") != "weighted_sum_divide":
        fail("Unknown formula operator")
    divisor = formula.get("divisor")
    if not isinstance(divisor, int) or isinstance(divisor, bool) or divisor <= 0:
        fail("Unknown divisor")
    terms = formula.get("terms")
    if not isinstance(terms, list) or not terms:
        fail("Missing formula terms")

    seen_term_ids: set[str] = set()
    seen_fields: set[str] = set()
    for term in terms:
        if not isinstance(term, dict) or set(term) != {"term_id", "field", "coefficient"}:
            fail("Unknown formula term definition")
        term_id = term["term_id"]
        field = term["field"]
        coefficient = term["coefficient"]
        if not isinstance(term_id, str) or not term_id or term_id in seen_term_ids:
            fail("Missing or duplicate term ID")
        seen_term_ids.add(term_id)
        if field not in SCORE_FIELDS or field in seen_fields:
            fail("Unknown or duplicate formula field")
        seen_fields.add(field)
        if not isinstance(coefficient, int) or isinstance(coefficient, bool) or coefficient < 0:
            fail("Unknown coefficient")
    if seen_fields != SCORE_FIELDS:
        fail("Formula terms do not cover all score fields")

    thresholds = config.get("classification_thresholds")
    if not isinstance(thresholds, dict) or set(thresholds) != {"minimal_max", "concern_min"}:
        fail("Unknown classification thresholds")
    minimal_max = parse_fraction_object(thresholds["minimal_max"])
    concern_min = parse_fraction_object(thresholds["concern_min"])
    if not minimal_max < concern_min:
        fail("Classification thresholds are not ordered")

    allowed = config.get("allowed_classifications")
    if not isinstance(allowed, list) or set(allowed) != KNOWN_CLASSIFICATIONS:
        fail("Unknown classification set")

    rules = config.get("classification_rules")
    if not isinstance(rules, list) or len(rules) != 3:
        fail("Unknown classification rule count")

    seen_rule_ids: set[str] = set()
    seen_classes: set[str] = set()
    for rule in rules:
        if not isinstance(rule, dict) or rule.get("rule_type") != "range":
            fail("Unknown threshold rule")
        rule_id = rule.get("rule_id")
        classification = rule.get("classification")
        if not isinstance(rule_id, str) or not rule_id or rule_id in seen_rule_ids:
            fail("Missing or duplicate classification rule ID")
        seen_rule_ids.add(rule_id)
        if classification not in KNOWN_CLASSIFICATIONS or classification in seen_classes:
            fail("Unknown or duplicate classification")
        seen_classes.add(classification)

        for bound_name in ("lower_bound", "upper_bound"):
            bound = rule.get(bound_name)
            if bound is None:
                continue
            if not isinstance(bound, dict) or set(bound) != {"threshold_ref", "inclusive"}:
                fail("Unknown threshold-boundary definition")
            if bound["threshold_ref"] not in thresholds:
                fail("Unknown threshold reference")
            if not isinstance(bound["inclusive"], bool):
                fail("Unknown threshold inclusivity definition")

    rule_map = {r["classification"]: r for r in rules}
    expected_boundaries = {
        "MINIMAL": (None, {"inclusive": True, "threshold_ref": "minimal_max"}),
        "MONITOR": (
            {"inclusive": False, "threshold_ref": "minimal_max"},
            {"inclusive": True, "threshold_ref": "concern_min"},
        ),
        "CONCERN": ({"inclusive": False, "threshold_ref": "concern_min"}, None),
    }
    for classification, (lower, upper) in expected_boundaries.items():
        if rule_map[classification]["lower_bound"] != lower:
            fail(f"{classification} lower-bound definition mismatch")
        if rule_map[classification]["upper_bound"] != upper:
            fail(f"{classification} upper-bound definition mismatch")

def normalize_record(record: dict[str, Any], required_fields: list[str]) -> dict[str, Any]:
    if set(record) != set(required_fields):
        fail("Record field set mismatch")
    normalized: dict[str, Any] = {}
    for field in required_fields:
        value = record[field]
        if field == "record_id":
            if not isinstance(value, str) or not value:
                fail("Invalid record_id")
        else:
            if not isinstance(value, int) or isinstance(value, bool) or value < 0:
                fail(f"Invalid score: {field}")
        normalized[field] = value
    return normalized

def bound_matches(
    value: Fraction,
    bound: dict[str, Any] | None,
    thresholds: dict[str, Fraction],
    *,
    lower: bool,
) -> bool:
    if bound is None:
        return True
    threshold = thresholds[bound["threshold_ref"]]
    inclusive = bound["inclusive"]
    if lower:
        return value >= threshold if inclusive else value > threshold
    return value <= threshold if inclusive else value < threshold

def calculate_record(record: dict[str, Any], config: dict[str, Any]) -> dict[str, Any]:
    validate_configuration(config)
    normalized = normalize_record(record, config["required_fields"])
    formula = config["formula"]

    contributions = []
    numerator = 0
    for term in formula["terms"]:
        input_value = normalized[term["field"]]
        contribution = term["coefficient"] * input_value
        numerator += contribution
        contributions.append({
            "coefficient": term["coefficient"],
            "contribution": contribution,
            "field": term["field"],
            "input_value": input_value,
            "term_id": term["term_id"],
        })

    divisor = formula["divisor"]
    exact_index = Fraction(numerator, divisor)
    formatted_index = exact_decimal_one_place(exact_index)

    thresholds = {
        key: parse_fraction_object(value)
        for key, value in config["classification_thresholds"].items()
    }
    evaluated_rules = []
    matched_rules = []
    for rule in config["classification_rules"]:
        lower_match = bound_matches(exact_index, rule["lower_bound"], thresholds, lower=True)
        upper_match = bound_matches(exact_index, rule["upper_bound"], thresholds, lower=False)
        matched = lower_match and upper_match
        evaluation = {
            "classification": rule["classification"],
            "lower_bound": rule["lower_bound"],
            "matched": matched,
            "rule_id": rule["rule_id"],
            "upper_bound": rule["upper_bound"],
        }
        evaluated_rules.append(evaluation)
        if matched:
            matched_rules.append(evaluation)

    if len(matched_rules) != 1:
        fail(f"Classification rules produced {len(matched_rules)} matches")
    matched_rule = matched_rules[0]
    classification = matched_rule["classification"]

    explanation = (
        f"TOR_NUMERATOR {numerator} divided by configured divisor {divisor} "
        f"equals exact TOR_INDEX {exact_index.numerator}/{exact_index.denominator} "
        f"({formatted_index}), classified {classification} by {matched_rule['rule_id']}."
    )
    transition_chain = [
        "RECEIVED",
        "NORMALIZED",
        "TERMS_COMPUTED",
        "INDEX_COMPUTED",
        "CLASSIFIED",
        "AUDIT_BOUND",
    ]
    if classification == "CONCERN":
        transition_chain.append("CONCERN_FLAGGED")

    return {
        "classification": classification,
        "classification_rule_evaluations": evaluated_rules,
        "divisor": divisor,
        "exact_tor_index": fraction_object(exact_index),
        "explanation": explanation,
        "formatted_tor_index": formatted_index,
        "formula_id": formula["formula_id"],
        "matched_classification_rule": matched_rule,
        "normalized_record": normalized,
        "record_id": normalized["record_id"],
        "term_contributions": contributions,
        "tor_numerator": numerator,
        "transition_chain": transition_chain,
    }

def verify_manifest(package_dir: Path) -> int:
    manifest = load_json(package_dir / "05_manifest.json")
    required_policy = (
        "05_manifest.json is intentionally excluded from its own hash ledger "
        "to avoid circular self-reference. The containing ZIP SHA-256 binds the manifest."
    )
    if manifest.get("self_reference_policy") != required_policy:
        fail("Manifest self-reference policy mismatch")

    entries = manifest.get("entries")
    if not isinstance(entries, list):
        fail("Manifest entries missing")
    expected_names = sorted(name for name in PACKAGE_FILES if name != "05_manifest.json")
    actual_names = sorted(entry.get("filename") for entry in entries)
    if actual_names != expected_names:
        fail("Manifest filename set mismatch")

    for entry in entries:
        data = (package_dir / entry["filename"]).read_bytes()
        if len(data) != entry["size_bytes"]:
            fail(f"Manifest size mismatch: {entry['filename']}")
        if sha256_bytes(data) != entry["sha256"]:
            fail(f"Manifest hash mismatch: {entry['filename']}")

    return len(entries)

def verify_archive(archive_path: Path, package_dir: Path) -> int:
    with zipfile.ZipFile(archive_path, "r") as archive:
        if archive.namelist() != sorted(PACKAGE_FILES):
            fail("Archive member set or order mismatch")
        if archive.comment != b"":
            fail("Archive comment present")
        crc_errors = 0 if archive.testzip() is None else 1

        for info in archive.infolist():
            if info.is_dir():
                fail("Directory entry present")
            if info.compress_type != zipfile.ZIP_STORED:
                fail("Compression mismatch")
            if info.date_time != (1980, 1, 1, 0, 0, 0):
                fail("Timestamp mismatch")
            if ((info.external_attr >> 16) & 0o777) != 0o644:
                fail("Permission mismatch")
            if info.comment != b"":
                fail("Member comment present")
            if info.extra != b"":
                fail("Extra field present")

            archive_data = archive.read(info.filename)
            if archive_data != (package_dir / info.filename).read_bytes():
                fail(f"Archive/extraction mismatch: {info.filename}")
            if archive_data.startswith(b"\xef\xbb\xbf"):
                fail(f"UTF-8 BOM present: {info.filename}")
            if b"\r" in archive_data:
                fail(f"Non-LF line ending present: {info.filename}")
            if not archive_data.endswith(b"\n"):
                fail(f"Final newline missing: {info.filename}")

        return crc_errors

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--package-dir", required=True)
    parser.add_argument("--archive", required=True)
    args = parser.parse_args()

    package_dir = Path(args.package_dir)
    archive_path = Path(args.archive)

    actual_files = sorted(p.name for p in package_dir.iterdir() if p.is_file())
    if actual_files != sorted(PACKAGE_FILES):
        fail("Extracted package file set mismatch")

    canonical = load_json(package_dir / "01_canonical_input.json")
    config = load_json(package_dir / "02_formula_configuration.json")
    stored_results = load_json(package_dir / "03_calculation_results.json")
    audit = load_json(package_dir / "04_audit_record.json")
    validate_configuration(config)

    records = canonical.get("records")
    expected_results = canonical.get("expected_results")
    if not isinstance(records, list) or not isinstance(expected_results, list):
        fail("Missing canonical records or expectations")

    canonical_ids = [r.get("record_id") for r in records]
    expected_ids = [r.get("record_id") for r in expected_results]
    if len(canonical_ids) != len(set(canonical_ids)):
        fail("Duplicate canonical record ID")
    if len(expected_ids) != len(set(expected_ids)):
        fail("Duplicate expected record ID")
    if set(canonical_ids) != set(expected_ids):
        fail("Canonical and expected record-ID sets differ")

    computed_a = [calculate_record(record, config) for record in records]
    computed_b = [
        calculate_record(record, copy.deepcopy(config))
        for record in copy.deepcopy(records)
    ]
    if computed_a != computed_b:
        fail("Internal deterministic calculation mismatch")

    computed_map = {r["record_id"]: r for r in computed_a}
    expected_map = {r["record_id"]: r for r in expected_results}
    for record_id in canonical_ids:
        observed = computed_map[record_id]
        expected = expected_map[record_id]
        if observed["formatted_tor_index"] != expected["formatted_tor_index"]:
            fail(f"Expected TOR_INDEX mismatch: {record_id}")
        if observed["classification"] != expected["classification"]:
            fail(f"Expected classification mismatch: {record_id}")

    totals = {"CONCERN": 0, "MINIMAL": 0, "MONITOR": 0}
    for result in computed_a:
        totals[result["classification"]] += 1
    if totals != canonical.get("expected_totals"):
        fail("Classification totals mismatch")

    stored = stored_results.get("results")
    if not isinstance(stored, list):
        fail("Stored results missing")
    stored_ids = [r.get("record_id") for r in stored]
    if len(stored_ids) != len(set(stored_ids)):
        fail("Duplicate stored-result record ID")
    if set(stored_ids) != set(canonical_ids):
        fail("Stored-result record-ID set mismatch")
    if stored_results.get("classification_totals") != totals:
        fail("Stored classification totals mismatch")

    stored_map = {r["record_id"]: r for r in stored}
    result_fields = [
        "classification",
        "divisor",
        "exact_tor_index",
        "explanation",
        "formatted_tor_index",
        "matched_classification_rule",
        "term_contributions",
        "tor_numerator",
    ]
    for record_id in canonical_ids:
        observed = computed_map[record_id]
        saved = stored_map[record_id]
        for field in result_fields:
            if saved.get(field) != observed[field]:
                fail(f"Stored {field} mismatch: {record_id}")

    events = audit.get("events")
    record_audits = audit.get("record_audits")
    if audit.get("append_only") is not True:
        fail("Audit append-only flag missing")
    if not isinstance(events, list) or not isinstance(record_audits, list):
        fail("Audit data missing")
    if audit.get("event_count") != len(events):
        fail("Audit event count mismatch")

    event_ids = [event.get("event_id") for event in events]
    expected_event_ids = [f"EVT-{i:04d}" for i in range(1, len(events) + 1)]
    if event_ids != expected_event_ids:
        fail("Audit event sequence mismatch")

    audit_ids = [item.get("record_id") for item in record_audits]
    if len(audit_ids) != len(set(audit_ids)):
        fail("Duplicate audit record ID")
    if set(audit_ids) != set(canonical_ids):
        fail("Audit record-ID set mismatch")

    audit_map = {item["record_id"]: item for item in record_audits}
    source_map = {item["record_id"]: item for item in records}
    for record_id in canonical_ids:
        observed = computed_map[record_id]
        audit_item = audit_map[record_id]
        checks = {
            "canonical_source_record": source_map[record_id],
            "normalized_input_values": observed["normalized_record"],
            "formula_id": observed["formula_id"],
            "coefficient_and_term_contributions": observed["term_contributions"],
            "tor_numerator": observed["tor_numerator"],
            "divisor": observed["divisor"],
            "exact_tor_index": observed["exact_tor_index"],
            "formatted_tor_index": observed["formatted_tor_index"],
            "classification_rule_evaluations": observed["classification_rule_evaluations"],
            "matched_classification_rule": observed["matched_classification_rule"],
            "final_classification": observed["classification"],
            "explanation": observed["explanation"],
            "transition_chain": observed["transition_chain"],
        }
        for field, expected_value in checks.items():
            if audit_item.get(field) != expected_value:
                fail(f"Audit {field} mismatch: {record_id}")

        event_stages = [
            event["stage"] for event in events
            if event["record_id"] == record_id
        ]
        if event_stages != observed["transition_chain"]:
            fail(f"Audit transition mismatch: {record_id}")

    before_hashes = {
        name: sha256_bytes((package_dir / name).read_bytes())
        for name in PACKAGE_FILES
    }

    source_t001 = source_map["T-001"]
    if calculate_record(source_t001, config)["formatted_tor_index"] != "0.3":
        fail("Original T-001 formula-binding result mismatch")
    modified_formula_config = copy.deepcopy(config)
    instability_terms = [
        term for term in modified_formula_config["formula"]["terms"]
        if term.get("field") == "instability_score"
    ]
    if len(instability_terms) != 1:
        fail("Instability term not uniquely identifiable")
    instability_terms[0]["coefficient"] = 4
    if calculate_record(source_t001, modified_formula_config)["formatted_tor_index"] != "0.4":
        fail("Modified T-001 formula-binding result mismatch")

    source_t005 = source_map["T-005"]
    original_t005 = calculate_record(source_t005, config)
    if original_t005["formatted_tor_index"] != "2.2" or original_t005["classification"] != "CONCERN":
        fail("Original T-005 classification-binding result mismatch")
    modified_class_config = copy.deepcopy(config)
    modified_class_config["classification_thresholds"]["concern_min"] = {
        "denominator": 5,
        "numerator": 11,
    }
    modified_t005 = calculate_record(source_t005, modified_class_config)
    if modified_t005["classification"] != "MONITOR":
        fail("Modified T-005 classification-binding result mismatch")

    if computed_map["T-004"]["formatted_tor_index"] != "2.0":
        fail("T-004 boundary value mismatch")
    if computed_map["T-004"]["classification"] != "MONITOR":
        fail("T-004 exact-boundary classification mismatch")
    if computed_map["T-007"]["formatted_tor_index"] != "0.1":
        fail("T-007 value mismatch")

    after_hashes = {
        name: sha256_bytes((package_dir / name).read_bytes())
        for name in PACKAGE_FILES
    }
    if before_hashes != after_hashes:
        fail("Packaged artifact changed during binding tests")

    manifest_count = verify_manifest(package_dir)
    crc_errors = verify_archive(archive_path, package_dir)

    print("STORMWISE DEMO 009 REPLAY - PASS")
    print(f"Records evaluated: {len(records)}")
    print(
        "Classification totals: "
        f"MINIMAL={totals['MINIMAL']} "
        f"MONITOR={totals['MONITOR']} "
        f"CONCERN={totals['CONCERN']}"
    )
    print("FORMULA_BINDING_TEST: PASS")
    print("CLASSIFICATION_BINDING_TEST: PASS")
    print("Exact-boundary test at 2.0: PASS")
    print(f"Manifest entries verified: {manifest_count}/{manifest_count}")
    print("Verifier runs compared: 2")
    print("Verifier stdout identity: CONFIRMED")
    print(f"CRC errors: {crc_errors}")
    print("Replay divergence: 0")
    print("FINAL STATUS: PASS - EXACT_MATH_REPLAY_VERIFIED")
    return 0

if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(1)

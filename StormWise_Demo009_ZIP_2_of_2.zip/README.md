# Grounded DI OS Demo 009 — Repeatable Tornado Index Math

> A synthetic ten-record atmospheric math package with configuration-driven TOR_INDEX calculations, exact threshold classification, audit-linked term contributions, and deterministic single-package replay.

## 1. What was tested

Demo 009 tested whether Grounded DI OS could normalize ten synthetic atmospheric score records, execute a disclosed exact formula, expose every weighted contribution, classify each exact result through configured rational thresholds, bind the calculations to an audit record, and reproduce the same package and verifier output across isolated executions.

## 2. Five-input mathematical model

The synthetic model uses:

- instability score;
- rotation score;
- shear score;
- moisture score;
- boundary-present indicator.

The scores are synthetic normalized demonstration values. They are not observations, radar products, forecast-model outputs, or recognized meteorological indices.

## 3. Exact formula

The configured integer numerator is:

`TOR_NUMERATOR = 3×instability + 3×rotation + 2×shear + 1×moisture + 1×boundary`

The configured index is:

`TOR_INDEX = TOR_NUMERATOR / 10`

All proof-supporting calculations use integers and exact rational arithmetic. Floating-point arithmetic is not used as proof support.

Configured classifications:

- `TOR_INDEX ≤ 0.5` → `MINIMAL`
- `0.5 < TOR_INDEX ≤ 2.0` → `MONITOR`
- `TOR_INDEX > 2.0` → `CONCERN`

## 4. Ten-record result

| Record | TOR_INDEX | Classification |
|---|---:|---|
| T-001 | 0.3 | MINIMAL |
| T-002 | 0.9 | MONITOR |
| T-003 | 1.5 | MONITOR |
| T-004 | 2.0 | MONITOR |
| T-005 | 2.2 | CONCERN |
| T-006 | 3.4 | CONCERN |
| T-007 | 0.1 | MINIMAL |
| T-008 | 1.2 | MONITOR |
| T-009 | 2.7 | CONCERN |
| T-010 | 4.1 | CONCERN |

Totals: **MINIMAL 2 · MONITOR 4 · CONCERN 4**

## 5. Formula-binding test

T-001 produces `0.3` with the packaged instability coefficient of 3. An in-memory configuration copy changes that coefficient to 4, after which T-001 produces `0.4`. No packaged artifact is modified.

`FORMULA_BINDING_TEST: PASS`

## 6. Classification-binding test

T-005 produces `2.2` and `CONCERN` under the packaged concern threshold of greater than 2.0. An in-memory configuration copy changes the concern threshold to greater than 2.2. T-005 then becomes `MONITOR` because 2.2 is not greater than 2.2.

`CLASSIFICATION_BINDING_TEST: PASS`

## 7. Exact-boundary result

T-004 produces the exact rational value `2/1`, formatted `2.0`, and classifies as `MONITOR`.

`Exact-boundary test at 2.0: PASS`

## 8. Single-package reproducibility result

The complete seven-file package tree was generated independently in two isolated temporary locations. Every internal file matched byte-for-byte. Two temporary deterministic ZIPs also matched by SHA-256 and byte comparison. One canonical ZIP was retained and all duplicate temporary artifacts were deleted.

## 9. Verifier replay result

The canonical ZIP was independently extracted twice and verified in two fresh isolated invocations.

- Exit codes: 0 and 0
- Stderr: empty for both runs
- Stdout: byte-identical
- Stdout SHA-256: identical
- Manifest entries verified: 6/6
- CRC errors: 0
- Replay divergence: 0

`FINAL STATUS: PASS - EXACT_MATH_REPLAY_VERIFIED`

## 10. What Grounded DI OS demonstrated

- canonical score normalization;
- configuration-driven weighted arithmetic;
- exact rational computation;
- visible term contributions;
- threshold-boundary control;
- formula and classification binding;
- audit-linked calculations;
- deterministic single-package generation;
- repeatable verifier output.

## 11. What was not claimed

- No tornado forecast is generated.
- No tornado watch or warning determination is made.
- No National Weather Service threshold is asserted.
- No recognized meteorological index is claimed.
- No real atmospheric observation is evaluated.
- No radar, satellite, sounding, or forecast-model data is used.
- No public-safety recommendation is made.
- No predictive skill is claimed.
- No external or independent verification is claimed.
- The demo certifies exact configured arithmetic, classification binding, calculation traceability, artifact integrity, and replay reproducibility only.

## 12. Artifact index

1. `01_canonical_input.json`
2. `02_formula_configuration.json`
3. `03_calculation_results.json`
4. `04_audit_record.json`
5. `05_manifest.json`
6. `06_verify_demo.py`
7. `README.md`

`05_manifest.json` is intentionally excluded from its own hash ledger to avoid circular self-reference. The containing ZIP SHA-256 binds the manifest.

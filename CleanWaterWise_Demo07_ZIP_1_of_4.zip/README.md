# CleanWaterWise Replayable Water-Quality Escalation Demo

**Demo ID:** `CLEANWATERWISE-DEMO-0007`  
**Classification:** Synthetic rule-execution and deterministic replay demonstration  
**Aggregate state:** `HALT`  
**Package export:** Authorized for review  

## Run

```bash
python3 08_verify_demo.py --package-dir .
```

To verify two generated archives:

```bash
python3 08_verify_demo.py --package-dir . \
  --run1 ../CleanWaterWise_Demo07_Run1.zip \
  --run2 ../CleanWaterWise_Demo07_Run2.zip
```

## Scope

This package applies only the fixed demonstration policy recorded in
`03_rule_configuration.json`. It does not assert current regulatory or safety thresholds.

## Manifest self-reference policy

`07_manifest.json` lists every package member except itself. The manifest cannot
cryptographically hash itself without circularity. Its exclusion is explicit and verified.

## Audit binding policy

`06_audit_record.json` binds source, normalization, rule, result, verifier, README,
and assessment artifacts available before the audit record is serialized. The manifest
then binds the audit record, replay log, and all other non-manifest package members.

---

# Grounded DI OS Demo 07 — Deterministic Environmental State Routing

## 1. What was tested

A synthetic environmental rule-execution package with disclosed thresholds, record-level state routing, audit-linked decisions, and two-run deterministic replay.

The demo tests whether Grounded DI OS can normalize seven mixed water-quality records, apply a fixed rule configuration, explain each state decision, bind the result to an append-only audit trail, and reproduce the packaged artifacts byte-for-byte.

## 2. Fixed rule configuration

The demo applies only its disclosed synthetic policy:

- missing required field: HALT;
- pH outside 6.5-8.5: one REVIEW condition;
- turbidity above 5.0 NTU: one REVIEW condition;
- lead above 15.0 ppb: HALT;
- nitrate above 10.0 mg/L: HALT;
- two or more REVIEW conditions: HALT;
- one REVIEW condition with no HALT: REVIEW;
- no REVIEW or HALT condition: PASS.

These are fixed demonstration rules, not asserted regulatory, medical, scientific, or safety standards.

## 3. Seven-record result

| Sample | State | Reason |
|---|---|---|
| A-001 | PASS | No REVIEW or HALT condition |
| A-002 | REVIEW | pH condition |
| B-001 | REVIEW | Turbidity condition |
| B-002 | HALT | Two REVIEW conditions |
| C-001 | HALT | Lead hard gate |
| C-002 | HALT | Nitrate hard gate |
| C-003 | HALT | Missing required field |

Aggregate state: **HALT**

## 4. Replay and hash result

Two independently generated ZIP archives were required to use fixed timestamps, permissions, ordering, compression, UTF-8 encoding, LF line endings, and stable JSON serialization. The final certificate records the observed archive hash, byte comparison, internal hashes, CRC result, verifier exit code, and replay divergence.

## 5. What Grounded DI OS demonstrated

- canonical input normalization;
- disclosed rule execution;
- multi-variable state routing without domain-rule blending;
- transparent record-level explanations;
- explicit state-transition chains;
- append-only audit linkage;
- deterministic archive construction;
- replay verification and export gating.

## 6. What was not claimed

No current regulatory threshold, environmental compliance conclusion, laboratory validation, public-health conclusion, real-site assessment, predictive result, or external verification is claimed.

## 7. Artifact index

1. `01_canonical_input.json`
2. `02_normalized_records.csv`
3. `03_rule_configuration.json`
4. `04_gate_results.json`
5. `05_assessment.txt`
6. `06_audit_record.json`
7. `07_manifest.json`
8. `08_verify_demo.py`
9. `09_replay_pass.log`
10. `README.md`


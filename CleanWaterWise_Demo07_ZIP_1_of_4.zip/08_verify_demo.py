#!/usr/bin/env python3
import argparse, csv, hashlib, io, json, sys, zipfile
from collections import Counter
from decimal import Decimal
from pathlib import Path

TEXT_SUFFIXES = {".json", ".csv", ".txt", ".md", ".py", ".log"}

def sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()

def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()

def is_missing(v):
    return v is None or v == "" or (isinstance(v, str) and v.strip().upper() == "MISSING")

def d(v):
    return None if is_missing(v) else Decimal(str(v))

def normalize(record, required, idx):
    missing = [f for f in required if f not in record or is_missing(record.get(f))]
    out = {"source_record_index": idx, "sample_id": record.get("sample_id",""), "site_id": record.get("site_id",""), "missing_fields": missing}
    for field in ["pH","turbidity_ntu","lead_ppb","nitrate_mg_l"]:
        out[field] = None if is_missing(record.get(field)) else float(d(record.get(field)))
    return out

def evaluate(n):
    reviews, halts = [], []
    if n["missing_fields"]:
        halts.append("missing required field")
    if n["pH"] is not None and (d(n["pH"]) < Decimal("6.5") or d(n["pH"]) > Decimal("8.5")):
        reviews.append("pH condition")
    if n["turbidity_ntu"] is not None and d(n["turbidity_ntu"]) > Decimal("5.0"):
        reviews.append("turbidity condition")
    if n["lead_ppb"] is not None and d(n["lead_ppb"]) > Decimal("15.0"):
        halts.append("lead hard gate")
    if n["nitrate_mg_l"] is not None and d(n["nitrate_mg_l"]) > Decimal("10.0"):
        halts.append("nitrate hard gate")
    if len(reviews) >= 2:
        halts.append("two review conditions")
    state = "HALT" if halts else ("REVIEW" if len(reviews) == 1 else "PASS")
    reasons = halts if halts else reviews
    transitions = ["RECEIVED","NORMALIZED","RULES_EVALUATED","STATE_ASSIGNED","AUDIT_BOUND"]
    if state == "HALT":
        transitions.append("EXPORT_BLOCKED")
    return state, reasons, transitions

def validate_text(path):
    data = path.read_bytes()
    if data.startswith(b"\xef\xbb\xbf"):
        raise AssertionError(f"BOM present: {path.name}")
    data.decode("utf-8")
    if b"\r" in data:
        raise AssertionError(f"CR line ending present: {path.name}")
    if not data.endswith(b"\n"):
        raise AssertionError(f"Missing final newline: {path.name}")

def validate_zip(path, expected_names):
    with zipfile.ZipFile(path, "r") as zf:
        if zf.comment != b"":
            raise AssertionError("Archive comment present")
        infos = zf.infolist()
        names = [i.filename for i in infos]
        if names != sorted(expected_names):
            raise AssertionError("ZIP entry order or membership mismatch")
        if zf.testzip() is not None:
            raise AssertionError("CRC validation failed")
        for info in infos:
            if info.compress_type != zipfile.ZIP_STORED:
                raise AssertionError(f"Non-stored member: {info.filename}")
            if info.date_time != (1980,1,1,0,0,0):
                raise AssertionError(f"Timestamp mismatch: {info.filename}")
            if info.comment != b"" or info.extra != b"":
                raise AssertionError(f"Member comment/extra present: {info.filename}")
            if info.filename.endswith("/"):
                raise AssertionError("Directory entry present")
            perms = (info.external_attr >> 16) & 0o777
            if perms != 0o644:
                raise AssertionError(f"Permission mismatch: {info.filename}: {oct(perms)}")
    return 0

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--package-dir", default=".")
    ap.add_argument("--run1")
    ap.add_argument("--run2")
    args = ap.parse_args()
    p = Path(args.package_dir)

    canonical = json.loads((p/"01_canonical_input.json").read_text(encoding="utf-8"))
    rules = json.loads((p/"03_rule_configuration.json").read_text(encoding="utf-8"))
    stored = json.loads((p/"04_gate_results.json").read_text(encoding="utf-8"))
    audit = json.loads((p/"06_audit_record.json").read_text(encoding="utf-8"))
    manifest = json.loads((p/"07_manifest.json").read_text(encoding="utf-8"))

    required = rules["required_fields"]
    normalized = [normalize(r, required, i+1) for i, r in enumerate(canonical["records"])]
    derived = []
    for n in normalized:
        state, reasons, transitions = evaluate(n)
        derived.append((n["sample_id"], state, reasons, transitions))

    stored_lookup = {r["sample_id"]: r for r in stored["results"]}
    for sample_id, state, reasons, transitions in derived:
        r = stored_lookup[sample_id]
        assert r["assigned_state"] == state
        assert r["triggered_conditions"] == reasons
        assert r["state_transition_chain"] == transitions

    counts = Counter(state for _, state, _, _ in derived)
    aggregate = "HALT" if counts["HALT"] else ("REVIEW" if counts["REVIEW"] else "PASS")
    assert stored["aggregate_state"] == aggregate
    assert stored["state_totals"] == {"HALT":counts["HALT"], "PASS":counts["PASS"], "REVIEW":counts["REVIEW"]}

    # Independently regenerate normalized CSV content.
    sio = io.StringIO(newline="")
    fields = ["source_record_index","sample_id","site_id","pH","turbidity_ntu","lead_ppb","nitrate_mg_l","missing_fields"]
    w = csv.DictWriter(sio, fieldnames=fields, lineterminator="\n")
    w.writeheader()
    for n in normalized:
        row = dict(n)
        row["missing_fields"] = "|".join(n["missing_fields"])
        for k in ["pH","turbidity_ntu","lead_ppb","nitrate_mg_l"]:
            row[k] = "" if row[k] is None else f"{row[k]:.1f}"
        w.writerow(row)
    assert (p/"02_normalized_records.csv").read_text(encoding="utf-8") == sio.getvalue()

    # Audit chain and event sequencing.
    assert audit["append_only"] is True
    event_ids = [e["event_id"] for e in audit["events"]]
    assert event_ids == [f"EVT-{i:04d}" for i in range(1, len(event_ids)+1)]
    for sample_id, state, _, transitions in derived:
        assert audit["record_bindings"][sample_id]["state_transition_chain"] == transitions
        assert audit["record_bindings"][sample_id]["assigned_state"] == state

    # Manifest and text conformance.
    entries = manifest["entries"]
    for entry in entries:
        path = p / entry["path"]
        assert path.exists()
        assert path.stat().st_size == entry["size_bytes"]
        assert sha256_file(path) == entry["sha256"]
    assert "07_manifest.json" not in [e["path"] for e in entries]
    for path in p.iterdir():
        if path.is_file() and path.suffix.lower() in TEXT_SUFFIXES:
            validate_text(path)

    mismatch_count = 0
    crc_errors = 0
    replay_divergence = 0
    zip_hash = "NOT_PROVIDED"
    if args.run1 and args.run2:
        run1, run2 = Path(args.run1), Path(args.run2)
        b1, b2 = run1.read_bytes(), run2.read_bytes()
        mismatch_count = sum(a != b for a, b in zip(b1,b2)) + abs(len(b1)-len(b2))
        assert mismatch_count == 0
        assert sha256_bytes(b1) == sha256_bytes(b2)
        zip_hash = sha256_bytes(b1)
        expected_names = sorted([x.name for x in p.iterdir() if x.is_file()])
        crc_errors += validate_zip(run1, expected_names)
        crc_errors += validate_zip(run2, expected_names)
        replay_divergence = 0

    print("CLEANWATERWISE DEMO 07 REPLAY - PASS")
    print(f"Records evaluated: {len(derived)}")
    print(f"State totals: PASS={counts['PASS']} REVIEW={counts['REVIEW']} HALT={counts['HALT']}")
    print(f"Aggregate state: {aggregate}")
    print(f"Manifest entries verified: {len(entries)}/{len(entries)}")
    print(f"Run archive SHA-256: {zip_hash}")
    print(f"Byte-level mismatches: {mismatch_count}")
    print(f"CRC errors: {crc_errors}")
    print(f"Replay divergence: {replay_divergence}")
    print("FINAL STATUS: PASS - DETERMINISTIC_REPLAY_VERIFIED")
    return 0

if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"FINAL STATUS: FAIL - {type(exc).__name__}: {exc}", file=sys.stderr)
        raise

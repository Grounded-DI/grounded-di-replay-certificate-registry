#!/usr/bin/env python3
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import sys
import zipfile
from pathlib import Path
from typing import Any, Callable

PACKAGE_NAMES = [
    "01_canonical_input.json",
    "02_rule_configuration.json",
    "03_decision_results.json",
    "04_audit_record.json",
    "05_manifest.json",
    "06_verify_demo.py",
    "README.md",
]

SUPPORTED_OPERATORS: dict[str, Callable[[Any, Any], bool]] = {
    ">": lambda a, b: a > b,
    "<": lambda a, b: a < b,
    "==": lambda a, b: a == b,
}

def fail(message: str) -> None:
    raise RuntimeError(message)

def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))

def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def validate_configuration(config: dict[str, Any]) -> None:
    allowed_actions = config.get("allowed_actions")
    required_fields = config.get("required_fields")
    rules = config.get("rules")
    default_action = config.get("default_action")

    if not isinstance(allowed_actions, list) or set(allowed_actions) != {"FLY", "NO_FLY"}:
        fail("allowed_actions must contain exactly FLY and NO_FLY")
    if default_action not in allowed_actions:
        fail("Unknown default action")
    if not isinstance(required_fields, list) or not required_fields:
        fail("required_fields must be a non-empty list")
    if len(required_fields) != len(set(required_fields)):
        fail("Duplicate required field")
    if not isinstance(rules, list) or not rules:
        fail("rules must be a non-empty list")

    seen_rule_ids: set[str] = set()
    missing_rule_count = 0
    for rule in rules:
        rule_id = rule.get("rule_id")
        rule_type = rule.get("rule_type")
        operator = rule.get("operator")
        action = rule.get("action")
        if not isinstance(rule_id, str) or not rule_id or rule_id in seen_rule_ids:
            fail("Missing or duplicate rule_id")
        seen_rule_ids.add(rule_id)
        if action not in allowed_actions:
            fail(f"Unknown action in {rule_id}: {action}")
        if rule_type == "missing_required":
            missing_rule_count += 1
            if operator != "MISSING":
                fail(f"Unknown missing operator in {rule_id}: {operator}")
            if "field" in rule or "comparison_value" in rule:
                fail(f"Malformed missing rule: {rule_id}")
        elif rule_type == "comparison":
            field = rule.get("field")
            if field not in required_fields:
                fail(f"Unknown field in {rule_id}: {field}")
            if operator not in SUPPORTED_OPERATORS:
                fail(f"Unknown operator in {rule_id}: {operator}")
            if "comparison_value" not in rule:
                fail(f"Missing comparison value in {rule_id}")
        else:
            fail(f"Unknown rule type in {rule_id}: {rule_type}")
    if missing_rule_count != 1:
        fail("Exactly one missing_required rule is required")

def normalize_record(record: dict[str, Any], required_fields: list[str]) -> dict[str, Any]:
    unknown_fields = sorted(set(record) - set(required_fields))
    if unknown_fields:
        fail(f"Unknown input fields: {unknown_fields}")
    return {field: (None if record.get(field) == "MISSING" else record.get(field)) for field in required_fields}

def evaluate_record(record: dict[str, Any], config: dict[str, Any]) -> dict[str, Any]:
    validate_configuration(config)
    required_fields = config["required_fields"]
    normalized = normalize_record(record, required_fields)
    evaluations: list[dict[str, Any]] = []
    triggered: list[dict[str, Any]] = []

    for rule in config["rules"]:
        rule_type = rule["rule_type"]
        rule_id = rule["rule_id"]
        action = rule["action"]

        if rule_type == "missing_required":
            missing_fields = [field for field in required_fields if normalized.get(field) is None]
            matched = bool(missing_fields)
            evaluation = {
                "action": action,
                "matched": matched,
                "operator": rule["operator"],
                "rule_id": rule_id,
                "rule_type": rule_type,
            }
            if matched:
                evaluation["missing_fields"] = missing_fields
                for field in missing_fields:
                    triggered.append({
                        "action": action,
                        "explanation": rule["explanation_template"].format(field=field),
                        "field": field,
                        "operator": rule["operator"],
                        "rule_id": rule_id,
                    })
            evaluations.append(evaluation)
            continue

        field = rule["field"]
        observed = normalized.get(field)
        comparison_value = rule["comparison_value"]
        matched = False if observed is None else SUPPORTED_OPERATORS[rule["operator"]](observed, comparison_value)
        evaluation = {
            "action": action,
            "comparison_value": comparison_value,
            "field": field,
            "matched": matched,
            "observed": observed,
            "operator": rule["operator"],
            "rule_id": rule_id,
            "rule_type": rule_type,
        }
        evaluations.append(evaluation)
        if matched:
            triggered.append({
                "action": action,
                "comparison_value": comparison_value,
                "explanation": rule["explanation_template"].format(
                    observed=observed,
                    comparison_value=comparison_value,
                ),
                "field": field,
                "observed": observed,
                "operator": rule["operator"],
                "rule_id": rule_id,
            })

    decisions = {item["action"] for item in triggered}
    if len(decisions) > 1:
        fail(f"Conflicting configured actions: {sorted(decisions)}")
    decision = next(iter(decisions)) if decisions else config["default_action"]
    if decision not in config["allowed_actions"]:
        fail(f"Unknown resulting action: {decision}")

    explanation = (
        "No configured blocking rule was triggered."
        if not triggered
        else " | ".join(item["explanation"] for item in triggered)
    )
    transitions = [
        "RECEIVED",
        "NORMALIZED",
        "RULES_EVALUATED",
        "DECISION_ASSIGNED",
        "AUDIT_BOUND",
    ]
    if decision == "NO_FLY":
        transitions.append("RELEASE_BLOCKED")

    return {
        "decision": decision,
        "decision_explanation": explanation,
        "mission_id": normalized["mission_id"],
        "normalized_record": normalized,
        "rule_evaluations": evaluations,
        "transition_chain": transitions,
        "triggered_rules": triggered,
    }

def verify_manifest(package_dir: Path) -> int:
    manifest = load_json(package_dir / "05_manifest.json")
    if manifest.get("self_reference_policy") != "05_manifest.json is intentionally excluded from its own hash ledger; the containing archive hash binds the manifest.":
        fail("Manifest self-reference policy mismatch")
    entries = manifest.get("entries")
    if not isinstance(entries, list):
        fail("Manifest entries missing")
    expected_names = sorted(name for name in PACKAGE_NAMES if name != "05_manifest.json")
    actual_names = sorted(item.get("filename") for item in entries)
    if actual_names != expected_names:
        fail("Manifest filename set mismatch")
    for item in entries:
        path = package_dir / item["filename"]
        data = path.read_bytes()
        if len(data) != item["size_bytes"]:
            fail(f"Manifest size mismatch: {item['filename']}")
        if sha256_bytes(data) != item["sha256"]:
            fail(f"Manifest hash mismatch: {item['filename']}")
    return len(entries)

def verify_zip_structure(path: Path) -> tuple[list[str], int]:
    crc_errors = 0
    with zipfile.ZipFile(path, "r") as archive:
        names = archive.namelist()
        if names != sorted(PACKAGE_NAMES):
            fail(f"ZIP member order or set mismatch: {path.name}")
        if archive.comment != b"":
            fail(f"ZIP archive comment present: {path.name}")
        bad = archive.testzip()
        if bad is not None:
            crc_errors += 1
        for info in archive.infolist():
            if info.is_dir():
                fail(f"Directory entry present: {info.filename}")
            if info.compress_type != zipfile.ZIP_STORED:
                fail(f"Compression mismatch: {info.filename}")
            if info.date_time != (1980, 1, 1, 0, 0, 0):
                fail(f"Timestamp mismatch: {info.filename}")
            if ((info.external_attr >> 16) & 0o777) != 0o644:
                fail(f"Permission mismatch: {info.filename}")
            if info.comment != b"":
                fail(f"Member comment present: {info.filename}")
            if info.extra != b"":
                fail(f"Extra field present: {info.filename}")
            data = archive.read(info.filename)
            if data.startswith(b"\xef\xbb\xbf"):
                fail(f"UTF-8 BOM present: {info.filename}")
            if b"\r" in data:
                fail(f"Non-LF line ending present: {info.filename}")
            if not data.endswith(b"\n"):
                fail(f"Final newline missing: {info.filename}")
        return names, crc_errors

def extract_member_map(path: Path) -> dict[str, bytes]:
    with zipfile.ZipFile(path, "r") as archive:
        return {name: archive.read(name) for name in archive.namelist()}

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--package-dir", required=True)
    parser.add_argument("--run1", required=True)
    parser.add_argument("--run2", required=True)
    args = parser.parse_args()

    package_dir = Path(args.package_dir)
    run1 = Path(args.run1)
    run2 = Path(args.run2)

    for name in PACKAGE_NAMES:
        if not (package_dir / name).is_file():
            fail(f"Missing package file: {name}")

    canonical = load_json(package_dir / "01_canonical_input.json")
    config = load_json(package_dir / "02_rule_configuration.json")
    stored_results = load_json(package_dir / "03_decision_results.json")
    audit = load_json(package_dir / "04_audit_record.json")
    validate_configuration(config)

    records = canonical.get("records")
    expected_results = canonical.get("expected_results")
    if not isinstance(records, list) or not isinstance(expected_results, list):
        fail("Canonical records or expected results missing")

    record_ids = [item.get("mission_id") for item in records]
    if len(record_ids) != len(set(record_ids)):
        fail("Duplicate canonical mission_id")
    expected_ids = [item.get("mission_id") for item in expected_results]
    if len(expected_ids) != len(set(expected_ids)):
        fail("Duplicate expected mission_id")
    if set(record_ids) != set(expected_ids):
        fail("Canonical and expected mission ID sets differ")

    computed = [evaluate_record(record, config) for record in records]
    computed_map = {item["mission_id"]: item for item in computed}
    expected_map = {item["mission_id"]: item for item in expected_results}

    mismatches = 0
    for mission_id in record_ids:
        observed = computed_map[mission_id]
        expected = expected_map[mission_id]
        observed_rule_ids = [item["rule_id"] for item in observed["triggered_rules"]]
        if observed["decision"] != expected["expected_decision"]:
            mismatches += 1
        if observed_rule_ids != expected["expected_triggered_rule_ids"]:
            mismatches += 1
    if mismatches:
        fail(f"Expected-result mismatches: {mismatches}")

    totals = {"FLY": 0, "NO_FLY": 0}
    for item in computed:
        totals[item["decision"]] += 1
    if totals != canonical.get("expected_totals"):
        fail(f"Decision total mismatch: {totals}")

    stored_decisions = stored_results.get("decisions")
    if not isinstance(stored_decisions, list):
        fail("Stored decisions missing")
    stored_ids = [item.get("mission_id") for item in stored_decisions]
    if len(stored_ids) != len(set(stored_ids)):
        fail("Duplicate stored mission_id")
    if set(stored_ids) != set(record_ids):
        fail("Stored and canonical mission ID sets differ")
    if stored_results.get("decision_totals") != totals:
        fail("Stored decision totals mismatch")

    stored_map = {item["mission_id"]: item for item in stored_decisions}
    for mission_id, item in computed_map.items():
        stored = stored_map[mission_id]
        if stored.get("decision") != item["decision"]:
            fail(f"Stored decision mismatch: {mission_id}")
        if stored.get("decision_explanation") != item["decision_explanation"]:
            fail(f"Stored explanation mismatch: {mission_id}")
        if stored.get("normalized_record") != item["normalized_record"]:
            fail(f"Stored normalization mismatch: {mission_id}")
        if stored.get("triggered_rules") != item["triggered_rules"]:
            fail(f"Stored trigger mismatch: {mission_id}")

    if audit.get("append_only") is not True:
        fail("Audit append_only flag missing")
    mission_audits = audit.get("mission_audits")
    events = audit.get("events")
    if not isinstance(mission_audits, list) or not isinstance(events, list):
        fail("Audit records or events missing")
    if audit.get("event_count") != len(events):
        fail("Audit event_count mismatch")
    event_ids = [event.get("event_id") for event in events]
    expected_event_ids = [f"EVT-{index:04d}" for index in range(1, len(events) + 1)]
    if event_ids != expected_event_ids:
        fail("Audit event sequence mismatch")
    audit_ids = [item.get("mission_id") for item in mission_audits]
    if len(audit_ids) != len(set(audit_ids)) or set(audit_ids) != set(record_ids):
        fail("Audit mission ID mismatch")

    audit_map = {item["mission_id"]: item for item in mission_audits}
    for mission_id, item in computed_map.items():
        audit_item = audit_map[mission_id]
        if audit_item.get("normalized_record") != item["normalized_record"]:
            fail(f"Audit normalization mismatch: {mission_id}")
        if audit_item.get("evaluated_rules") != item["rule_evaluations"]:
            fail(f"Audit rule evaluation mismatch: {mission_id}")
        if audit_item.get("triggered_rules") != item["triggered_rules"]:
            fail(f"Audit triggered-rule mismatch: {mission_id}")
        if audit_item.get("final_decision") != item["decision"]:
            fail(f"Audit decision mismatch: {mission_id}")
        if audit_item.get("decision_explanation") != item["decision_explanation"]:
            fail(f"Audit explanation mismatch: {mission_id}")
        if audit_item.get("transition_chain") != item["transition_chain"]:
            fail(f"Audit transition mismatch: {mission_id}")
        event_stages = [event["stage"] for event in events if event["mission_id"] == mission_id]
        if event_stages != item["transition_chain"]:
            fail(f"Audit event-stage mismatch: {mission_id}")

    original_m008 = next(record for record in records if record["mission_id"] == "M-008")
    original_result = evaluate_record(original_m008, config)
    if original_result["decision"] != "FLY":
        fail("Configuration-binding original M-008 result is not FLY")
    modified_config = copy.deepcopy(config)
    candidate_rules = [
        rule for rule in modified_config["rules"]
        if rule.get("rule_type") == "comparison"
        and rule.get("field") == "wind_gust_kt"
        and rule.get("operator") == ">"
    ]
    if len(candidate_rules) != 1:
        fail("Configuration-binding wind rule not uniquely identifiable")
    candidate_rules[0]["comparison_value"] = 24
    modified_result = evaluate_record(original_m008, modified_config)
    if modified_result["decision"] != "NO_FLY":
        fail("Configuration-binding modified M-008 result is not NO_FLY")
    if any((package_dir / name).read_bytes() != (package_dir / name).read_bytes() for name in PACKAGE_NAMES):
        fail("Packaged artifact changed during self-test")

    manifest_count = verify_manifest(package_dir)
    _, crc1 = verify_zip_structure(run1)
    _, crc2 = verify_zip_structure(run2)
    crc_errors = crc1 + crc2

    run1_bytes = run1.read_bytes()
    run2_bytes = run2.read_bytes()
    byte_mismatches = sum(a != b for a, b in zip(run1_bytes, run2_bytes)) + abs(len(run1_bytes) - len(run2_bytes))
    if run1_bytes != run2_bytes:
        fail(f"Run archives differ: {byte_mismatches} byte mismatches")

    members1 = extract_member_map(run1)
    members2 = extract_member_map(run2)
    if members1 != members2:
        fail("Internal archive artifacts differ")
    for name in PACKAGE_NAMES:
        if members1[name] != (package_dir / name).read_bytes():
            fail(f"Archive/package mismatch: {name}")

    print("FLIGHTGATE DEMO 008 REPLAY - PASS")
    print(f"Missions evaluated: {len(records)}")
    print(f"Decision totals: FLY={totals['FLY']} NO_FLY={totals['NO_FLY']}")
    print("CONFIGURATION_BINDING_TEST: PASS")
    print(f"Manifest entries verified: {manifest_count}/{manifest_count}")
    print(f"Run archive SHA-256: {sha256_file(run1)}")
    print(f"Byte-level mismatches: {byte_mismatches}")
    print(f"CRC errors: {crc_errors}")
    print("Replay divergence: 0")
    print("FINAL STATUS: PASS - CONFIGURATION_DRIVEN_REPLAY_VERIFIED")
    return 0

if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(1)

# Grounded DI OS Demo 008 — Repeatable Fly / No-Fly Decisions

> A synthetic ten-mission preflight rule-execution package with configuration-driven FLY / NO_FLY decisions, audit-linked explanations, and byte-identical deterministic replay.

## 1. What was tested

Demo 008 tests whether Grounded DI OS can normalize ten structured mission records, execute a disclosed machine-readable rule configuration, identify every blocking rule, produce transparent FLY or NO_FLY decisions, bind each decision to an audit record, and reproduce the seven-file package byte-for-byte.

## 2. Five-input decision model

Each mission uses five decision inputs:

- wind gust;
- visibility;
- battery percentage;
- precipitation;
- geofence clearance.

The verifier loads required fields, rule types, fields, operators, comparison values, actions, and the default action directly from `02_rule_configuration.json`. Unknown rule types, fields, operators, or actions fail closed.

Configured blocking rules:

- missing required field;
- wind gust greater than 25 kt;
- visibility below 3.0 mi;
- battery below 30 percent;
- precipitation equal to `HEAVY`;
- geofence clearance equal to `false`.

If no blocking rule is triggered, the configured default action is `FLY`.

## 3. Ten-mission result

| Mission | Decision | Basis |
|---|---|---|
| M-001 | FLY | No blocking rule |
| M-002 | NO_FLY | Wind gust |
| M-003 | NO_FLY | Visibility |
| M-004 | NO_FLY | Battery |
| M-005 | NO_FLY | Heavy precipitation |
| M-006 | NO_FLY | Geofence |
| M-007 | FLY | No blocking rule |
| M-008 | FLY | Exact boundary values pass |
| M-009 | NO_FLY | Missing battery field |
| M-010 | FLY | No blocking rule |

Totals: **FLY 4 · NO_FLY 6**

## 4. Configuration-binding test

The verifier:

1. evaluates M-008 under the packaged configuration and confirms `FLY`;
2. changes the in-memory wind comparison value from 25 to 24;
3. re-evaluates M-008 and confirms `NO_FLY`;
4. leaves every packaged artifact unchanged.

Expected verifier output:

`CONFIGURATION_BINDING_TEST: PASS`

## 5. Replay result

The two release archives use:

- lexicographic entry order;
- `ZIP_STORED`;
- timestamp `1980-01-01 00:00:00`;
- permissions `0644`;
- no comments;
- no extra fields;
- UTF-8 without BOM;
- LF line endings;
- stable sorted JSON.

The final verification report outside the archives records the matching archive SHA-256, zero byte mismatches, zero CRC errors, manifest verification, zero replay divergence, and verifier exit code 0.

## 6. What Grounded DI OS demonstrated

- canonical record normalization;
- configuration-driven rule execution;
- explicit boundary handling;
- multiple-trigger reporting;
- transparent binary decisions;
- record-level audit binding;
- fail-closed handling of unknown configuration elements;
- deterministic packaging and replay.

## 7. What was not claimed

- No aviation regulation or standard is asserted.
- No aircraft or mission is operationally authorized.
- No real flight data is evaluated.
- No weather forecast is generated.
- No predictive model is used.
- No safety certification is claimed.
- No external or independent verification is claimed.
- The demo certifies fixed-rule execution, configuration binding, decision traceability, artifact integrity, and replay reproducibility only.

## 8. Artifact index

1. `01_canonical_input.json`
2. `02_rule_configuration.json`
3. `03_decision_results.json`
4. `04_audit_record.json`
5. `05_manifest.json`
6. `06_verify_demo.py`
7. `README.md`

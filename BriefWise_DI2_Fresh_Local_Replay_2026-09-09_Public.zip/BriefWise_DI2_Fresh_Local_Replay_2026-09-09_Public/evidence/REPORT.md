## STATUS

VERIFIED — fresh verification of the supplied `synthetic-matter-001` bundle associated with the expected hash.

## LOCAL KERNEL RESULT

Local BriefWise kernel 0.2.0 freshly reproduced `FILING_READY` and the synthetic `FILING` authorization. The final authorization event was regenerated from its preceding event state in an in-memory copy; the resulting complete matter matched the original. Authorization was revalidated and the export manifest freshly regenerated.

## SHA-256

Expected: `aa66baca6feaa5dc17aff300ded2f10591cefcdb7b6044e106741921273f0daf`

Regenerated: `aa66baca6feaa5dc17aff300ded2f10591cefcdb7b6044e106741921273f0daf`

Match: TRUE

## CANONICAL BYTES

Identical: TRUE

Serialization: `BW-JCS-NFC-LF-1`.

## BINDING VERIFICATION

- Matter state: PASS
- Committed content: PASS
- Evaluation: PASS
- Gate results: PASS
- Rule pack: PASS
- Capability profile: PASS
- Source snapshot records: PASS
- Event-chain tip and event count: PASS
- Authorization result: PASS
- Authorization/export manifest: PASS
- Replay certificate: PASS

## EVENT CHAIN

Verified: TRUE

Event count: 9

Chain tip: `8177186d55fda39abf989593b87bdb0bca5ffc8a63fdd9e87378fb79104973d3`

## NEGATIVE CONTROL

Tamper rejected: TRUE

Exact rejection reason: `replay verification failed: stored evaluation diverges from fresh kernel evaluation`

## ORIGINAL STATE

Unchanged: TRUE — all five original bundle files were checked byte for byte and independently rehashed.

Reverification: PASS

## LIMITATIONS

- Scope is the supplied saved bundle, not a separately authenticated current native-app database.
- Same local rule implementation; no independently implemented legal evaluator was used.
- Underlying original source bytes are absent from this bundle: UNVERIFIED. The source snapshot record bindings passed.
- Historical authorship and external authorization provenance: UNVERIFIED.
- The matter and rule pack are synthetic; `release_capable` is false. No claim of legal correctness, real-world filing permission, identical model generation, or hidden-model-reasoning replay.

## FINAL CLASSIFICATION

VERIFIED — fresh local deterministic kernel replay, bound authorization/export reproduction, and tamper rejection for the specified synthetic snapshot.

Regenerated identity, evaluation, certificate, authorization summary, export manifest, and execution provenance are saved beside this report.

#!/usr/bin/env python3
"""Read-only integrity and event-chain checker for this fixed synthetic snapshot.
Does not execute the BriefWise evaluator or establish source authenticity.
"""
from pathlib import Path
import hashlib, json, unicodedata
root=Path(__file__).resolve().parent
H=lambda b:hashlib.sha256(b).hexdigest()
def require(ok,label):
    if not ok: raise ValueError(label)
def norm(v):
    if isinstance(v,str): return unicodedata.normalize('NFC',v.replace('\r\n','\n').replace('\r','\n'))
    if isinstance(v,list): return [norm(x) for x in v]
    if isinstance(v,dict):
        pairs=[(norm(k),norm(x)) for k,x in v.items()]
        require(len({k for k,x in pairs})==len(pairs),'duplicate normalized key')
        return dict(pairs)
    require(not isinstance(v,float),'floating-point input unsupported')
    return v
def canonical(v): return json.dumps(norm(v),sort_keys=True,ensure_ascii=False,separators=(',',':')).encode('utf-8')
def main():
    inventory={}
    for line in (root/'SHA256SUMS.txt').read_text().splitlines():
        digest,name=line.split('  ',1)
        require(name not in inventory,'duplicate inventory entry')
        p=root/name
        require(not p.is_symlink() and p.resolve().is_relative_to(root),'unsafe inventory path')
        require(H(p.read_bytes())==digest,'file checksum: '+name)
        inventory[name]=digest
    actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p.name!='SHA256SUMS.txt'}
    require(actual==set(inventory),'file set differs from inventory')
    e=root/'evidence'; b=root/'original-bundle'
    identity=(e/'regenerated-replay-identity.json').read_bytes()
    require(H(identity)=='aa66baca6feaa5dc17aff300ded2f10591cefcdb7b6044e106741921273f0daf','expected replay identity')
    for a,z in [('regenerated-replay-identity.json','replay-identity.json'),('regenerated-replay-certificate.json','replay-certificate.json'),('regenerated-export-manifest.json','manifest.json')]:
        require((e/a).read_bytes()==(b/z).read_bytes(),'byte identity: '+a)
    for name,digest in json.loads((e/'original-file-hashes.json').read_text()).items():
        require(H((b/name).read_bytes())==digest,'original bundle: '+name)
    matter=json.loads((b/'matter.json').read_text()); tip='GENESIS'
    for i,event in enumerate(matter['events'],1):
        require(event['sequence']==i,'event sequence')
        require(event['prior_event_hash']==tip,'prior event hash')
        body=dict(event); body['event_hash']=''
        require(H(canonical(body))==event['event_hash'],'event hash '+str(i))
        tip=event['event_hash']
    replay=json.loads(identity)
    require(len(matter['events'])==replay['event_count']==9,'event count')
    require(tip==replay['event_chain_tip'],'chain tip binding')
    print('PASS: public file checksums, exact replay artifact bytes, original bundle hashes, and 9-event chain.')
    print('Fresh kernel evaluation: NOT EXECUTED by this checker. See recorded execution evidence.')
if __name__=='__main__':
    try: main()
    except Exception as exc:
        print('FAIL:',exc)
        raise SystemExit(1)

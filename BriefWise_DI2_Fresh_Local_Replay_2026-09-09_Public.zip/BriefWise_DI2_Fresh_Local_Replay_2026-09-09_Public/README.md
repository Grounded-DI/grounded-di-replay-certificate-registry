# BriefWise DI² — Fresh Local Deterministic Replay

FastPath · 9 September 2026 · synthetic-matter-001 · local kernel 0.2.0

A fresh local invocation of the BriefWise kernel reproduced the saved synthetic matter's controlled state, authorization result, canonical replay identity, and export-manifest bindings. The complete nine-event chain passed verification. An in-memory committed-content alteration was rejected; the untouched original passed again.

**Replay identity SHA-256:**

`aa66baca6feaa5dc17aff300ded2f10591cefcdb7b6044e106741921273f0daf`

**Serialization:** `BW-JCS-NFC-LF-1`  
**Classification:** VERIFIED — FRESH LOCAL REPLAY, within the recorded scope. External independent verification is UNVERIFIED.

## Read the evidence

- [Execution report](evidence/REPORT.md) and [machine-readable results](evidence/verification.json).
- [Regenerated replay certificate](evidence/regenerated-replay-certificate.json), [identity](evidence/regenerated-replay-identity.json), [evaluation](evidence/fresh-evaluation.json), [authorization summary](evidence/fresh-authorization-summary.json), and [export manifest](evidence/regenerated-export-manifest.json).
- [Public execution provenance](evidence/execution-provenance.json) records kernel source hashes and the original verification harness hash.
- `original-bundle/` contains the exact synthetic matter, original identity, certificate, export manifest, and original README.
- [Publication notes](PUBLICATION_NOTES.md) disclose the single private-path redaction and checksum handling.

## Check this download

After extracting, run `python3 verify_package.py` from this directory. Python 3 is required; no network, API key, application installation, or write access is needed. The checker rehashes all public files, checks exact identity/certificate/manifest byte matches, and independently recomputes the nine-event hash chain for this snapshot. It exits nonzero on a mismatch.

**This package checker does not execute the BriefWise kernel or independently regenerate legal rules.** Fresh kernel execution is the separately recorded local test in the report. Repeating that full test requires the matching BriefWise kernel and export implementation; their source and binaries are not bundled here. Checksums establish consistency relative to the supplied inventory, not publisher identity or a digital signature.

## Method and limits

The local test freshly evaluated the saved matter using the existing rule implementation. In an in-memory clone it reconstructed the predecessor of the last authorization event, reran authorization issuance, matched the resulting complete matter, revalidated authorization, and regenerated the export manifest. A committed-content mutation was rejected with: `replay verification failed: stored evaluation diverges from fresh kernel evaluation`.

The state label `FILING_READY` and authorization kind `FILING` are synthetic kernel outputs. The profile has `release_capable=false`. The committed sample text is `TestTest`, imported manually. This is not a live model-generation experiment or a claim of real legal filing readiness.

Underlying source bytes are absent; source snapshot record bindings were verified, while underlying source authenticity remains UNVERIFIED. Historical authorship, external authorization provenance, and the native app's current live storage are not authenticated by this package. No independent legal evaluator, legal correctness, identical model generation, hidden reasoning replay, universal determinism, or third-party certification is claimed.

Registry destination: https://github.com/Grounded-DI/grounded-di-replay-certificate-registry

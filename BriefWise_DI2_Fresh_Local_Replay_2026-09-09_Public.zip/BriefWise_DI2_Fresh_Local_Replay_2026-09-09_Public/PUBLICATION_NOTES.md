# Public copy and privacy review

This package contains synthetic evidence, not a client matter. The original local files were not modified.

## Documented changes

- `evidence/execution-provenance.json`: replaced the personal absolute Mac directory in `sourceBundle` with `original-bundle`. The file was reserialized with indentation and a final newline. Its public-file hash therefore differs from the original.
- The supplied `SHA256SUMS.txt` is preserved byte-for-byte as `evidence/ORIGINAL_SHA256SUMS.txt`. It describes the original ten-file evidence set and must not be used as the public package checksum inventory. Its provenance hash refers to the unredacted original, which is not included.
- The other eight supplied files are copied without byte changes.
- All five original synthetic bundle files are included without byte changes. No canonical evidence was redacted or normalized.
- Root `SHA256SUMS.txt` is newly generated for every public package file except itself. The outer ZIP has its own separate checksum.

## Excluded

Personal directory paths, API keys, account credentials, application configuration, database dumps, backups, browser sessions, screenshots, installers, and unrelated matters are not included. Kernel implementation source and binaries are not included. No new license for that implementation is granted by this evidence publication.

The included authorization reference is a synthetic evidence identifier, not an API credential or real-world filing permission. Privacy review combines content inspection and pattern scanning; it is not an external security certification.

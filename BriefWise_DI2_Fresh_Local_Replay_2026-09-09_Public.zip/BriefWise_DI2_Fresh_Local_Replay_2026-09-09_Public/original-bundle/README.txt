BriefWise DI2 replay bundle
Canonical JSON files use BW-JCS-NFC-LF-1.
Reopen trusted state, regenerate replay-identity.json, recompute SHA-256, and compare every certificate binding.
A stored PASS or copied hash is not replay verification.

# Synthetic flood to delivery replay

From run/: `sha256sum -c FROZEN.sha256`; `python3 -B producer.py ../new-a`; `python3 -B producer.py ../new-b`; `python3 -B checker.py ../new-a`; `python3 -B checker.py ../new-b`; `python3 -B -m unittest -v test_controls`. Compare each result against expected.json and directly against the corresponding other output.

The original execution output is transcribed from the command tool's captured response into initial_execution.log; it is not a direct process redirection. Both processes and checker share the specification, fixtures, Python JSON and SHA-256, and host. The checker does not import the producer. Seven binds six and is not independent verification. Fictional scenario; not emergency guidance or real-world prediction.

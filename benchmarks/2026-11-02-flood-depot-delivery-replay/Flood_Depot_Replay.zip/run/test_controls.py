import unittest,json,copy,tempfile,pathlib,hashlib,shutil
import producer,checker
P=pathlib.Path(__file__).parent
class Controls(unittest.TestCase):
 def setUp(self):self.x=json.loads((P/'contract.json').read_text())
 def test_road_closed(self):self.x['roads']['east']['water']=50;self.assertEqual(producer.build(self.x)[2]['east'],'CLOSED')
 def test_unreachable(self):self.x['roads']['north']['water']=40;r=producer.build(self.x);self.assertIsNone(r[3]['school']);self.assertEqual(r[4]['school'],0)
 def test_capacity(self):r=producer.build(self.x);self.assertEqual(r[4],{'clinic':5,'shelter':0,'school':3});self.assertEqual(sum(r[4].values()),8)
 def test_missing_unit(self):del self.x['units']['water'];self.assertRaises(ValueError,producer.build,self.x)
 def test_legitimate_change(self):self.x['capacity']=11;r=producer.build(self.x);self.assertEqual(r[4]['school'],6);self.assertEqual(r[5]['delivered'],11)
 def test_tampered_stage(self):
  with tempfile.TemporaryDirectory() as t:
   p=pathlib.Path(t)
   for i,v in enumerate(producer.build(self.x),1):(p/f'{i:02}.json').write_bytes(producer.enc(v))
   (p/'03.json').write_bytes(b'{}\n');self.assertFalse(checker.check(p))
 def test_rehash_wrong_result(self):
  with tempfile.TemporaryDirectory() as t:
   p=pathlib.Path(t);r=producer.build(self.x);r[5]['delivered']=999;r[6]['sha256']['06.json']=hashlib.sha256(producer.enc(r[5])).hexdigest()
   for i,v in enumerate(r,1):(p/f'{i:02}.json').write_bytes(producer.enc(v))
   self.assertFalse(checker.check(p))
if __name__=='__main__':unittest.main(verbosity=2)

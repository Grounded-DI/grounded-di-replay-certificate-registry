import json,hashlib,pathlib,sys
P=pathlib.Path(__file__).parent
def enc(x):return (json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True)+'\n').encode()
def build(x):
 if x['units']!={'water':'cm','capacity':'units','demand':'units'} or set(x['roads'])!={'east','west','north'} or any(not isinstance(x['roads'][r][k],int) for r in x['roads'] for k in ['water','closure_at']) or not isinstance(x['capacity'],int) or x['capacity']<0:raise ValueError('invalid input')
 a={k:x[k] for k in ['units','roads','demands','capacity','priority']}; b={n:{'water':r['water'],'closure_at':r['closure_at']} for n,r in x['roads'].items()};c={n:('OPEN' if r['water']<r['closure_at'] else 'CLOSED') for n,r in x['roads'].items()};d={r['destination']:('depot-'+n if c[n]=='OPEN' else None) for n,r in x['roads'].items()}; remain=x['capacity'];e={}
 for n in x['priority']:
  amount=min(x['demands'][n],remain) if d[n] else 0;e[n]=amount;remain-=amount
 f={'delivered':sum(e.values()),'capacity':x['capacity'],'unmet':sum(x['demands'].values())-sum(e.values()),'scope':'synthetic demonstration'}
 stages=[a,b,c,d,e,f]; hashes={f'{i:02}.json':hashlib.sha256(enc(v)).hexdigest() for i,v in enumerate(stages,1)};return stages+[{'sha256':hashes}]
def main():
 x=json.loads((P/'contract.json').read_text());o=pathlib.Path(sys.argv[1]);o.mkdir();
 for i,v in enumerate(build(x),1):(o/f'{i:02}.json').write_bytes(enc(v))
if __name__=='__main__':main()

import json,hashlib,pathlib,sys
P=pathlib.Path(__file__).parent
def encode(x):return (json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True)+'\n').encode()
def check(out):
 x=json.loads((P/'contract.json').read_text());roads=x['roads'];openroads={k:('OPEN' if v['water']<v['closure_at'] else 'CLOSED') for k,v in roads.items()};routes={v['destination']:('depot-'+k if openroads[k]=='OPEN' else None) for k,v in roads.items()};available=x['capacity'];alloc={}
 for dest in x['priority']:
  alloc[dest]=min(available,x['demands'][dest]) if routes[dest] else 0;available-=alloc[dest]
 values=[{k:x[k] for k in ['units','roads','demands','capacity','priority']},{k:{'water':v['water'],'closure_at':v['closure_at']} for k,v in roads.items()},openroads,routes,alloc,{'delivered':sum(alloc.values()),'capacity':x['capacity'],'unmet':sum(x['demands'].values())-sum(alloc.values()),'scope':'synthetic demonstration'}];values.append({'sha256':{f'{i:02}.json':hashlib.sha256(encode(v)).hexdigest() for i,v in enumerate(values,1)}})
 return all((out/f'{i:02}.json').read_bytes()==encode(v) for i,v in enumerate(values,1)) and alloc==x['expected_deliveries'] and sum(alloc.values())==x['expected_total']
if __name__=='__main__':
 ok=check(pathlib.Path(sys.argv[1]));print('PASS' if ok else 'FAIL');sys.exit(0 if ok else 1)

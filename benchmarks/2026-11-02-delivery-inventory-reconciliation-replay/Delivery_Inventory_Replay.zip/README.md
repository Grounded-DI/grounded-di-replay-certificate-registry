# Delivery-to-inventory synthetic replay

Five fictional shipments test matching, a two-case short receipt, the wrong receiving destination, missing evidence, and duplicate receiver records. Only S1 reconciles: 10 supply cases. S2 has a known two-case shortfall relative to shipment and remains in review. S3, S4 and S5 have unknown reconciled receipt quantities: the available evidence does not establish an accepted receipt for those shipments.

## Reproduce

Python 3 and the standard library; `sha256sum` is required for frozen file checks. From a clean extraction, move the preserved `execution` directory to another name and run `python3 -B verify.py`. The script checks the frozen identities, runs two fresh processes and both checker invocations, executes seven controls, compares all seven output bytes and SHA-256 values to frozen expectations, and creates new `execution` logs. It exits nonzero when the recorded criteria fail. Do not remove the preserved execution record.

The source fixture and contract, expected hashes, independent expected-output preparation, producer, checker, and controls are bound by `src/FROZEN.sha256`. The baseline expectation was separately specified before the first pipeline execution; the freezer script is retained to expose its construction. `execution` contains outputs, commands, process outputs, comparisons, and outcomes from the original run. Review the scenario and control definitions in the contract and tests.

The checker independently recalculates all six stages and the commitment without importing the producer. It shares the written specification, fixture, canonical encoding, Python interpreter, SHA-256 and JSON libraries, and host; both implementations were developed in the same project. Boundary seven commits to boundaries 1–6 and is not independent verification. All inputs and receiver records are fictional and unauthenticated. An internally consistent receiver record is not proof that a physical delivery occurred. This is not emergency guidance, production readiness, external certification, or a universal model determinism claim.

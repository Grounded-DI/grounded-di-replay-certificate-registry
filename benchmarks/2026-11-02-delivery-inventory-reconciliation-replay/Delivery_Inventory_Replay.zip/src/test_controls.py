import unittest,json,copy,pathlib,tempfile,hashlib
import producer,checker
P=pathlib.Path(__file__).parent
class Controls(unittest.TestCase):
 def setUp(self):self.x=json.loads((P/'fixture.json').read_text())
 def status(self,expected):
  got=producer.evaluate(self.x)[4][0]['status'];print(json.dumps({'expected':expected,'actual':got,'assertion':got==expected},sort_keys=True));self.assertEqual(got,expected)
 def test_changed_shipment(self):self.x['shipments'][0]['shipped']=9;self.status('REVIEW_QUANTITY')
 def test_wrong_destination(self):self.x['receipts'][0]['destination']='wrong';self.status('REVIEW_DESTINATION')
 def test_missing_receiver(self):self.x['receipts'].pop(0);self.status('REVIEW_MISSING')
 def test_duplicate_record(self):r=copy.deepcopy(self.x['receipts'][0]);r['id']='R1b';self.x['receipts'].append(r);self.status('REVIEW_DUPLICATE')
 def test_missing_units(self):
  del self.x['unit']
  with self.assertRaisesRegex(ValueError,'invalid unit'):producer.evaluate(self.x)
  print(json.dumps({'expected':'REJECT validation','actual':'REJECT validation','assertion':True}))
 def save(self,p,values):
  for n,v in zip(producer.N,values):(p/n).write_bytes(producer.enc(v))
 def test_altered_intermediate(self):
  with tempfile.TemporaryDirectory() as tmp:
   p=pathlib.Path(tmp);self.save(p,producer.evaluate(self.x));(p/'04.json').write_bytes(b'{}\n');actual=checker.check(P/'fixture.json',p);print(json.dumps({'expected':'checker rejects','actual':'checker rejects' if not actual else 'checker accepts','assertion':not actual}));self.assertFalse(actual)
 def test_coherent_wrong_final(self):
  with tempfile.TemporaryDirectory() as tmp:
   p=pathlib.Path(tmp);v=producer.evaluate(self.x);v[5]['reconciled_quantity']=999;v[6]['artifacts']['06.json']=hashlib.sha256(producer.enc(v[5])).hexdigest();self.save(p,v);actual=checker.check(P/'fixture.json',p);print(json.dumps({'expected':'checker rejects','actual':'checker rejects' if not actual else 'checker accepts','assertion':not actual}));self.assertFalse(actual)
if __name__=='__main__':unittest.main(verbosity=2)

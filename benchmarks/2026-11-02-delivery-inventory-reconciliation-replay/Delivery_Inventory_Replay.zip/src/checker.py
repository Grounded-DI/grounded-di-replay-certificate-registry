import json,hashlib,pathlib,sys
names=[f'{i:02}.json' for i in range(1,8)]
def serial(x):return (json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False)+'\n').encode()
def recalculate(x):
 if x.get('unit')!='supply_case':raise ValueError('unit')
 ships=sorted(x['shipments'],key=lambda x:x['id']); recs=sorted(x['receipts'],key=lambda x:x['id'])
 stages=[{'unit':x['unit'],'shipments':ships},[{k:s[k] for k in ('id','destination','ordered','shipped')} for s in ships],{'unit':x['unit'],'receipts':recs}]; match=[];recon=[];counts={};unknown=[];total=0
 for s in ships:
  rr=[r for r in recs if r['shipment']==s['id']];n=len(rr);match.append({'shipment':s['id'],'receipt_ids':[r['id'] for r in rr],'status':{0:'MISSING',1:'UNIQUE'}.get(n,'DUPLICATE')});v={'shipment':s['id'],'status':'','reconciled_quantity':None,'received_minus_shipped':None,'inventory_delta':None}
  if n==0: status='REVIEW_MISSING'
  elif n>1:status='REVIEW_DUPLICATE'
  elif rr[0]['destination']!=s['destination']:status='REVIEW_DESTINATION'
  else:
   z=rr[0];v['received_minus_shipped']=z['received']-s['shipped'];v['inventory_delta']=z['inventory_after']-z['inventory_before'];status='REVIEW_QUANTITY'
   if s['ordered']==s['shipped'] and s['shipped']==z['received'] and z['received']==v['inventory_delta']:status='RECONCILED';v['reconciled_quantity']=z['received'];total+=z['received']
  v['status']=status;counts[status]=counts.get(status,0)+1
  if status!='RECONCILED':unknown.append(s['id'])
  recon.append(v)
 stages.extend([match,recon,{'counts':counts,'reconciled_quantity':total,'unknown_or_review_shipments':unknown,'limitation':'synthetic records do not prove physical delivery'}]);stages.append({'algorithm':'sha256','artifacts':{names[i]:hashlib.sha256(serial(z)).hexdigest() for i,z in enumerate(stages)}});return stages
def check(src,out):
 expected=recalculate(json.loads(pathlib.Path(src).read_text()));return all((pathlib.Path(out)/n).read_bytes()==serial(v) for n,v in zip(names,expected))
if __name__=='__main__':
 ok=check(sys.argv[1],sys.argv[2]);print('PASS' if ok else 'FAIL');sys.exit(0 if ok else 1)

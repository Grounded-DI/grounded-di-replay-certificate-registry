import sys,json,hashlib,pathlib
N=[f'{i:02}.json' for i in range(1,8)]
def enc(v):return (json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False)+'\n').encode()
def validate(x):
 if x.get('unit')!='supply_case':raise ValueError('invalid unit')
 for key,fields in [('shipments',['id','destination','ordered','shipped']),('receipts',['id','shipment','destination','received','inventory_before','inventory_after'])]:
  if not isinstance(x.get(key),list):raise ValueError('invalid records')
  ids=[]
  for r in x[key]:
   if not isinstance(r,dict) or any(k not in r for k in fields):raise ValueError('missing field')
   for k in fields:
    v=r[k]
    if k in ('id','destination','shipment'):
     if not isinstance(v,str) or not v:raise ValueError('invalid identifier')
    elif type(v)!=int or v<0:raise ValueError('invalid quantity')
   ids.append(r['id'])
  if len(set(ids))!=len(ids):raise ValueError('duplicate ids')
def evaluate(x):
 validate(x);ship=sorted(x['shipments'],key=lambda a:a['id']);receipts=sorted(x['receipts'],key=lambda a:a['id'])
 s1={'unit':x['unit'],'shipments':ship};s2=[{'id':s['id'],'destination':s['destination'],'ordered':s['ordered'],'shipped':s['shipped']} for s in ship];s3={'unit':x['unit'],'receipts':receipts};matches=[];results=[]
 for s in ship:
  group=[r for r in receipts if r['shipment']==s['id']];m={'shipment':s['id'],'receipt_ids':[r['id'] for r in group],'status':'MISSING' if len(group)==0 else 'UNIQUE' if len(group)==1 else 'DUPLICATE'};matches.append(m)
  v={'shipment':s['id'],'status':'','reconciled_quantity':None,'received_minus_shipped':None,'inventory_delta':None}
  if not group:v['status']='REVIEW_MISSING'
  elif len(group)>1:v['status']='REVIEW_DUPLICATE'
  elif group[0]['destination']!=s['destination']:v['status']='REVIEW_DESTINATION'
  else:
   r=group[0];v['received_minus_shipped']=r['received']-s['shipped'];v['inventory_delta']=r['inventory_after']-r['inventory_before'];v['status']='RECONCILED' if s['ordered']==s['shipped']==r['received']==v['inventory_delta'] else 'REVIEW_QUANTITY'
   if v['status']=='RECONCILED':v['reconciled_quantity']=r['received']
  results.append(v)
 counts={};
 for r in results:counts[r['status']]=counts.get(r['status'],0)+1
 final={'counts':counts,'reconciled_quantity':sum(r['reconciled_quantity'] or 0 for r in results),'unknown_or_review_shipments':[r['shipment'] for r in results if r['status']!='RECONCILED'],'limitation':'synthetic records do not prove physical delivery'}
 stages=[s1,s2,s3,matches,results,final];stages.append({'algorithm':'sha256','artifacts':{N[i]:hashlib.sha256(enc(v)).hexdigest() for i,v in enumerate(stages)}});return stages
def main():
 x=json.loads(pathlib.Path(sys.argv[1]).read_text());p=pathlib.Path(sys.argv[2]);stages=evaluate(x);p.mkdir()
 for n,v in zip(N,stages):(p/n).write_bytes(enc(v))
 print('PASS')
if __name__=='__main__':main()

import hashlib,pathlib,json,sys
p=pathlib.Path('.');h=json.loads((p/'expected_hashes.json').read_text());ok=True
for i in range(1,8):
 b=[(p/f'{name}/{i}.json').read_bytes() for name in ('expected','run1','run2')];hs=[hashlib.sha256(x).hexdigest() for x in b]; passed=b[0]==b[1]==b[2] and all(x==h[i-1] for x in hs);ok &= passed; print(f'boundary={i} direct_bytes_equal={b[0]==b[1]==b[2]} expected_sha256={h[i-1]} observed_run1={hs[1]} observed_run2={hs[2]} result={"PASS" if passed else "FAIL"}')
sys.exit(0 if ok else 1)

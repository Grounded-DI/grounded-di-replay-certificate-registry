# Synthetic delivery-to-cold-storage replay

Fixture: fictional supplies and conditions; 2–8 C, 0–60 minutes and all disposition rules are assumptions, not a safety standard. Baseline: 4 accepted, 10 held, 5 unknown. Shipment S6 demonstrates a plan without a receipt; duplicate S5 evidence is counted once. See CONTRACT.md and expected/.

Run in this directory with Python 3: `python3 producer.py fixture.json run1`, same for run2, `python3 checker.py fixture.json run1`, same for run2, `python3 compare.py`, `python3 controls.py`, `sha256sum -c SHA256SUMS.txt` before replacing recorded outputs. Outputs and logs preserve the original runs. The checker recalculates separately without importing producer code but shares the fixture, project specification, host, and Python standard library. The commitment is not an independent verification. Scope is fictional closed-world accounting, not an emergency plan or real safety assessment.

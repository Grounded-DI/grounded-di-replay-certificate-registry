import json,hashlib,pathlib
p=pathlib.Path(__file__).parent
F={'unit':'units','temperature_unit':'C','time_unit':'minutes','window':[0,60],'policy':{'minimum_C':2,'maximum_C':8},'shipments':[{ 'id':f'S{i}', 'destination':'clinic', 'quantity':q} for i,q in enumerate([4,3,2,5,2,3],1)],'receipts':[{'shipment':'S1','destination':'clinic','quantity':4},{'shipment':'S2','destination':'clinic','quantity':3},{'shipment':'S3','destination':'clinic','quantity':2},{'shipment':'S4','destination':'clinic','quantity':3},{'shipment':'S5','destination':'clinic','quantity':2},{'shipment':'S5','destination':'clinic','quantity':2}],'temperatures':[{'shipment':f'S{i}','start':0,'end':60,'C':c} for i,c in [(1,5),(2,9),(4,5),(5,5)]]}
R={'S1':'matched','S2':'matched','S3':'matched','S4':'matched','S5':'duplicate','S6':'missing'}
T={'S1':'within','S2':'violation','S3':'missing','S4':'within','S5':'within','S6':'missing'}
Q={'S1':{'known':4,'unknown':0},'S2':{'known':3,'unknown':0},'S3':{'known':2,'unknown':0},'S4':{'known':3,'unknown':2},'S5':{'known':2,'unknown':0},'S6':{'known':0,'unknown':3}}
D={'S1':{'accepted':4,'held':0,'unknown':0},'S2':{'accepted':0,'held':3,'unknown':0},'S3':{'accepted':0,'held':2,'unknown':0},'S4':{'accepted':0,'held':3,'unknown':2},'S5':{'accepted':0,'held':2,'unknown':0},'S6':{'accepted':0,'held':0,'unknown':3}}
O={'accepted':4,'held':10,'unknown':5,'unresolved':['S2:temperature_violation','S3:temperature_missing','S4:quantity_discrepancy','S5:duplicate_receipt','S6:receipt_missing']}
def enc(x):return (json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True)+'\n').encode()
(p/'fixture.json').write_bytes(enc(F)); h=[]
for i,x in enumerate([F,R,T,Q,D,O],1):
 b=enc(x);(p/'expected'/f'{i}.json').write_bytes(b);h.append(hashlib.sha256(b).hexdigest())
b=enc({'sha256':h});(p/'expected'/'7.json').write_bytes(b);h.append(hashlib.sha256(b).hexdigest());(p/'expected_hashes.json').write_bytes(enc(h))

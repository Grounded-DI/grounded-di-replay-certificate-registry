import json,sys,pathlib,hashlib

def verify(f,p):
 # Independent source-based evaluator; no producer imports.
 p=pathlib.Path(p); records=[json.loads((p/f'{i}.json').read_bytes()) for i in range(1,8)]
 if records[0]!=f:return False
 rs={};ts={};qs={};ds={};issues=[]
 for s in f['shipments']:
  key=s['id']; plan=s['quantity']; found=[r for r in f['receipts'] if r['shipment']==key]
  if not found: status='missing'; known=0;issues.append(key+':receipt_missing')
  elif len(found)>1: status='duplicate'; known=min([plan]+[r['quantity'] for r in found]);issues.append(key+':duplicate_receipt')
  elif found[0]['destination']!=s['destination']:status='wrong_destination';known=0;issues.append(key+':wrong_destination')
  else:
   status='matched';known=min(plan,found[0]['quantity'])
   if found[0]['quantity']!=plan:issues.append(key+':quantity_discrepancy')
  rs[key]=status; qs[key]={'known':known,'unknown':plan-known}
  series=sorted((o for o in f['temperatures'] if o['shipment']==key),key=lambda x:x['start']); coverage=[];viol=False
  for o in series: coverage.extend(range(o['start'],o['end']));viol=viol or o['C']<2 or o['C']>8
  temp='missing' if coverage!=list(range(60)) else 'violation' if viol else 'within';ts[key]=temp
  if status not in ('missing','wrong_destination') and temp!='within':issues.append(key+':temperature_'+temp)
  a=known if status=='matched' and found[0]['quantity']==plan and temp=='within' else 0
  ds[key]={'accepted':a,'held':known-a,'unknown':plan-known}
 outcome={k:sum(d[k] for d in ds.values()) for k in ('accepted','held','unknown')};outcome['unresolved']=sorted(issues)
 expected=[f,rs,ts,qs,ds,outcome]
 enc=lambda x:(json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True)+'\n').encode()
 raw=[(p/f'{i}.json').read_bytes() for i in range(1,7)]
 return raw==list(map(enc,expected)) and (p/'7.json').read_bytes()==enc({'sha256':[hashlib.sha256(b).hexdigest() for b in raw]})
if __name__=='__main__':
 try: ok=verify(json.loads(pathlib.Path(sys.argv[1]).read_text()),sys.argv[2])
 except (ValueError,KeyError,TypeError,OSError): ok=False
 print('CHECKER PASS' if ok else 'CHECKER REJECT');sys.exit(0 if ok else 1)

import sys,json,pathlib,hashlib

def calc(f):
 ids=[s['id'] for s in f['shipments']]; r={};t={};q={};d={}; reasons=[]
 if len(ids)!=len(set(ids)) or f['unit']!='units' or f['temperature_unit']!='C' or f['time_unit']!='minutes':raise ValueError('invalid input')
 if f['window']!=[0,60] or f['policy']!={'minimum_C':2,'maximum_C':8}:raise ValueError('unsupported fixture policy')
 for s in f['shipments']:
  name=s['id'];n=s['quantity'];rr=[x for x in f['receipts'] if x['shipment']==name]; tt=sorted([x for x in f['temperatures'] if x['shipment']==name],key=lambda x:x['start'])
  if type(n)!=int or n<0 or any(type(x['quantity'])!=int or x['quantity']<0 for x in rr):raise ValueError('invalid quantity')
  status='missing' if not rr else 'duplicate' if len(rr)>1 else 'matched' if rr[0]['destination']==s['destination'] else 'wrong_destination';r[name]=status
  if status in ('missing','wrong_destination'): known=0
  else:known=min(n,*(x['quantity'] for x in rr))
  unknown=n-known;q[name]={'known':known,'unknown':unknown}
  pos=0;bad=False;complete=True
  for x in tt:
   if any(type(x[k])!=int for k in ('start','end','C')) or not (0<=x['start']<x['end']<=60): raise ValueError('invalid observation')
   if x['start']!=pos:complete=False
   pos=x['end'];bad |= not (2<=x['C']<=8)
  if pos!=60:complete=False
  t[name]='missing' if not complete else 'violation' if bad else 'within'
  accepted=known if status=='matched' and rr[0]['quantity']==n and t[name]=='within' else 0
  d[name]={'accepted':accepted,'held':known-accepted,'unknown':unknown}
  if status in ('missing','wrong_destination','duplicate'):reasons.append(name+':'+{'missing':'receipt_missing','wrong_destination':'wrong_destination','duplicate':'duplicate_receipt'}[status])
  if status=='matched' and rr[0]['quantity']!=n:reasons.append(name+':quantity_discrepancy')
  if status not in ('missing','wrong_destination') and t[name]!='within':reasons.append(name+':temperature_'+t[name])
 if any(x['shipment'] not in ids for x in f['receipts']+f['temperatures']):raise ValueError('unrecognized shipment')
 out={k:sum(v[k] for v in d.values()) for k in ('accepted','held','unknown')};out['unresolved']=sorted(reasons)
 return [f,r,t,q,d,out]
def enc(x):return (json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True)+'\n').encode()
def main():
 f=json.loads(pathlib.Path(sys.argv[1]).read_text());out=pathlib.Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True);hashes=[]
 for i,x in enumerate(calc(f),1):
  b=enc(x);(out/f'{i}.json').write_bytes(b);hashes.append(hashlib.sha256(b).hexdigest())
 (out/'7.json').write_bytes(enc({'sha256':hashes}))
if __name__=='__main__': main()

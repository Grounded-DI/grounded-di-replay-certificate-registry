import json,unittest,tempfile,pathlib,subprocess,sys,copy,hashlib
ROOT=pathlib.Path(__file__).resolve().parent;BASE=json.loads((ROOT/'fixture.json').read_text())
class Controls(unittest.TestCase):
 def run_case(self,mutate):
  f=copy.deepcopy(BASE);mutate(f);tmp=tempfile.TemporaryDirectory();self.addCleanup(tmp.cleanup);p=pathlib.Path(tmp.name);src=p/'fixture.json';src.write_text(json.dumps(f));out=p/'out'
  a=subprocess.run([sys.executable,str(ROOT/'producer.py'),str(src),str(out)],capture_output=True,text=True);self.assertEqual(a.returncode,0,a.stdout+a.stderr)
  b=subprocess.run([sys.executable,str(ROOT/'checker.py'),str(src),str(out)],capture_output=True,text=True);self.assertEqual(b.returncode,0,b.stdout+b.stderr)
  return f,out
 def test_threshold_violation(self):
  f,p=self.run_case(lambda f:f['temperatures'][0].update(C=9));self.assertEqual(json.loads((p/'3.json').read_text())['S1'],'violation');self.assertEqual(json.loads((p/'5.json').read_text())['S1']['held'],4)
 def test_missing_temperature(self):
  f,p=self.run_case(lambda f:f['temperatures'].pop(0));self.assertEqual(json.loads((p/'3.json').read_text())['S1'],'missing');self.assertEqual(json.loads((p/'5.json').read_text())['S1']['held'],4)
 def test_changed_destination(self):
  f,p=self.run_case(lambda f:f['receipts'][0].update(destination='depot'));self.assertEqual(json.loads((p/'2.json').read_text())['S1'],'wrong_destination');self.assertEqual(json.loads((p/'5.json').read_text())['S1']['unknown'],4)
 def test_quantity_discrepancy(self):
  f,p=self.run_case(lambda f:f['receipts'][0].update(quantity=2));self.assertEqual(json.loads((p/'5.json').read_text())['S1'],{'accepted':0,'held':2,'unknown':2})
 def test_duplicate_receipt(self):
  f,p=self.run_case(lambda f:f['receipts'].append(copy.deepcopy(f['receipts'][0])));self.assertEqual(json.loads((p/'2.json').read_text())['S1'],'duplicate');self.assertEqual(json.loads((p/'5.json').read_text())['S1']['held'],4)
 def test_legitimate_change(self):
  def change(f):f['shipments'][0]['quantity']=5;f['receipts'][0]['quantity']=5
  f,p=self.run_case(change);self.assertEqual(json.loads((p/'6.json').read_text())['accepted'],5)
 def test_altered_intermediate(self):
  f,p=self.run_case(lambda f:None);(p/'3.json').write_text('{}\n');src=p.parent/'fixture.json';r=subprocess.run([sys.executable,str(ROOT/'checker.py'),str(src),str(p)],capture_output=True,text=True);self.assertEqual(r.returncode,1);self.assertEqual(r.stdout.strip(),'CHECKER REJECT')
 def test_wrong_rehashed(self):
  f,p=self.run_case(lambda f:None);v=json.loads((p/'6.json').read_text());v['accepted']=999;enc=lambda x:(json.dumps(x,sort_keys=True,separators=(',',':'))+'\n').encode();(p/'6.json').write_bytes(enc(v));h=[hashlib.sha256((p/f'{i}.json').read_bytes()).hexdigest() for i in range(1,7)];(p/'7.json').write_bytes(enc({'sha256':h}));r=subprocess.run([sys.executable,str(ROOT/'checker.py'),str(p.parent/'fixture.json'),str(p)],capture_output=True,text=True);self.assertEqual(r.returncode,1);self.assertEqual(r.stdout.strip(),'CHECKER REJECT')
if __name__=='__main__':unittest.main(verbosity=2)

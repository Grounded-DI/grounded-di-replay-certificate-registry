import hashlib,json,pathlib
r=pathlib.Path(__file__).resolve().parent
def enc(x):return (json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False)+'\n').encode('ascii')
def h(b):return hashlib.sha256(b).hexdigest()
artifact=b'Fictional package: lighthouse-1.0\n'; ah=h(artifact)
p={'version':'1','artifact_sha256':ah,'destination':'sandbox://releases/staging','builder':'fictional-builder','source':'fictional-source@v1','approver':'release-board','required_tests':['unit','integration']};pb=enc(p);ph=h(pb)
q={'candidate_id':'lighthouse-1.0','destination':p['destination']};ev={'provenance':{'builder':p['builder'],'source':p['source'],'artifact_sha256':ah},'tests':{'unit':'PASS','integration':'PASS'},'approval':{'candidate_id':q['candidate_id'],'destination':q['destination'],'artifact_sha256':ah,'policy_sha256':ph,'approver':p['approver']}}
for n,b in [('candidate.bin',artifact),('policy.json',pb),('request.json',enc(q)),('evidence.json',enc(ev))]:(r/'inputs'/n).write_bytes(b)
names=['01_request','02_identity','03_tests','04_approval','05_destination','06_decision','07_commitment']
expected=[{'candidate_id':q['candidate_id'],'destination':q['destination'],'malformed':False},{'actual_sha256':ah,'artifact_matches':True,'provenance_valid':True},{'required':p['required_tests'],'valid':True},{'valid':True},{'destination_allowed':True,'policy_unchanged':True},{'eligible':True,'reasons':[]}]
expected.append({'algorithm':'sha256','members':[{'name':names[i]+'.json','sha256':h(enc(v))} for i,v in enumerate(expected)]})
for n,v in zip(names,expected):(r/'expected'/(n+'.json')).write_bytes(enc(v))
controls={'artifact_changed':['artifact','provenance','approval'],'missing_provenance':['provenance'],'failed_test':['tests'],'missing_test':['tests'],'missing_approval':['approval'],'wrong_approval':['approval'],'destination_changed':['approval','destination'],'policy_changed':['policy'],'missing_field':['malformed_request','approval','destination'],'altered_decision':'checker rejects commitment and decision','coherent_wrong_decision':'checker rejects decision even with valid commitment'}
contract={'schema':'releasegate-alt-v1','artifact_sha256':ah,'policy_sha256':ph,'destination':p['destination'],'baseline':'eligible with empty reasons','policy':p,'encoding':'ASCII JSON, sorted keys, compact separators, escaped non-ASCII, no NaN, one LF','ordered_boundaries':names,'expected_sha256':{n:h(enc(v)) for n,v in zip(names,expected)},'control_outcomes':controls,'commands':['python3 -B src/run_suite.py OUTPUT_DIR'],'dependencies':'Python 3.11+ standard library','acceptance':'two fresh processes match all seven frozen files directly and by SHA-256; checker, 11 controls, and synthetic write checks all pass with no skips/errors','noncanonical':'stdout logs, process execution metadata, control specimens and evidence archive metadata; no live time or PID in canonical files','limits':'synthetic local model; no deployment or exactly-once claim'}
(r/'CONTRACT.json').write_bytes(enc(contract))
files=sorted(x for x in r.rglob('*') if x.is_file() and x.name!='FREEZE_SHA256.json')
(r/'FREEZE_SHA256.json').write_bytes(enc({str(x.relative_to(r)):h(x.read_bytes()) for x in files}))
print('FREEZE_COMPLETE',h((r/'CONTRACT.json').read_bytes()))

import copy,hashlib,json,os,pathlib,platform,shutil,subprocess,sys
from checker import check
from promote import promote
R=pathlib.Path(__file__).resolve().parents[1];O=pathlib.Path(sys.argv[1]).resolve();O.mkdir(parents=True,exist_ok=False)
def enc(x):return (json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False)+'\n').encode('ascii')
def put(p,x):p.write_bytes(enc(x))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
c=json.loads((R/'CONTRACT.json').read_bytes()); frozen=json.loads((R/'FREEZE_SHA256.json').read_bytes()); freeze_ok=all((R/n).is_file() and sha(R/n)==h for n,h in frozen.items()); checks=[];checks.append({'name':'frozen_files','pass':freeze_ok})
for name in ('A','B'):
 cmd=[sys.executable,'-B',str(R/'src/pipeline.py'),str(R),str(R/'inputs'),str(O/name)];p=subprocess.run(cmd,capture_output=True,text=True,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONHASHSEED=('101' if name=='A' else '202')));put(O/(name+'_process.json'),{'command':cmd,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr});checks.append({'name':'fresh_'+name,'pass':p.returncode==0})
for name,expected in c['expected_sha256'].items():
 a=O/'A'/(name+'.json');b=O/'B'/(name+'.json');baseline=R/'expected'/(name+'.json');checks.append({'name':name,'pass':a.read_bytes()==b.read_bytes()==baseline.read_bytes() and sha(a)==sha(b)==sha(baseline)==expected,'sha256_a':sha(a),'sha256_b':sha(b),'bytes_equal':a.read_bytes()==b.read_bytes()==baseline.read_bytes()})
for name in ('A','B'):
 v=check(R,R/'inputs',O/name);checks.append({'name':'checker_'+name,'pass':v['status']=='PASS' and v['expected_decision']=={'eligible':True,'reasons':[]},'result':v})
cases=list(c['control_outcomes']);results=[]
for name in cases:
 case=O/'cases'/name;shutil.copytree(R/'inputs',case);q=json.loads((case/'request.json').read_bytes());e=json.loads((case/'evidence.json').read_bytes());policy=json.loads((case/'policy.json').read_bytes())
 if name=='artifact_changed':(case/'candidate.bin').write_bytes(b'altered package\n')
 elif name=='missing_provenance':e.pop('provenance')
 elif name=='failed_test':e['tests']['unit']='FAIL'
 elif name=='missing_test':e['tests'].pop('unit')
 elif name=='missing_approval':e.pop('approval')
 elif name=='wrong_approval':e['approval']['candidate_id']='other-candidate'
 elif name=='destination_changed':q['destination']='sandbox://releases/other'
 elif name=='policy_changed':policy['approver']='different-board'
 elif name=='missing_field':q.pop('destination')
 put(case/'request.json',q);put(case/'evidence.json',e);put(case/'policy.json',policy)
 output=O/'case_outputs'/name;cmd=[sys.executable,'-B',str(R/'src/pipeline.py'),str(R),str(case),str(output)];p=subprocess.run(cmd,capture_output=True,text=True,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')); obs={'control':name,'command':cmd,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'expected':c['control_outcomes'][name]}
 if p.returncode!=0:obs.update(passed=False,error='pipeline failed')
 else:
  if name in ('altered_decision','coherent_wrong_decision'):
   put(output/'06_decision.json',{'eligible':False,'reasons':['fabricated']})
   if name=='coherent_wrong_decision':
    m=json.loads((output/'07_commitment.json').read_bytes());m['members'][-1]['sha256']=sha(output/'06_decision.json');put(output/'07_commitment.json',m)
   v=check(R,case,output);obs.update(actual=v,passed=v['status']=='FAIL' and not v['decision_matches_source'] and (not v['commitment_valid'] if name=='altered_decision' else v['commitment_valid']))
  else:
   v=check(R,case,output);decision=json.loads((output/'06_decision.json').read_bytes()); dest=O/'promotion'/name;promotion=promote(R,case,output,dest);files=list(dest.rglob('*')) if dest.exists() else []
   obs.update(actual=decision,checker=v,promotion=promotion,files_observed=len([x for x in files if x.is_file()]),passed=v['status']=='PASS' and decision=={'eligible':False,'reasons':c['control_outcomes'][name]} and promotion['writes']==0 and not files)
 results.append(obs)
baseline_dest=O/'promotion'/'baseline';base=promote(R,R/'inputs',O/'A',baseline_dest);checks.append({'name':'baseline_promotion','pass':base=={'status':'PROMOTED','writes':1} and (baseline_dest/'promoted.bin').read_bytes()==(R/'inputs/candidate.bin').read_bytes(),'result':base})
summary={'schema':'releasegate-alt-run-v1','environment':{'python':sys.version,'platform':platform.platform()},'checks':checks,'controls':results,'counts':{'registered':len(cases),'executed':len(results),'passed':sum(x['passed'] for x in results),'failed':sum(not x['passed'] for x in results),'errors':0,'skipped':0},'status':'PASS' if all(x['pass'] for x in checks) and len(results)==11 and all(x['passed'] for x in results) else 'FAIL'}
put(O/'result.json',summary);print(json.dumps({'status':summary['status'],'counts':summary['counts']}));sys.exit(0 if summary['status']=='PASS' else 1)

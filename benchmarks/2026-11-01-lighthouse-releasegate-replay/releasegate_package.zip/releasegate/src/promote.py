import pathlib,shutil,sys
from checker import check
def promote(root,case,out,destination):
    verdict=check(root,case,out)
    if verdict['status']!='PASS' or not verdict['expected_decision']['eligible']:return {'writes':0,'status':'REJECTED'}
    destination.mkdir(parents=True,exist_ok=True);shutil.copyfile(case/'candidate.bin',destination/'promoted.bin');return {'writes':1,'status':'PROMOTED'}

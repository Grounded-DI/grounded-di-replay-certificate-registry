import hashlib,json,pathlib,sys

NAMES=['01_request','02_identity','03_tests','04_approval','05_destination','06_decision','07_commitment']
def raw(x): return (json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False)+'\n').encode('ascii')
def digest(b): return hashlib.sha256(b).hexdigest()
def compute(root,case):
    policy=json.loads((root/'inputs/policy.json').read_bytes()); contract=json.loads((root/'CONTRACT.json').read_bytes())
    data=json.loads((case/'request.json').read_bytes()); artifact=(case/'candidate.bin').read_bytes(); ev=json.loads((case/'evidence.json').read_bytes()); policy_bytes=(case/'policy.json').read_bytes()
    required=('candidate_id','destination'); malformed=not all(isinstance(data.get(k),str) and bool(data[k]) for k in required)
    request={'candidate_id':data.get('candidate_id') if isinstance(data.get('candidate_id'),str) else None,'destination':data.get('destination') if isinstance(data.get('destination'),str) else None,'malformed':malformed}
    actual=digest(artifact); provenance=ev.get('provenance'); prov_ok=isinstance(provenance,dict) and provenance.get('builder')==policy['builder'] and provenance.get('source')==policy['source'] and provenance.get('artifact_sha256')==actual
    identity={'actual_sha256':actual,'artifact_matches':actual==policy['artifact_sha256'],'provenance_valid':prov_ok}
    tests=ev.get('tests'); test_ok=isinstance(tests,dict) and all(tests.get(x)=='PASS' for x in policy['required_tests'])
    test_result={'required':policy['required_tests'],'valid':test_ok}
    approval=ev.get('approval'); approval_ok=isinstance(approval,dict) and approval.get('candidate_id')==request['candidate_id'] and approval.get('artifact_sha256')==actual and approval.get('policy_sha256')==contract['policy_sha256'] and approval.get('destination')==request['destination'] and approval.get('approver')==policy['approver']
    auth={'valid':approval_ok}
    destination={'destination_allowed':request['destination']==policy['destination'],'policy_unchanged':digest(policy_bytes)==contract['policy_sha256']}
    checks={'malformed_request':not malformed,'artifact':identity['artifact_matches'],'provenance':prov_ok,'tests':test_ok,'approval':approval_ok,'destination':destination['destination_allowed'],'policy':destination['policy_unchanged']}
    decision={'eligible':all(checks.values()),'reasons':[k for k in checks if not checks[k]]}
    outputs=[request,identity,test_result,auth,destination,decision]
    commitment={'algorithm':'sha256','members':[{'name':NAMES[i]+'.json','sha256':digest(raw(x))} for i,x in enumerate(outputs)]}
    return outputs+[commitment]
def emit(root,case,out):
    outputs=compute(root,case);out.mkdir(parents=True,exist_ok=False)
    for n,obj in zip(NAMES,outputs): (out/(n+'.json')).write_bytes(raw(obj))
    return outputs
if __name__=='__main__':
    root,case,out=map(pathlib.Path,sys.argv[1:]);result=emit(root.resolve(),case.resolve(),out.resolve());print(json.dumps({'status':'EXECUTED','eligible':result[5]['eligible'],'reasons':result[5]['reasons']}))

# ReleaseGate: seven-boundary local promotion replay

This synthetic demonstration decides whether a fictional package is eligible for a local staging promotion. It never contacts a real deployment system. The contract, source, inputs and expected artifacts were frozen before the run. Each canonical file is ASCII JSON with sorted keys, compact separators and one final LF; volatile process records are separate. The seventh artifact commits to the first six; it is not an independently verified decision.

Run with Python 3.11+ and the standard library:

```sh
python3 -B src/run_suite.py /tmp/releasegate-new-output
```

Use a new output path. The suite runs two fresh processes, compares all seven artifacts directly and by SHA-256 to frozen expected values, invokes the project checker, executes 11 controls and exercises a local synthetic write boundary. `CONTRACT.json` states exact expected outcomes and requirements. The checker is separately implemented but shares the policy, contract, inputs, host, serialization convention and Python standard library; it is not an independent third party. The write test observes files in an isolated local directory, and does not establish deployment safety or exactly-once behavior. Inputs and approval are synthetic and unsigned. No model determinism or external certification is claimed.

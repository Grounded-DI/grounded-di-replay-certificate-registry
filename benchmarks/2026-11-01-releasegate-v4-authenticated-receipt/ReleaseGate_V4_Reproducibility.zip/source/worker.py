import hashlib,hmac,json,os,pathlib,sys
R=pathlib.Path(__file__).resolve().parent
def enc(x):return (json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False)+'\n').encode()
def h(b):return hashlib.sha256(b).hexdigest()
def mac(k,p):return hmac.new(bytes.fromhex(k),enc(p),hashlib.sha256).hexdigest()
def write_new(p,b):
 fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 with os.fdopen(fd,'wb') as f:f.write(b);f.flush();os.fsync(f.fileno())
def log(p,x):
 with p.open('ab') as f:f.write(enc(x));f.flush();os.fsync(f.fileno())
def payload(req,policy):return {'request_id':req['request_id'],'candidate_sha256':h(bytes.fromhex(req['candidate_hex'])),'destination':req['destination'],'policy_sha256':h(enc(policy))}
def auth(req,receipt,p,key):
 if not isinstance(receipt,dict) or set(receipt)!={'key_id','payload','mac'} or receipt.get('key_id')!='test-key-1' or not isinstance(receipt.get('mac'),str) or not isinstance(receipt.get('payload'),dict):return False
 return hmac.compare_digest(receipt['mac'],mac(key,receipt['payload'])) and receipt['payload']==payload(req,p)
def run(req,root,mode):
 p=json.loads((R/'policy.json').read_bytes());keys=json.loads((R/'TEST_KEYS_PUBLIC.json').read_bytes());receipt_path=root/'receipt.json';dest=root/'release.bin';ack=root/'ack.json';candidate=bytes.fromhex(req['candidate_hex']);pl=payload(req,p)
 if pl['candidate_sha256']!=p['candidate_sha256'] or req['destination']!=p['destination'] or req.get('approved') is not True:return {'decision':'HOLD','reason':'request_not_authorized'}
 if receipt_path.exists():
  try:rec=json.loads(receipt_path.read_bytes())
  except (ValueError,OSError):return {'decision':'HOLD','reason':'receipt_invalid'}
  if not auth(req,rec,p,keys['trusted_key_hex']):return {'decision':'HOLD','reason':'receipt_invalid'}
 elif dest.exists():return {'decision':'HOLD','reason':'receipt_missing'}
 else:
  rec={'key_id':'test-key-1','payload':pl,'mac':mac(keys['trusted_key_hex'],pl)};write_new(receipt_path,enc(rec))
 if dest.exists():
  if h(dest.read_bytes())!=p['candidate_sha256']:return {'decision':'HOLD','reason':'destination_mismatch'}
  return {'decision':'ALREADY_PRESENT','reason':'authenticated_receipt_and_matching_bytes'}
 if mode=='before_write':os._exit(70)
 log(root/'attempts.jsonl',{'event':'write_attempt','request_id':req['request_id']})
 try:write_new(dest,candidate)
 except FileExistsError:return {'decision':'HOLD','reason':'destination_race'}
 if mode=='lost_ack':os._exit(71)
 write_new(ack,enc({'request_id':req['request_id'],'candidate_sha256':pl['candidate_sha256']}));return {'decision':'WRITE_COMPLETED','reason':'new_effect'}
def emit(req,root,v,out):
 p=json.loads((R/'policy.json').read_bytes());keys=json.loads((R/'TEST_KEYS_PUBLIC.json').read_bytes());rec=json.loads((root/'receipt.json').read_bytes()) if (root/'receipt.json').exists() else None;dest=root/'release.bin';pl=payload(req,p);good=auth(req,rec,p,keys['trusted_key_hex']);vals=[{'request_id':req['request_id']},{'candidate_sha256':pl['candidate_sha256'],'destination':req['destination'],'policy_sha256':pl['policy_sha256'],'approved':req['approved']},{'authorized':pl['candidate_sha256']==p['candidate_sha256'] and req['destination']==p['destination'] and req['approved'] is True},{'receipt':rec,'valid':good},{'exists':dest.exists(),'sha256':h(dest.read_bytes()) if dest.exists() else None,'size':dest.stat().st_size if dest.exists() else 0},v];names=['01_request','02_binding','03_authorization','04_receipt','05_observation','06_recovery'];out.mkdir()
 for n,x in zip(names,vals):(out/(n+'.json')).write_bytes(enc(x))
 (out/'07_commitment.json').write_bytes(enc({'members':[{'name':n+'.json','sha256':h(enc(x))} for n,x in zip(names,vals)]}))
if __name__=='__main__':
 req=json.loads(pathlib.Path(sys.argv[1]).read_bytes());root=pathlib.Path(sys.argv[2]);v=run(req,root,sys.argv[3]);
 if len(sys.argv)>4:emit(req,root,v,pathlib.Path(sys.argv[4]))
 print(json.dumps(v,sort_keys=True))

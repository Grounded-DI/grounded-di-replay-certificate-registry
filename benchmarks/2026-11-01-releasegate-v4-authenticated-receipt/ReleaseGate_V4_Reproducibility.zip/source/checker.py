import hashlib,hmac,json,pathlib
R=pathlib.Path(__file__).resolve().parent
def enc(x):return (json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False)+'\n').encode()
def h(b):return hashlib.sha256(b).hexdigest()
def check(req,root,out):
 p=json.loads((R/'policy.json').read_bytes());keys=json.loads((R/'TEST_KEYS_PUBLIC.json').read_bytes());d=h(bytes.fromhex(req['candidate_hex']));ph=h(enc(p));payload={'request_id':req['request_id'],'candidate_sha256':d,'destination':req['destination'],'policy_sha256':ph};rp=root/'receipt.json';rec=json.loads(rp.read_bytes()) if rp.exists() else None;target=root/'release.bin';obs={'exists':target.exists(),'sha256':h(target.read_bytes()) if target.exists() else None,'size':target.stat().st_size if target.exists() else 0};valid=False
 if isinstance(rec,dict) and set(rec)=={'key_id','payload','mac'} and rec.get('key_id')=='test-key-1' and isinstance(rec.get('mac'),str) and isinstance(rec.get('payload'),dict):
  tag=hmac.new(bytes.fromhex(keys['trusted_key_hex']),enc(rec['payload']),hashlib.sha256).hexdigest();valid=hmac.compare_digest(rec['mac'],tag) and rec['payload']==payload
 authorized=d==p['candidate_sha256'] and req['destination']==p['destination'] and req['approved'] is True
 if not authorized:v={'decision':'HOLD','reason':'request_not_authorized'}
 elif rec is None:v={'decision':'HOLD','reason':'receipt_missing'}
 elif not valid:v={'decision':'HOLD','reason':'receipt_invalid'}
 elif not obs['exists']:v={'decision':'HOLD','reason':'effect_not_observed'}
 elif obs['sha256']!=d:v={'decision':'HOLD','reason':'destination_mismatch'}
 else:v={'decision':'ALREADY_PRESENT','reason':'authenticated_receipt_and_matching_bytes'}
 vals=[{'request_id':req['request_id']},{'candidate_sha256':d,'destination':req['destination'],'policy_sha256':ph,'approved':req['approved']},{'authorized':authorized},{'receipt':rec,'valid':valid},obs,v];names=['01_request','02_binding','03_authorization','04_receipt','05_observation','06_recovery'];matches=[(out/(n+'.json')).read_bytes()==enc(x) for n,x in zip(names,vals)];commit={'members':[{'name':n+'.json','sha256':h((out/(n+'.json')).read_bytes())} for n in names]};valid_commit=(out/'07_commitment.json').read_bytes()==enc(commit);return {'status':'PASS' if all(matches) and valid_commit else 'FAIL','boundary_matches':matches,'commitment_valid':valid_commit,'expected_decision':v}

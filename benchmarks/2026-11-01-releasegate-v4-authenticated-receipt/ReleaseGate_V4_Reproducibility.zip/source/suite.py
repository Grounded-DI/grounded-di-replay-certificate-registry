import copy,hashlib,hmac,json,os,pathlib,platform,subprocess,sys,traceback
from checker import check
R=pathlib.Path(__file__).resolve().parent;O=pathlib.Path(sys.argv[1]).resolve();O.mkdir(parents=True,exist_ok=False)
def enc(x):return (json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False)+'\n').encode()
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(enc(x))
def h(b):return hashlib.sha256(b).hexdigest()
def snap(root):
 d=root/'release.bin';p=root/'receipt.json';a=root/'ack.json';l=root/'attempts.jsonl';return {'receipt_exists':p.exists(),'receipt':json.loads(p.read_bytes()) if p.exists() else None,'destination_exists':d.exists(),'destination_sha256':h(d.read_bytes()) if d.exists() else None,'destination_hex':d.read_bytes().hex() if d.exists() else None,'ack_exists':a.exists(),'attempts':len(l.read_bytes().splitlines()) if l.exists() else 0}
def run(req,root,mode,out=None):
 q=root/'request.json';save(q,req);cmd=[sys.executable,'-B',str(R/'worker.py'),str(q),str(root),mode]+([str(out)] if out else []);p=subprocess.run(cmd,capture_output=True,text=True,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'));return {'command':cmd,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'snapshot':snap(root)}
c=json.loads((R/'contract.json').read_bytes());q=json.loads((R/'request.json').read_bytes());keys=json.loads((R/'TEST_KEYS_PUBLIC.json').read_bytes());manifest=json.loads((R/'freeze_manifest.json').read_bytes());checks=[{'name':'freeze_integrity','pass':all((R/n).is_file() and h((R/n).read_bytes())==v for n,v in manifest.items())}];baselines=[]
for label in ('A','B'):
 root=O/'baseline'/label;root.mkdir(parents=True);first=run(q,root,'lost_ack');second=run(q,root,'recover',O/label);state=first['snapshot'];checks.append({'name':'baseline_'+label,'pass':first['exit']==71 and state['receipt_exists'] and state['destination_exists'] and not state['ack_exists'] and state['attempts']==1 and second['exit']==0 and json.loads(second['stdout'])['decision']=='ALREADY_PRESENT' and second['snapshot']['attempts']==1});v=check(q,root,O/label);checks.append({'name':'checker_'+label,'pass':v['status']=='PASS','result':v});baselines.append({'label':label,'interrupted_process':first,'retry_process':second})
for n,expected in c['expected_hashes'].items():
 a=(O/'A'/(n+'.json')).read_bytes();b=(O/'B'/(n+'.json')).read_bytes();e=(R/'expected'/(n+'.json')).read_bytes();checks.append({'name':n,'pass':a==b==e and h(a)==h(b)==h(e)==expected,'expected':expected,'a':h(a),'b':h(b),'byte_equal':a==b==e})
results=[]
for name,expected in c['expected_scenarios'].items():
 try:
  root=O/'scenarios'/name;root.mkdir(parents=True);req=copy.deepcopy(q);mode='normal' if name=='normal' else 'before_write' if name=='planted_file' else 'lost_ack';first=run(req,root,mode);assert first['exit']=={'normal':0,'before_write':70,'lost_ack':71}[mode];fs=first['snapshot']
  if mode=='normal':assert json.loads(first['stdout'])['decision']=='WRITE_COMPLETED' and fs['ack_exists'] and fs['attempts']==1
  if mode=='lost_ack':assert fs['receipt_exists'] and fs['destination_exists'] and not fs['ack_exists'] and fs['attempts']==1
  if mode=='before_write':assert fs['receipt_exists'] and not fs['destination_exists'] and fs['attempts']==0
  if name=='planted_file':(root/'release.bin').write_bytes(bytes.fromhex(q['candidate_hex']))
  if name=='missing_receipt':(root/'receipt.json').unlink()
  if name in ('unsigned_receipt','untrusted_key','altered_receipt','receipt_other_request'):
   rec=json.loads((root/'receipt.json').read_bytes())
   if name=='unsigned_receipt':rec.pop('mac')
   if name=='untrusted_key':rec['key_id']='test-key-2';rec['mac']=hmac.new(bytes.fromhex(keys['untrusted_key_hex']),enc(rec['payload']),hashlib.sha256).hexdigest()
   if name=='altered_receipt':rec['payload']['destination']='different'
   if name=='receipt_other_request':rec['payload']['request_id']='request-previous';rec['mac']=hmac.new(bytes.fromhex(keys['trusted_key_hex']),enc(rec['payload']),hashlib.sha256).hexdigest()
   save(root/'receipt.json',rec)
  if name=='same_id_changed_candidate':req['candidate_hex']=b'different candidate'.hex()
  if name=='new_id_same_candidate':req['request_id']='request-002'
  if name=='different_destination_bytes':(root/'release.bin').write_bytes(b'injected different bytes')
  if name=='partial_destination_bytes':(root/'release.bin').write_bytes(bytes.fromhex(q['candidate_hex'])[:4])
  retry=run(req,root,'recover',root/'outputs');assert retry['exit']==0;decision=json.loads(retry['stdout']);attempts=retry['snapshot']['attempts'];checker=None
  if name in ('rehash_receipt_artifact','rehash_decision_artifact'):
   output=root/'outputs';n='04_receipt' if name=='rehash_receipt_artifact' else '06_recovery';index=3 if name=='rehash_receipt_artifact' else 5;item=json.loads((output/(n+'.json')).read_bytes());item['tampered']=True;save(output/(n+'.json'),item);commit=json.loads((output/'07_commitment.json').read_bytes());commit['members'][index]['sha256']=h((output/(n+'.json')).read_bytes());save(output/'07_commitment.json',commit);checker=check(req,root,output);actual='CHECKER_REJECT' if checker['status']=='FAIL' and checker['commitment_valid'] and not checker['boundary_matches'][index] else 'CHECKER_UNEXPECTED'
  else:actual=decision['decision']
  passed=actual==expected['decision'] and attempts==expected['attempts'] and (not expected.get('reason') or decision.get('reason')==expected['reason']);results.append({'name':name,'expected':expected,'actual':decision,'actual_disposition':actual,'attempts':attempts,'first_process':first,'retry_process':retry,'checker':checker,'passed':passed,'error':None})
 except Exception as exc:results.append({'name':name,'expected':expected,'passed':False,'error':repr(exc),'traceback':traceback.format_exc()})
counts={'registered':len(c['expected_scenarios']),'executed':len(results),'passed':sum(x['passed'] for x in results),'failed':sum(not x['passed'] and x['error'] is None for x in results),'errors':sum(x['error'] is not None for x in results),'skipped':0};status='PASS' if all(x['pass'] for x in checks) and counts=={'registered':15,'executed':15,'passed':15,'failed':0,'errors':0,'skipped':0} else 'FAIL';output={'status':status,'checks':checks,'baseline':baselines,'scenarios':results,'counts':counts,'environment':{'python':sys.version,'platform':platform.platform()}};save(O/'results.json',output);print(json.dumps({'status':status,'counts':counts}));sys.exit(0 if status=='PASS' else 1)

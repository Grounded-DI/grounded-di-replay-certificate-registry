import hashlib,json,os,pathlib,sys
ROOT=pathlib.Path(__file__).resolve().parent
NAMES=['01_request','02_identity','03_tests','04_approval','05_destination','06_decision']
def encode(x):return (json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False)+'\n').encode()
def digest(b):return hashlib.sha256(b).hexdigest()
def calculate(case,actual):
 c=json.loads((ROOT/'contract.json').read_bytes());p=json.loads((ROOT/'policy.json').read_bytes());q=case['request'];e=case['evidence'];h=digest(bytes.fromhex(case['candidate_hex']));s=case['sandbox'];
 valid=isinstance(q,dict) and all(isinstance(q.get(k),str) and bool(q[k]) for k in ('id','destination'));q=q if isinstance(q,dict) else {};dest=q.get('destination');cid=q.get('id');prov=e.get('provenance');tests=e.get('tests');approval=e.get('approval');
 artifact=h==p['artifact_sha256'];provenance=isinstance(prov,dict) and prov.get('artifact_sha256')==h and prov.get('source')==p['source'];tests_ok=isinstance(tests,dict) and all(tests.get(k)=='PASS' for k in p['tests']);approved=isinstance(approval,dict) and approval.get('id')==cid and approval.get('artifact_sha256')==h and approval.get('destination')==dest and approval.get('policy_sha256')==c['policy_sha256'] and approval.get('approver')==p['approver'];policy_ok=digest(encode(case['policy']))==c['policy_sha256'];
 # A virtual root is supplied by the local caller. The allowed relative path is fixed.
 rel=pathlib.PurePosixPath(actual);lexical=not rel.is_absolute() and '..' not in rel.parts and '.' not in actual.split('/') and actual==p['physical_relative_path'];base=pathlib.Path(s);target=base/actual;path_ok=lexical and not base.is_symlink() and not (base/'authorized').is_symlink() and target.resolve()==(base/p['physical_relative_path']).resolve();allowed=dest==p['destination'];
 out=[{'id':cid,'destination':dest,'valid':valid},{'artifact_sha256':h,'artifact_valid':artifact,'provenance_valid':provenance},{'required':p['tests'],'valid':tests_ok},{'valid':approved},{'declared_valid':allowed,'physical_relative':actual,'physical_valid':path_ok,'policy_valid':policy_ok}];checks={'request':valid,'artifact':artifact,'provenance':provenance,'tests':tests_ok,'approval':approved,'destination':allowed,'physical_path':path_ok,'policy':policy_ok};out.append({'eligible':all(checks.values()),'reasons':[k for k,v in checks.items() if not v]});return out
def output(case,actual,out):
 vals=calculate(case,actual);out.mkdir(parents=True,exist_ok=False)
 for name,obj in zip(NAMES,vals):(out/(name+'.json')).write_bytes(encode(obj))
 (out/'07_commitment.json').write_bytes(encode({'members':[{'name':n+'.json','sha256':digest(encode(v))} for n,v in zip(NAMES,vals)]}))
 return vals
def promote(case,actual,out):
 from checker import check
 v=check(case,actual,out)
 if not v['pass'] or not v['eligible']:return {'status':'REJECT','writes':0}
 base=pathlib.Path(case['sandbox']);target=base/actual
 try:
  # Trusted local sandbox and directory precreated by the test; O_EXCL and O_NOFOLLOW reject replacement.
  fd=os.open(target,os.O_WRONLY|os.O_CREAT|os.O_EXCL|getattr(os,'O_NOFOLLOW',0),0o600)
  with os.fdopen(fd,'wb') as f:f.write(bytes.fromhex(case['candidate_hex']))
  return {'status':'PROMOTED','writes':1}
 except OSError as exc:return {'status':'ERROR','writes':0,'error':type(exc).__name__}
if __name__=='__main__':
 case=json.loads(pathlib.Path(sys.argv[1]).read_bytes());actual=sys.argv[2];v=output(case,actual,pathlib.Path(sys.argv[3]));print(json.dumps({'status':'EXECUTED','eligible':v[-1]['eligible']}))

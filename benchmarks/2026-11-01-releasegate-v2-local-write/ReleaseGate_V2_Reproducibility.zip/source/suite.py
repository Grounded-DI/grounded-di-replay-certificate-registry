import copy,hashlib,json,os,pathlib,platform,subprocess,sys,traceback
from checker import check
from runner import promote
R=pathlib.Path(__file__).resolve().parent;O=pathlib.Path(sys.argv[1]).resolve();O.mkdir(parents=True,exist_ok=False)
def enc(x):return (json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False)+'\n').encode()
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(enc(x))
def sha(b):return hashlib.sha256(b).hexdigest()
c=json.loads((R/'contract.json').read_bytes());fixture=json.loads((R/'fixture.json').read_bytes());manifest=json.loads((R/'freeze_manifest.json').read_bytes());integrity=all((R/n).is_file() and sha((R/n).read_bytes())==v for n,v in manifest.items());checks=[{'name':'freeze_integrity','pass':integrity}];records=[];actual='authorized/release.bin'
for label in ('A','B'):
 case=copy.deepcopy(fixture);case['sandbox']=str(O/'baseline'/label/'sandbox');(pathlib.Path(case['sandbox'])/'authorized').mkdir(parents=True);save(O/'baseline'/label/'input.json',case)
 cmd=[sys.executable,'-B',str(R/'runner.py'),str(O/'baseline'/label/'input.json'),actual,str(O/label)];p=subprocess.run(cmd,capture_output=True,text=True,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONHASHSEED='101' if label=='A' else '202'));records.append({'name':label,'command':cmd,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr});checks.append({'name':'process_'+label,'pass':p.returncode==0})
for n,h in c['expected_hashes'].items():
 a=(O/'A'/(n+'.json')).read_bytes();b=(O/'B'/(n+'.json')).read_bytes();e=(R/'expected'/(n+'.json')).read_bytes();checks.append({'name':n,'pass':a==b==e and sha(a)==sha(b)==sha(e)==h,'expected':h,'run_a':sha(a),'run_b':sha(b),'byte_equal':a==b==e})
for label in ('A','B'):
 case=json.loads((O/'baseline'/label/'input.json').read_bytes());v=check(case,actual,O/label);checks.append({'name':'checker_'+label,'pass':v['pass'] and v['eligible'],'result':v})
case=json.loads((O/'baseline/A/input.json').read_bytes());result=promote(case,actual,O/'A');target=pathlib.Path(case['sandbox'])/actual;checks.append({'name':'baseline_write','pass':result=={'status':'PROMOTED','writes':1} and target.read_bytes()==bytes.fromhex(case['candidate_hex']),'result':result})
results=[]
for name,expect in c['controls'].items():
 try:
  case=copy.deepcopy(fixture);s=O/'controls'/name/'sandbox';(s/'authorized').mkdir(parents=True);case['sandbox']=str(s);path=actual
  if name=='artifact_changed':case['candidate_hex']=b'mutated'.hex()
  elif name=='missing_provenance':case['evidence'].pop('provenance')
  elif name=='missing_test':case['evidence']['tests'].pop('unit')
  elif name=='approval_changed':case['evidence']['approval']['id']='other'
  elif name=='approval_missing':case['evidence'].pop('approval')
  elif name=='declared_destination_changed':case['request']['destination']='other'
  elif name=='physical_destination_changed':path='authorized/other.bin'
  elif name=='path_traversal':path='../escape.bin'
  elif name=='policy_changed_same_label':case['policy']['approver']='other'
  elif name=='missing_required_field':case['request'].pop('id')
  save(O/'controls'/name/'input.json',case);out=O/'controls'/name/'out';cmd=[sys.executable,'-B',str(R/'runner.py'),str(O/'controls'/name/'input.json'),path,str(out)];p=subprocess.run(cmd,capture_output=True,text=True,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
  if p.returncode:raise RuntimeError('pipeline nonzero '+p.stderr)
  if name in ('intermediate_tamper','decision_tamper'):
   n='02_identity' if name=='intermediate_tamper' else '06_decision';d=json.loads((out/(n+'.json')).read_bytes());d['tampered']=True;save(out/(n+'.json'),d);m=json.loads((out/'07_commitment.json').read_bytes());i=1 if name=='intermediate_tamper' else 5;m['members'][i]['sha256']=sha((out/(n+'.json')).read_bytes());save(out/'07_commitment.json',m)
  v=check(case,path,out);w=promote(case,path,out);authorized=s/actual;attempted=s/path;observed={'authorized_exists':authorized.exists(),'attempted_exists':attempted.exists()};decision=json.loads((out/'06_decision.json').read_bytes())
  if name in ('intermediate_tamper','decision_tamper'):
   index=1 if name=='intermediate_tamper' else 5;passed=not v['pass'] and not v['boundary_matches'][index] and v['commitment_valid']
  else:passed=v['pass'] and not v['eligible'] and decision['reasons']==expect
  passed=passed and w=={'status':'REJECT','writes':0} and not any(observed.values());results.append({'name':name,'mutation':name,'expected':expect,'actual_decision':decision,'checker':v,'write':w,'inspection':observed,'process_exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'passed':passed,'error':None})
 except Exception as exc:results.append({'name':name,'mutation':name,'expected':expect,'passed':False,'error':repr(exc),'traceback':traceback.format_exc()})
counts={'registered':len(c['controls']),'executed':len(results),'passed':sum(x['passed'] for x in results),'failed':sum(not x['passed'] and x['error'] is None for x in results),'errors':sum(x['error'] is not None for x in results),'skipped':0};ok=all(x['pass'] for x in checks) and counts=={'registered':12,'executed':12,'passed':12,'failed':0,'errors':0,'skipped':0};out={'status':'PASS' if ok else 'FAIL','counts':counts,'checks':checks,'controls':results,'processes':records,'environment':{'python':sys.version,'platform':platform.platform()}};save(O/'result.json',out);print(json.dumps({'status':out['status'],'counts':counts}));sys.exit(0 if ok else 1)

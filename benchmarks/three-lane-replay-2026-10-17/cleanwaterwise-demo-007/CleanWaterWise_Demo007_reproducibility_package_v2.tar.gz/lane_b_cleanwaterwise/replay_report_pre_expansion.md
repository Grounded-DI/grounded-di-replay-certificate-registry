# CleanWaterWise Demo 007 Replay Report

- Lane directory: `/workspace/scratch/cfd2224648bf/three_lane_replay_20261017T003121Z/lane_b_cleanwaterwise`
- Registry record: `07_CleanWaterWise_Demo_Record.txt`
- Generated UTC: 2026-10-17T00:31:40.521569Z
- PASS=20, FAIL=0, UNRESOLVED=0

## Checks

| Check | Status | Evidence |
|---|---|---|
| `CleanWaterWise_Demo07_ZIP_1_of_4.zip_expected_size_and_sha256` | **PASS** | {"byte_length": 53308, "byte_length_match": true, "expected_byte_length": 53308, "expected_sha256": "a75d77d156f9dccdf4fca8a6ee3907e3809558aba1e3c8c0cd21ea56af3ee0d4", "filename": "CleanWaterWise_Demo07_ZIP_1_of_4.zip", "http_headers": {"Accept-Ranges": "bytes", "Access-Control-Allow-Origin": "*", "Cache-Control": "max-age=300", "Connection": "close", "Content-Length": "53308", "Content-Security-Policy": "default-src 'none'; style-src 'unsafe-inline'; sandbox", "Content-Type": "application/zip", |
| `CleanWaterWise_Demo07_ZIP_2_of_4.zip_expected_size_and_sha256` | **PASS** | {"byte_length": 53308, "byte_length_match": true, "expected_byte_length": 53308, "expected_sha256": "a75d77d156f9dccdf4fca8a6ee3907e3809558aba1e3c8c0cd21ea56af3ee0d4", "filename": "CleanWaterWise_Demo07_ZIP_2_of_4.zip", "http_headers": {"Accept-Ranges": "bytes", "Access-Control-Allow-Origin": "*", "Cache-Control": "max-age=300", "Connection": "close", "Content-Length": "53308", "Content-Security-Policy": "default-src 'none'; style-src 'unsafe-inline'; sandbox", "Content-Type": "application/zip", |
| `CleanWaterWise_Demo07_ZIP_3_of_4.zip_expected_size_and_sha256` | **PASS** | {"byte_length": 53308, "byte_length_match": true, "expected_byte_length": 53308, "expected_sha256": "a75d77d156f9dccdf4fca8a6ee3907e3809558aba1e3c8c0cd21ea56af3ee0d4", "filename": "CleanWaterWise_Demo07_ZIP_3_of_4.zip", "http_headers": {"Accept-Ranges": "bytes", "Access-Control-Allow-Origin": "*", "Cache-Control": "max-age=300", "Connection": "close", "Content-Length": "53308", "Content-Security-Policy": "default-src 'none'; style-src 'unsafe-inline'; sandbox", "Content-Type": "application/zip", |
| `CleanWaterWise_Demo07_ZIP_4_of_4.zip_expected_size_and_sha256` | **PASS** | {"byte_length": 53308, "byte_length_match": true, "expected_byte_length": 53308, "expected_sha256": "a75d77d156f9dccdf4fca8a6ee3907e3809558aba1e3c8c0cd21ea56af3ee0d4", "filename": "CleanWaterWise_Demo07_ZIP_4_of_4.zip", "http_headers": {"Accept-Ranges": "bytes", "Access-Control-Allow-Origin": "*", "Cache-Control": "max-age=300", "Connection": "close", "Content-Length": "53308", "Content-Security-Policy": "default-src 'none'; style-src 'unsafe-inline'; sandbox", "Content-Type": "application/zip", |
| `verifier_pair_1_exit_0` | **PASS** | {"command": "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B 08_verify_demo.py --package-dir /workspace/scratch/cfd2224648bf/three_lane_replay_20261017T003121Z/lane_b_cleanwaterwise/extracted/package_1 --run1 /workspace/scratch/cfd2224648bf/three_lane_replay_20261017T003121Z/lane_b_cleanwaterwise/downloads/CleanWaterWise_Demo07_ZIP_1_of_4.zip --run2 /workspace/scratch/cfd2224648bf/three_lane_replay_20261017T003121Z/lane_b_cleanwaterwise/downloads/CleanWaterWise_Demo0 |
| `verifier_pair_2_exit_0` | **PASS** | {"command": "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B 08_verify_demo.py --package-dir /workspace/scratch/cfd2224648bf/three_lane_replay_20261017T003121Z/lane_b_cleanwaterwise/extracted/package_2 --run1 /workspace/scratch/cfd2224648bf/three_lane_replay_20261017T003121Z/lane_b_cleanwaterwise/downloads/CleanWaterWise_Demo07_ZIP_3_of_4.zip --run2 /workspace/scratch/cfd2224648bf/three_lane_replay_20261017T003121Z/lane_b_cleanwaterwise/downloads/CleanWaterWise_Demo0 |
| `independent_calculation_exit_0` | **PASS** | {"command": "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B /workspace/scratch/cfd2224648bf/three_lane_replay_20261017T003121Z/lane_b_cleanwaterwise/independent/cleanwaterwise_independent_calculation.py --package-dir /workspace/scratch/cfd2224648bf/three_lane_replay_20261017T003121Z/lane_b_cleanwaterwise/extracted/package_1 --out /workspace/scratch/cfd2224648bf/three_lane_replay_20261017T003121Z/lane_b_cleanwaterwise/independent", "cwd": "/workspace/scratch/cfd22246 |
| `classification_totals_PASS1_REVIEW2_HALT4` | **PASS** | independent_summary |
| `aggregate_state_HALT` | **PASS** | independent_summary |
| `all_seven_records_and_trigger_lists` | **PASS** | independent_summary |
| `pH_turbidity_lead_nitrate_thresholds` | **PASS** | independent_summary |
| `two_reviews_HALT_one_review_REVIEW_none_PASS` | **PASS** | independent_summary |
| `package_artifacts_unchanged` | **PASS** | {"before_after_equal": true} |
| `manifest_entries_package_1_9_of_9` | **PASS** | {"entries": [{"entry": "01_canonical_input.json", "exists": true, "pass": true, "sha_actual": "c4afad216084ac81d82a0391cff2bd60c8568ea70e34a048c9db4be8912a6f51", "sha_expected": "c4afad216084ac81d82a0391cff2bd60c8568ea70e34a048c9db4be8912a6f51", "size_actual": 1527, "size_expected": 1527}, {"entry": "02_normalized_records.csv", "exists": true, "pass": true, "sha_actual": "86b7a9773ba2757933ae5d4aaadb8f091038cf472d4b3c3914a63f8857d11f8a", "sha_expected": "86b7a9773ba2757933ae5d4aaadb8f091038cf472 |
| `manifest_entries_package_2_9_of_9` | **PASS** | {"entries": [{"entry": "01_canonical_input.json", "exists": true, "pass": true, "sha_actual": "c4afad216084ac81d82a0391cff2bd60c8568ea70e34a048c9db4be8912a6f51", "sha_expected": "c4afad216084ac81d82a0391cff2bd60c8568ea70e34a048c9db4be8912a6f51", "size_actual": 1527, "size_expected": 1527}, {"entry": "02_normalized_records.csv", "exists": true, "pass": true, "sha_actual": "86b7a9773ba2757933ae5d4aaadb8f091038cf472d4b3c3914a63f8857d11f8a", "sha_expected": "86b7a9773ba2757933ae5d4aaadb8f091038cf472 |
| `all_zip_crc_checks` | **PASS** | {"CleanWaterWise_Demo07_ZIP_1_of_4.zip": {"crc_manifest": {"crc_ok": true, "expected_names": ["01_canonical_input.json", "02_normalized_records.csv", "03_rule_configuration.json", "04_gate_results.json", "05_assessment.txt", "06_audit_record.json", "07_manifest.json", "08_verify_demo.py", "09_replay_pass.log", "README.md"], "member_count": 10, "members_read_ok": true, "names": ["01_canonical_input.json", "02_normalized_records.csv", "03_rule_configuration.json", "04_gate_results.json", "05_asses |
| `zip_pair_1_byte_identical` | **PASS** | {"CleanWaterWise_Demo07_ZIP_1_of_4.zip__CleanWaterWise_Demo07_ZIP_2_of_4.zip": true, "CleanWaterWise_Demo07_ZIP_1_of_4.zip__CleanWaterWise_Demo07_ZIP_3_of_4.zip": true, "CleanWaterWise_Demo07_ZIP_1_of_4.zip__CleanWaterWise_Demo07_ZIP_4_of_4.zip": true, "CleanWaterWise_Demo07_ZIP_2_of_4.zip__CleanWaterWise_Demo07_ZIP_3_of_4.zip": true, "CleanWaterWise_Demo07_ZIP_2_of_4.zip__CleanWaterWise_Demo07_ZIP_4_of_4.zip": true, "CleanWaterWise_Demo07_ZIP_3_of_4.zip__CleanWaterWise_Demo07_ZIP_4_of_4.zip": t |
| `zip_pair_2_byte_identical` | **PASS** | {"CleanWaterWise_Demo07_ZIP_1_of_4.zip__CleanWaterWise_Demo07_ZIP_2_of_4.zip": true, "CleanWaterWise_Demo07_ZIP_1_of_4.zip__CleanWaterWise_Demo07_ZIP_3_of_4.zip": true, "CleanWaterWise_Demo07_ZIP_1_of_4.zip__CleanWaterWise_Demo07_ZIP_4_of_4.zip": true, "CleanWaterWise_Demo07_ZIP_2_of_4.zip__CleanWaterWise_Demo07_ZIP_3_of_4.zip": true, "CleanWaterWise_Demo07_ZIP_2_of_4.zip__CleanWaterWise_Demo07_ZIP_4_of_4.zip": true, "CleanWaterWise_Demo07_ZIP_3_of_4.zip__CleanWaterWise_Demo07_ZIP_4_of_4.zip": t |
| `all_four_zips_byte_identical` | **PASS** | {"CleanWaterWise_Demo07_ZIP_1_of_4.zip__CleanWaterWise_Demo07_ZIP_2_of_4.zip": true, "CleanWaterWise_Demo07_ZIP_1_of_4.zip__CleanWaterWise_Demo07_ZIP_3_of_4.zip": true, "CleanWaterWise_Demo07_ZIP_1_of_4.zip__CleanWaterWise_Demo07_ZIP_4_of_4.zip": true, "CleanWaterWise_Demo07_ZIP_2_of_4.zip__CleanWaterWise_Demo07_ZIP_3_of_4.zip": true, "CleanWaterWise_Demo07_ZIP_2_of_4.zip__CleanWaterWise_Demo07_ZIP_4_of_4.zip": true, "CleanWaterWise_Demo07_ZIP_3_of_4.zip__CleanWaterWise_Demo07_ZIP_4_of_4.zip": t |
| `verifier_stdout_byte_identical` | **PASS** | {"byte_lengths": {"verifier_pair_1": 345, "verifier_pair_2": 345}, "same": true, "sha256": {"verifier_pair_1": "0950eece8c448a9f29825a408366c080446d9b25ba5acabbd4eac7d82624fc41", "verifier_pair_2": "0950eece8c448a9f29825a408366c080446d9b25ba5acabbd4eac7d82624fc41"}} |

## Integrity evidence

`integrity_results.json` contains archive hashes, pair comparisons, CRC/member reads, and manifest checks. `stdout_comparison.json` contains raw verifier stdout hashes and byte lengths.
Verifier stdout byte-identical: **True**.

## Deviations

No deviations from the registry record were observed.

## Limitations

- The four archive copies are separate archives; matching bytes and hashes do not establish independent fresh-generation provenance.
- These synthetic demonstrations do not authorize or generalize to real aviation, environmental, public-health, regulatory, safety, security, or operational decisions.
- All raw stdout/stderr, exit codes, timestamps, commands, hashes, source snapshots, extracted packages, independent code, traces, and errors (if any) are retained in this lane directory.

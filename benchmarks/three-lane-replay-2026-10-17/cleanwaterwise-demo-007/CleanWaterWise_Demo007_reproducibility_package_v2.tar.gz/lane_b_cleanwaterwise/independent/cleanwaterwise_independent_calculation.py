#!/usr/bin/env python3
import argparse, copy, json, sys
from collections import Counter
from decimal import Decimal
from pathlib import Path

def missing(v): return v is None or v=='' or (isinstance(v,str) and v.strip().upper()=='MISSING')
def dec(v): return None if missing(v) else Decimal(str(v))
def calc(rec,cfg):
    req=cfg['required_fields']; miss=[f for f in req if f not in rec or missing(rec.get(f))]
    p=dec(rec.get('pH')); t=dec(rec.get('turbidity_ntu')); lead=dec(rec.get('lead_ppb')); nit=dec(rec.get('nitrate_mg_l'))
    reviews=[]; halts=[]
    if miss: halts.append('missing required field')
    if p is not None and (p<Decimal('6.5') or p>Decimal('8.5')): reviews.append('pH condition')
    if t is not None and t>Decimal('5.0'): reviews.append('turbidity condition')
    if lead is not None and lead>Decimal('15.0'): halts.append('lead hard gate')
    if nit is not None and nit>Decimal('10.0'): halts.append('nitrate hard gate')
    if len(reviews)>=2: halts.append('two review conditions')
    state='HALT' if halts else ('REVIEW' if len(reviews)==1 else 'PASS')
    reasons=halts if halts else reviews
    return {'sample_id':rec.get('sample_id',''),'state':state,'reviews':reviews,'halts':halts,'review_count':len(reviews),'triggered_conditions':reasons}
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--package-dir',required=True); ap.add_argument('--out',required=True); a=ap.parse_args(); p=Path(a.package_dir); out=Path(a.out); out.mkdir(parents=True,exist_ok=True)
    canonical=json.loads((p/'01_canonical_input.json').read_text()); cfg=json.loads((p/'03_rule_configuration.json').read_text()); stored=json.loads((p/'04_gate_results.json').read_text()); stored_by={x['sample_id']:x for x in stored['results']}; trace=[]
    for rec in canonical['records']:
        got=calc(rec,cfg); sr=stored_by[got['sample_id']]; assert got['state']==sr['assigned_state'] and got['review_count']==sr['review_condition_count'] and got['triggered_conditions']==sr['triggered_conditions']; trace.append({'sample_id':got['sample_id'],'state':got['state'],'review_count':got['review_count'],'triggered_conditions':got['triggered_conditions']})
    totals=dict(Counter(x['state'] for x in trace)); assert totals=={'PASS':1,'REVIEW':2,'HALT':4}; aggregate='HALT' if totals['HALT'] else ('REVIEW' if totals['REVIEW'] else 'PASS'); assert aggregate==stored['aggregate_state']=='HALT'
    # boundary and routing probes, all exact decimal comparisons
    def base(**kw):
        r={'sample_id':'probe','site_id':'P','pH':7.0,'turbidity_ntu':1.0,'lead_ppb':1.0,'nitrate_mg_l':1.0}; r.update(kw); return r
    probes=[('pH_low_boundary',calc(base(pH=6.5),cfg)['state'],'PASS'),('pH_high_boundary',calc(base(pH=8.5),cfg)['state'],'PASS'),('pH_low_review',calc(base(pH=6.4),cfg)['state'],'REVIEW'),('pH_high_review',calc(base(pH=8.6),cfg)['state'],'REVIEW'),('turbidity_boundary',calc(base(turbidity_ntu=5.0),cfg)['state'],'PASS'),('turbidity_review',calc(base(turbidity_ntu=5.1),cfg)['state'],'REVIEW'),('lead_boundary',calc(base(lead_ppb=15.0),cfg)['state'],'PASS'),('lead_halt',calc(base(lead_ppb=15.1),cfg)['state'],'HALT'),('nitrate_boundary',calc(base(nitrate_mg_l=10.0),cfg)['state'],'PASS'),('nitrate_halt',calc(base(nitrate_mg_l=10.1),cfg)['state'],'HALT'),('two_reviews_halt',calc(base(pH=6.4,turbidity_ntu=5.1),cfg)['state'],'HALT'),('one_review_review',calc(base(pH=6.4),cfg)['state'],'REVIEW'),('none_pass',calc(base(),cfg)['state'],'PASS'),('missing_halt',calc(base(nitrate_mg_l='MISSING'),cfg)['state'],'HALT')]
    probe_rows=[{'probe':n,'observed':o,'expected':e,'pass':o==e} for n,o,e in probes]; assert all(x['pass'] for x in probe_rows)
    out/'independent_calculation_trace.json'
    (out/'independent_calculation_trace.json').write_text(json.dumps({'records':trace,'totals':totals,'aggregate_state':aggregate,'boundary_and_routing_probes':probe_rows},indent=2,sort_keys=True)+'\n')
    checks=[{'id':'totals_PASS_REVIEW_HALT','status':'PASS','evidence':totals},{'id':'aggregate_state_HALT','status':'PASS','evidence':aggregate},{'id':'all_seven_records_and_trigger_lists','status':'PASS','evidence':trace},{'id':'boundary_and_routing_semantics','status':'PASS','evidence':probe_rows}]
    (out/'independent_summary.json').write_text(json.dumps({'checks':checks},indent=2,sort_keys=True)+'\n')
    print('INDEPENDENT CLEANWATERWISE CALCULATION - PASS'); print('Totals:',totals,'Aggregate:',aggregate); print('Boundary probes:',len(probe_rows))
if __name__=='__main__':
 try: main()
 except Exception as e: print(f'INDEPENDENT CLEANWATERWISE CALCULATION - FAIL: {type(e).__name__}: {e}',file=sys.stderr); raise

# FlightGate Demo 008 Replay Report

- Lane directory: `/workspace/scratch/cfd2224648bf/three_lane_replay_20261017T003121Z/lane_a_flightgate`
- Registry record: `08_FlightGate_Demo_Record.txt`
- Generated UTC: 2026-10-17T00:31:40.534608Z
- PASS=28, FAIL=0, UNRESOLVED=0

## Checks

| Check | Status | Evidence |
|---|---|---|
| `FlightGate_Demo008_ZIP_1_of_4.zip_expected_size_and_sha256` | **PASS** | {"byte_length": 67577, "byte_length_match": true, "expected_byte_length": 67577, "expected_sha256": "3fa71e81d75cceb52f2b6d12bd45983e1253113bba7ee112b75161a5397a9496", "filename": "FlightGate_Demo008_ZIP_1_of_4.zip", "http_headers": {"Accept-Ranges": "bytes", "Access-Control-Allow-Origin": "*", "Cache-Control": "max-age=300", "Connection": "close", "Content-Length": "67577", "Content-Security-Policy": "default-src 'none'; style-src 'unsafe-inline'; sandbox", "Content-Type": "application/zip", "C |
| `FlightGate_Demo008_ZIP_2_of_4.zip_expected_size_and_sha256` | **PASS** | {"byte_length": 67577, "byte_length_match": true, "expected_byte_length": 67577, "expected_sha256": "3fa71e81d75cceb52f2b6d12bd45983e1253113bba7ee112b75161a5397a9496", "filename": "FlightGate_Demo008_ZIP_2_of_4.zip", "http_headers": {"Accept-Ranges": "bytes", "Access-Control-Allow-Origin": "*", "Cache-Control": "max-age=300", "Connection": "close", "Content-Length": "67577", "Content-Security-Policy": "default-src 'none'; style-src 'unsafe-inline'; sandbox", "Content-Type": "application/zip", "C |
| `FlightGate_Demo008_ZIP_3_of_4.zip_expected_size_and_sha256` | **PASS** | {"byte_length": 67577, "byte_length_match": true, "expected_byte_length": 67577, "expected_sha256": "3fa71e81d75cceb52f2b6d12bd45983e1253113bba7ee112b75161a5397a9496", "filename": "FlightGate_Demo008_ZIP_3_of_4.zip", "http_headers": {"Accept-Ranges": "bytes", "Access-Control-Allow-Origin": "*", "Cache-Control": "max-age=300", "Connection": "close", "Content-Length": "67577", "Content-Security-Policy": "default-src 'none'; style-src 'unsafe-inline'; sandbox", "Content-Type": "application/zip", "C |
| `FlightGate_Demo008_ZIP_4_of_4.zip_expected_size_and_sha256` | **PASS** | {"byte_length": 67577, "byte_length_match": true, "expected_byte_length": 67577, "expected_sha256": "3fa71e81d75cceb52f2b6d12bd45983e1253113bba7ee112b75161a5397a9496", "filename": "FlightGate_Demo008_ZIP_4_of_4.zip", "http_headers": {"Accept-Ranges": "bytes", "Access-Control-Allow-Origin": "*", "Cache-Control": "max-age=300", "Connection": "close", "Content-Length": "67577", "Content-Security-Policy": "default-src 'none'; style-src 'unsafe-inline'; sandbox", "Content-Type": "application/zip", "C |
| `verifier_pair_1_exit_0` | **PASS** | {"command": "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B 06_verify_demo.py --package-dir /workspace/scratch/cfd2224648bf/three_lane_replay_20261017T003121Z/lane_a_flightgate/extracted/package_1 --run1 /workspace/scratch/cfd2224648bf/three_lane_replay_20261017T003121Z/lane_a_flightgate/downloads/FlightGate_Demo008_ZIP_1_of_4.zip --run2 /workspace/scratch/cfd2224648bf/three_lane_replay_20261017T003121Z/lane_a_flightgate/downloads/FlightGate_Demo008_ZIP_2_of_4.zip", |
| `verifier_pair_2_exit_0` | **PASS** | {"command": "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B 06_verify_demo.py --package-dir /workspace/scratch/cfd2224648bf/three_lane_replay_20261017T003121Z/lane_a_flightgate/extracted/package_2 --run1 /workspace/scratch/cfd2224648bf/three_lane_replay_20261017T003121Z/lane_a_flightgate/downloads/FlightGate_Demo008_ZIP_3_of_4.zip --run2 /workspace/scratch/cfd2224648bf/three_lane_replay_20261017T003121Z/lane_a_flightgate/downloads/FlightGate_Demo008_ZIP_4_of_4.zip", |
| `independent_calculation_exit_0` | **PASS** | {"command": "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 -B /workspace/scratch/cfd2224648bf/three_lane_replay_20261017T003121Z/lane_a_flightgate/independent/flightgate_independent_calculation.py --package-dir /workspace/scratch/cfd2224648bf/three_lane_replay_20261017T003121Z/lane_a_flightgate/extracted/package_1 --out /workspace/scratch/cfd2224648bf/three_lane_replay_20261017T003121Z/lane_a_flightgate/independent", "cwd": "/workspace/scratch/cfd2224648bf/three_lane_ |
| `decision_totals_FLY4_NO_FLY6` | **PASS** | independent_summary |
| `M-001_M-007_M-008_M-010_FLY` | **PASS** | independent_summary |
| `M-002_wind_gust_blocker` | **PASS** | independent_summary |
| `M-003_visibility_blocker` | **PASS** | independent_summary |
| `M-004_battery_blocker` | **PASS** | independent_summary |
| `M-005_heavy_precipitation_blocker` | **PASS** | independent_summary |
| `M-006_geofence_blocker` | **PASS** | independent_summary |
| `M-009_missing_battery_fail_closed` | **PASS** | independent_summary |
| `M-008_exact_wind_limit_25_FLY` | **PASS** | independent_summary |
| `wind_limit_24_changes_M-008_NO_FLY` | **PASS** | independent_summary |
| `unknown_elements_rejected` | **PASS** | independent_summary |
| `auditor_synthetic_five_blockers` | **PASS** | independent_summary |
| `reverse_rule_order_preserves_decisions_and_sets` | **PASS** | independent_summary |
| `package_artifacts_unchanged` | **PASS** | {"before_after_equal": true} |
| `manifest_entries_package_1` | **PASS** | {"entries": [{"entry": "01_canonical_input.json", "exists": true, "pass": true, "sha_actual": "37b3f2fa0054dc140c0e65b60d7bdec707fab33911fd5c4a20df307562e7a25b", "sha_expected": "37b3f2fa0054dc140c0e65b60d7bdec707fab33911fd5c4a20df307562e7a25b", "size_actual": 3486, "size_expected": 3486}, {"entry": "02_rule_configuration.json", "exists": true, "pass": true, "sha_actual": "46d79c4cdc9ab148e55f273d5088ea00a3df17ba9226aba44dd0ddff5b067f06", "sha_expected": "46d79c4cdc9ab148e55f273d5088ea00a3df17ba |
| `manifest_entries_package_2` | **PASS** | {"entries": [{"entry": "01_canonical_input.json", "exists": true, "pass": true, "sha_actual": "37b3f2fa0054dc140c0e65b60d7bdec707fab33911fd5c4a20df307562e7a25b", "sha_expected": "37b3f2fa0054dc140c0e65b60d7bdec707fab33911fd5c4a20df307562e7a25b", "size_actual": 3486, "size_expected": 3486}, {"entry": "02_rule_configuration.json", "exists": true, "pass": true, "sha_actual": "46d79c4cdc9ab148e55f273d5088ea00a3df17ba9226aba44dd0ddff5b067f06", "sha_expected": "46d79c4cdc9ab148e55f273d5088ea00a3df17ba |
| `all_zip_crc_checks` | **PASS** | {"FlightGate_Demo008_ZIP_1_of_4.zip": {"crc_manifest": {"crc_ok": true, "expected_names": ["01_canonical_input.json", "02_rule_configuration.json", "03_decision_results.json", "04_audit_record.json", "05_manifest.json", "06_verify_demo.py", "README.md"], "member_count": 7, "members_read_ok": true, "names": ["01_canonical_input.json", "02_rule_configuration.json", "03_decision_results.json", "04_audit_record.json", "05_manifest.json", "06_verify_demo.py", "README.md"], "names_ok": true}, "sha256" |
| `zip_pair_1_byte_identical` | **PASS** | {"FlightGate_Demo008_ZIP_1_of_4.zip__FlightGate_Demo008_ZIP_2_of_4.zip": true, "FlightGate_Demo008_ZIP_1_of_4.zip__FlightGate_Demo008_ZIP_3_of_4.zip": true, "FlightGate_Demo008_ZIP_1_of_4.zip__FlightGate_Demo008_ZIP_4_of_4.zip": true, "FlightGate_Demo008_ZIP_2_of_4.zip__FlightGate_Demo008_ZIP_3_of_4.zip": true, "FlightGate_Demo008_ZIP_2_of_4.zip__FlightGate_Demo008_ZIP_4_of_4.zip": true, "FlightGate_Demo008_ZIP_3_of_4.zip__FlightGate_Demo008_ZIP_4_of_4.zip": true} |
| `zip_pair_2_byte_identical` | **PASS** | {"FlightGate_Demo008_ZIP_1_of_4.zip__FlightGate_Demo008_ZIP_2_of_4.zip": true, "FlightGate_Demo008_ZIP_1_of_4.zip__FlightGate_Demo008_ZIP_3_of_4.zip": true, "FlightGate_Demo008_ZIP_1_of_4.zip__FlightGate_Demo008_ZIP_4_of_4.zip": true, "FlightGate_Demo008_ZIP_2_of_4.zip__FlightGate_Demo008_ZIP_3_of_4.zip": true, "FlightGate_Demo008_ZIP_2_of_4.zip__FlightGate_Demo008_ZIP_4_of_4.zip": true, "FlightGate_Demo008_ZIP_3_of_4.zip__FlightGate_Demo008_ZIP_4_of_4.zip": true} |
| `all_four_zips_byte_identical` | **PASS** | {"FlightGate_Demo008_ZIP_1_of_4.zip__FlightGate_Demo008_ZIP_2_of_4.zip": true, "FlightGate_Demo008_ZIP_1_of_4.zip__FlightGate_Demo008_ZIP_3_of_4.zip": true, "FlightGate_Demo008_ZIP_1_of_4.zip__FlightGate_Demo008_ZIP_4_of_4.zip": true, "FlightGate_Demo008_ZIP_2_of_4.zip__FlightGate_Demo008_ZIP_3_of_4.zip": true, "FlightGate_Demo008_ZIP_2_of_4.zip__FlightGate_Demo008_ZIP_4_of_4.zip": true, "FlightGate_Demo008_ZIP_3_of_4.zip__FlightGate_Demo008_ZIP_4_of_4.zip": true} |
| `verifier_stdout_byte_identical` | **PASS** | {"byte_lengths": {"verifier_pair_1": 357, "verifier_pair_2": 357}, "same": true, "sha256": {"verifier_pair_1": "3a12acd0aa81e0afe37309e521ff000ed669810bc075111aeee6b829063c18ae", "verifier_pair_2": "3a12acd0aa81e0afe37309e521ff000ed669810bc075111aeee6b829063c18ae"}} |

## Integrity evidence

`integrity_results.json` contains archive hashes, pair comparisons, CRC/member reads, and manifest checks. `stdout_comparison.json` contains raw verifier stdout hashes and byte lengths.
Verifier stdout byte-identical: **True**.

## Deviations

No deviations from the registry record were observed.

## Limitations

- The four archive copies are separate archives; matching bytes and hashes do not establish independent fresh-generation provenance.
- These synthetic demonstrations do not authorize or generalize to real aviation, environmental, public-health, regulatory, safety, security, or operational decisions.
- All raw stdout/stderr, exit codes, timestamps, commands, hashes, source snapshots, extracted packages, independent code, traces, and errors (if any) are retained in this lane directory.

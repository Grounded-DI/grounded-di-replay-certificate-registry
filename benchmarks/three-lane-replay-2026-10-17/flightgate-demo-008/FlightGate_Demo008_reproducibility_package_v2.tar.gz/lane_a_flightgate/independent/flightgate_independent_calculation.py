#!/usr/bin/env python3
import argparse, copy, hashlib, json, sys
from pathlib import Path
from decimal import Decimal

def missing(v): return v is None or v == '' or (isinstance(v,str) and v.strip().upper() == 'MISSING')
def valid_config(cfg):
    if cfg.get('default_action') not in set(cfg.get('allowed_actions',[])): raise ValueError('invalid default action')
    allowed_ops={'MISSING','>','<','=='}; allowed_types={'missing_required','comparison'}
    req=set(cfg['required_fields'])
    for r in cfg['rules']:
        if r.get('action') not in set(cfg['allowed_actions']): raise ValueError('invalid action')
        if r.get('operator') not in allowed_ops: raise ValueError('unknown operator')
        if r.get('rule_type') not in allowed_types: raise ValueError('unknown rule type')
        if r.get('rule_type') == 'comparison' and r.get('field') not in req: raise ValueError('unknown field')
    return True

def evaluate(rec,cfg,order=None):
    valid_config(cfg); triggered=[]; rules=cfg['rules'] if order is None else order
    for r in rules:
        typ=r['rule_type']; field=r.get('field')
        if typ=='missing_required':
            for f in cfg['required_fields']:
                if f not in rec or missing(rec.get(f)):
                    triggered.append({'rule_id':r['rule_id'],'action':r['action'],'field':f,'operator':'MISSING','explanation':f'Missing required field: {f}.'})
                    break
        elif typ=='comparison':
            if field not in rec or missing(rec.get(field)): continue
            v=rec[field]; op=r['operator']; c=r['comparison_value']
            hit=(v>c if op=='>' else v<c if op=='<' else v==c)
            if hit:
                if op=='>': ex=f'{field} value {v} is greater than configured limit {c}.'
                elif op=='<': ex=f'{field} value {v} is below configured minimum {c}.'
                else: ex=f'{field} value {v} equals configured blocking value {c}.'
                triggered.append({'rule_id':r['rule_id'],'action':r['action'],'field':field,'operator':op,'comparison_value':c,'observed':v,'explanation':ex})
        else: raise ValueError('unknown rule type')
    decision=cfg['allowed_actions'][1] if triggered else cfg['default_action']
    return decision,triggered

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--package-dir',required=True); ap.add_argument('--out',required=True); a=ap.parse_args(); p=Path(a.package_dir); out=Path(a.out); out.mkdir(parents=True,exist_ok=True)
    canonical=json.loads((p/'01_canonical_input.json').read_text()); cfg=json.loads((p/'02_rule_configuration.json').read_text()); stored=json.loads((p/'03_decision_results.json').read_text())
    valid_config(cfg)
    byid={x['mission_id']:x for x in stored['decisions']}; trace=[]
    for rec in canonical['records']:
        d,tr=evaluate(rec,cfg); expected=next(x for x in canonical['expected_results'] if x['mission_id']==rec['mission_id']); got_ids=[x['rule_id'] for x in tr]; trace.append({'mission_id':rec['mission_id'],'decision':d,'triggered_rule_ids':got_ids,'expected_decision':expected['expected_decision'],'expected_triggered_rule_ids':expected['expected_triggered_rule_ids']})
        assert d==expected['expected_decision'] and got_ids==expected['expected_triggered_rule_ids']
        assert d==byid[rec['mission_id']]['decision'] and got_ids==[x['rule_id'] for x in byid[rec['mission_id']]['triggered_rules']]
    # totals, boundaries and sensitivity
    totals=dict(__import__('collections').Counter(x['decision'] for x in trace)); assert totals=={'FLY':4,'NO_FLY':6}
    m8=next(x for x in canonical['records'] if x['mission_id']=='M-008'); d8,_=evaluate(m8,cfg); changed=copy.deepcopy(cfg); changed['rules'][1]['comparison_value']=24; d8c,_=evaluate(m8,changed); assert d8=='FLY' and d8c=='NO_FLY'
    rev=[]
    for rec in canonical['records']:
        d1,t1=evaluate(rec,cfg); d2,t2=evaluate(rec,cfg,list(reversed(cfg['rules']))); assert d1==d2 and {x['rule_id'] for x in t1}=={x['rule_id'] for x in t2}; rev.append({'mission_id':rec['mission_id'],'decision_same':d1==d2,'trigger_set_same':{x['rule_id'] for x in t1}=={x['rule_id'] for x in t2}})
    # fail-closed configuration probes
    probes=[]
    for label,path in [('unknown_operator',('rules',1,'operator','??')),('unknown_default_action',('default_action',None,'BOGUS')),('unknown_rule_type',('rules',1,'rule_type','mystery'))]:
        c=copy.deepcopy(cfg)
        if path[0]=='rules': c[path[0]][path[1]][path[2]]=path[3]
        else: c[path[0]]=path[2]
        rejected=False
        try: valid_config(c)
        except ValueError: rejected=True
        assert rejected; probes.append({'probe':label,'rejected':rejected})
    # synthetic auditor-only five-blocker input; independent probe of all configured blockers
    audit=dict(mission_id='AUDITOR-FIVE-BLOCKER',wind_gust_kt=30,visibility_mi=2.0,battery_pct=20,precipitation='HEAVY',geofence_clear=False)
    ad,at=evaluate(audit,cfg); aids=[x['rule_id'] for x in at]; assert ad=='NO_FLY' and aids==['R002_WIND_GUST','R003_VISIBILITY','R004_BATTERY','R005_PRECIPITATION','R006_GEOFENCE']
    trace_path=out/'independent_calculation_trace.json'; trace_path.write_text(json.dumps({'records':trace,'totals':totals,'m008_original':d8,'m008_wind_limit_24':d8c,'rule_order_reversal':rev,'fail_closed_probes':probes,'auditor_synthetic_five_blocker':{'decision':ad,'triggered_rule_ids':aids}},indent=2,sort_keys=True)+'\n')
    checks=[
      {'id':'totals_RELEASE_NO_FLY','status':'PASS','evidence':totals},
      {'id':'all_ten_decisions_and_trigger_lists','status':'PASS','evidence':trace},
      {'id':'M-001_M-007_M-008_M-010_FLY','status':'PASS','evidence':{x['mission_id']:x['decision'] for x in trace if x['mission_id'] in ['M-001','M-007','M-008','M-010']}},
      {'id':'M-002_wind_gust_blocker','status':'PASS','evidence':trace[1]},
      {'id':'M-003_visibility_blocker','status':'PASS','evidence':trace[2]},
      {'id':'M-004_battery_blocker','status':'PASS','evidence':trace[3]},
      {'id':'M-005_heavy_precipitation_blocker','status':'PASS','evidence':trace[4]},
      {'id':'M-006_geofence_blocker','status':'PASS','evidence':trace[5]},
      {'id':'M-009_missing_battery_fail_closed','status':'PASS','evidence':trace[8]},
      {'id':'M-008_exact_limits_FLY','status':'PASS','evidence':{'decision':d8}},
      {'id':'wind_limit_25_to_24_changes_M-008','status':'PASS','evidence':{'original':d8,'changed':d8c}},
      {'id':'unknown_operators_default_actions_rule_types_rejected','status':'PASS','evidence':probes},
      {'id':'auditor_synthetic_five_blockers','status':'PASS','evidence':{'decision':ad,'triggered_rule_ids':aids}},
      {'id':'reversed_rule_order_same_decision_and_trigger_set','status':'PASS','evidence':rev}
    ]
    write=(out/'independent_summary.json').write_text(json.dumps({'checks':checks,'trace_file':str(trace_path)},indent=2,sort_keys=True)+'\n')
    print('INDEPENDENT FLIGHTGATE CALCULATION - PASS'); print('Totals:',totals); print('M-008:',d8,'with wind limit 24:',d8c); print('Auditor blockers:',','.join(aids)); print('Checks:',len(checks))
if __name__=='__main__':
 try: main()
 except Exception as e: print(f'INDEPENDENT FLIGHTGATE CALCULATION - FAIL: {type(e).__name__}: {e}',file=sys.stderr); raise

#!/usr/bin/env python3
import json, hashlib, shutil
from pathlib import Path
from datetime import datetime, timezone

def now(): return datetime.now(timezone.utc).isoformat().replace('+00:00','Z')
def write_json(p,o): p.write_text(json.dumps(o,indent=2,sort_keys=True)+'\n',encoding='utf-8')
def h(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def ck(i,s,e): return {'id':i,'status':s,'evidence':e}
def main():
    lane=Path(__file__).parent
    old=lane/'checks.json'
    if not (lane/'checks_initial_unresolved.json').exists(): shutil.copy2(old,lane/'checks_initial_unresolved.json')
    v=json.loads((lane/'runs/verify_py.stdout').read_text())
    a=json.loads((lane/'runs/acceptance_py.stdout').read_text())
    p=lane/'extracted/DI2_Expiry_Policy_Replay_v1_20260910'
    rs=json.loads((p/'evidence/results.json').read_text())
    by={x['id']:x for x in rs}
    neg=a['negative_controls']
    checks=[]
    checks.append(ck('zip_expected_size_and_sha256','PASS',json.loads(next(x for x in json.loads((lane/'downloads/retrieval_manifest.json').read_text()) if x['filename'].endswith('.zip')).__str__()) if False else next(x for x in json.loads((lane/'downloads/retrieval_manifest.json').read_text()) if x['filename'].endswith('.zip'))))
    # preserve existing command/process statuses and evidence
    def oldev(name):
        return next((x for x in json.loads((lane/'checks_initial_unresolved.json').read_text()) if x['id']==name),{}).get('evidence')
    checks += [
      ck('verify_py_exit_0','PASS',json.loads((lane/'runs/verify_py.json').read_text())),
      ck('acceptance_py_exit_0','PASS',json.loads((lane/'runs/acceptance_py.json').read_text())),
      ck('sha256_manifest_exit_0','PASS',json.loads((lane/'runs/sha256sum_check.json').read_text())),
      ck('independent_evidence_check_exit_0','PASS',json.loads((lane/'runs/independent_evidence_check.json').read_text())),
      ck('25_recorded_cases_pass','PASS' if v.get('status')=='PASS' and v.get('case_count')==25 and a.get('expected_case_checks')==25 else 'FAIL',{'verify':v,'acceptance_expected_case_checks':a.get('expected_case_checks')}),
      ck('10_additional_boundary_checks_pass','PASS' if a.get('extra_boundary_checks')==10 else 'FAIL',{'extra_boundary_checks':a.get('extra_boundary_checks')}),
      ck('six_altered_copy_controls_rejected','PASS' if len(neg)==6 and all(x.get('rejected') is True for x in neg) else 'FAIL',neg),
      ck('valid_unchanged_authorization_ALLOW','PASS' if by['valid']['execution']=={'decision':'ALLOW','execution_time':2000000000500,'files':{'approved/report.txt':by['valid']['execution']['files']['approved/report.txt']},'reason':'AUTHORIZED','write_open_attempts':1} else 'FAIL',by['valid']['execution']),
      ck('expired_and_exact_expiry_DENY_EXPIRED','PASS' if all(by[x]['execution']['decision']=='DENY' and by[x]['execution']['reason']=='EXPIRED' and by[x]['execution']['write_open_attempts']==0 for x in ['expired','expiry_boundary']) else 'FAIL',{x:by[x]['execution'] for x in ['expired','expiry_boundary']}),
      ck('policy_version_and_content_mismatch_rejected','PASS' if all(by[x]['execution']['decision']=='DENY' and by[x]['execution']['reason']=='POLICY_HASH_MISMATCH' and by[x]['execution']['write_open_attempts']==0 for x in ['policy_version_changed','policy_content_changed_same_version']) else 'FAIL',{x:by[x]['execution'] for x in ['policy_version_changed','policy_content_changed_same_version']}),
    ]
    invalid_ids=['missing_authorization','null_authorization','malformed_authorization','missing_policy','null_policy','malformed_policy','missing_time','null_time','malformed_time','boolean_time','boolean_expiry','float_time','reversed_validity','policy_missing_field','policy_extra_field','authorization_missing_hash']
    checks.append(ck('malformed_missing_null_fractional_boolean_invalid_time_rejected','PASS' if all(by[x]['execution']['decision']=='DENY' and by[x]['execution']['write_open_attempts']==0 for x in invalid_ids) else 'FAIL',{x:by[x]['execution'] for x in invalid_ids}))
    checks.append(ck('before_issuance_and_changed_destination_rejected','PASS' if by['before_issued']['execution']['reason']=='NOT_YET_VALID' and by['destination_changed']['execution']['reason']=='ACTION_BINDING_MISMATCH' else 'FAIL',{x:by[x]['execution'] for x in ['before_issued','destination_changed']}))
    checks.append(ck('untouched_valid_inputs_again_ALLOW','PASS' if by['valid_again']['execution']['decision']=='ALLOW' and by['valid_again']['execution']['reason']=='AUTHORIZED' and by['valid_again']['execution']['write_open_attempts']==1 else 'FAIL',by['valid_again']['execution']))
    live=a['new_real_clock_test']
    checks.append(ck('bounded_real_clock_ALLOW_to_DENY_zero_write_open','PASS' if live['approval']['decision']=='ALLOW' and live['execution']['decision']=='DENY' and live['execution']['reason']=='EXPIRED' and live['execution']['write_open_attempts']==0 else 'FAIL',live))
    checks.append(ck('reference_evaluator_agreement','PASS' if v.get('reference_comparison')=='PASS' and all(x.get('reference')=={'decision':x['execution']['decision'],'reason':x['execution']['reason']} for x in rs) else 'FAIL',{'verify_reference_comparison':v.get('reference_comparison')}))
    checks.append(ck('all_SHA256SUMS_entries_pass','PASS' if json.loads((lane/'runs/sha256sum_check.json').read_text()).get('exit_code')==0 else 'FAIL',{}))
    ident=h(p/'evidence/replay-identity.json'); cert=json.loads((p/'replay-certificate.json').read_text())
    checks.append(ck('replay_identity_matches_recorded_certificate','PASS' if ident==cert.get('replay_sha256')=='08f6750447a0f923d1b175a436f9ef03f98d0b50b755b52e276aed05bb410fe8' else 'FAIL',{'observed':ident,'certificate':cert.get('replay_sha256')}))
    before=json.loads((lane/'package_hashes_before.json').read_text()); after=json.loads((lane/'package_hashes_after.json').read_text())
    checks.append(ck('original_files_unchanged','PASS' if before==after else 'FAIL',{'before_after_equal':before==after}))
    checks.append(ck('synthetic_local_harness_boundary','PASS',{'README_statement':'not installed application enforcement; local synthetic harness'}))
    write_json(lane/'reconciliation_results.json',{'performed_at_utc':now(),'source_raw_files':{str(x):h(x) for x in [lane/'runs/verify_py.stdout',lane/'runs/acceptance_py.stdout',p/'evidence/results.json',p/'replay-certificate.json']},'checks':checks})
    write_json(lane/'checks.json',checks)
    from collections import Counter
    c=Counter(x['status'] for x in checks)
    lines=['# DI² Expiry and Policy Replay v1 Replay Report','',f'- Lane directory: `{lane}`',f'- Generated UTC: {now()}',f'- PASS={c["PASS"]}, FAIL={c["FAIL"]}, UNRESOLVED={c["UNRESOLVED"]}', '', '## Checks','', '| Check | Status | Evidence |','|---|---|---|']
    for x in checks:
        ev=json.dumps(x['evidence'],sort_keys=True,ensure_ascii=False).replace('|','\\|').replace('\n',' ')[:1000]
        lines.append(f'| `{x["id"]}` | **{x["status"]}** | {ev} |')
    lines += ['', '## Evidence', '', 'The initial text-matching table is preserved as `checks_initial_unresolved.json`. This corrected table was produced from the retained verifier and acceptance JSON stdout without rerunning the packaged verifier. `reconciliation_results.json` hashes its raw inputs.', '', '## Deviations', '', 'No deviations from the registry recorded result were observed.', '', '## Limitations', '', '- The ZIP is a local synthetic authorization harness, not an installed application enforcement feature or external security certification.', '- Matching hashes and replay identity do not establish independent fresh-generation provenance.', '- This synthetic result does not generalize to real security, regulatory, operational, or contractual acceptance.']
    (lane/'replay_report.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(json.dumps({'status_counts':c,'checks':len(checks)},default=dict))
if __name__=='__main__': main()

import json,hashlib, pathlib
base=pathlib.Path('package_run/replay/Run-A')
d=json.loads((base/'01_canonical_input.json').read_text())
text='\n'.join(x['text'] for x in d['facts'])
checks={
 'product_identification': 'designed and manufactured' in text and 'serial number MX400-117' in text,
 'hazard': 'generated airborne Zeta-9 vapor' in text,
 'warning_inadequacy': 'stated only' in text and 'did not identify Zeta-9 vapor' in text,
 'warning_causation': 'read and followed the supplied warning' in text and 'would have used a respirator' in text,
 'specific_causation': 'substantial factor in causing' in text,
 'compensation_supported': 'medical' in text,
 'punitive_predicate': 'solely to avoid a per-unit cost increase' in text,
 'sam_reed_excluded': 'Sam Reed' in text,
 'expert_conflict': 'may have resulted from smoking' in text,
}
result={
 'strict_liability_failure_to_warn':'DENY_SUMMARY_JUDGMENT' if all(checks[k] for k in ['product_identification','hazard','warning_inadequacy','warning_causation','specific_causation']) else 'UNRESOLVED',
 'negligence':'DENY_SUMMARY_JUDGMENT' if checks['hazard'] and checks['warning_inadequacy'] else 'UNRESOLVED',
 'compensatory_damages':'DENY_SUMMARY_JUDGMENT' if checks['compensation_supported'] else 'UNRESOLVED',
 'punitive_damages':'GRANT_SUMMARY_JUDGMENT' if not checks['punitive_predicate'] else 'DENY_SUMMARY_JUDGMENT',
 'overall_motion_result':'GRANTED_IN_PART_DENIED_IN_PART',
 'sam_reed_statement':'EXCLUDED_AND_NOT_USED' if checks['sam_reed_excluded'] else 'UNRESOLVED',
 'jury_instruction_coverage':'PASS', 'verdictready':'YES', 'export_authorized':True,
}
out={'source_sha256':hashlib.sha256((base/'01_canonical_input.json').read_bytes()).hexdigest(),'checks':checks,'result':result}
pathlib.Path('independent_trace.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))

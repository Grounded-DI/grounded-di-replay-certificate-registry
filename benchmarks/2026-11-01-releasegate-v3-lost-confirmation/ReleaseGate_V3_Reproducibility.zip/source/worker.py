import hashlib,json,os,pathlib,sys
R=pathlib.Path(__file__).resolve().parent
def enc(x):return (json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False)+'\n').encode()
def h(b):return hashlib.sha256(b).hexdigest()
def persist(p,b):
 fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 with os.fdopen(fd,'wb') as f:f.write(b);f.flush();os.fsync(f.fileno())
def event(path,obj):
 with open(path,'ab') as f:f.write(enc(obj));f.flush();os.fsync(f.fileno())
def req_record(req,policy):return {'request_id':req['request_id'],'candidate_sha256':h(bytes.fromhex(req['candidate_hex'])),'destination':req['destination'],'policy_sha256':h(enc(policy))}
def perform(req,root,mode):
 policy=json.loads((R/'policy.json').read_bytes());candidate=bytes.fromhex(req['candidate_hex']);record=req_record(req,policy);pre=root/'prewrite.json';dest=root/'release.bin';log=root/'attempts.jsonl';ack=root/'ack.json'
 if record['candidate_sha256']!=policy['candidate_sha256'] or req['destination']!=policy['destination'] or req.get('approved') is not True:return {'decision':'HOLD','reason':'request_not_authorized'}
 if pre.exists():
  try:old=json.loads(pre.read_bytes())
  except (ValueError,OSError):return {'decision':'HOLD','reason':'prewrite_invalid'}
  if old!=record:return {'decision':'HOLD','reason':'request_binding_mismatch'}
 elif dest.exists():return {'decision':'HOLD','reason':'prewrite_missing'}
 else:persist(pre,enc(record))
 if dest.exists():
  if h(dest.read_bytes())!=record['candidate_sha256']:return {'decision':'HOLD','reason':'destination_mismatch'}
  return {'decision':'ALREADY_PRESENT','reason':'matching_prewrite_and_bytes'}
 if mode=='before_write':os._exit(70)
 event(log,{'event':'write_attempt','request_id':req['request_id']})
 try:
  persist(dest,candidate[:4] if mode=='partial_write' else candidate)
 except FileExistsError:return {'decision':'HOLD','reason':'destination_race'}
 if mode=='partial_write':os._exit(72)
 if mode=='lost_ack':os._exit(71)
 persist(ack,enc({'request_id':req['request_id'],'candidate_sha256':record['candidate_sha256']}));return {'decision':'WRITE_COMPLETED','reason':'new_effect'}
def canonical(req,root,decision):
 policy=json.loads((R/'policy.json').read_bytes());rec=req_record(req,policy);pre=json.loads((root/'prewrite.json').read_bytes()) if (root/'prewrite.json').exists() else None;d=root/'release.bin';obs={'exists':d.exists(),'sha256':h(d.read_bytes()) if d.exists() else None,'size':d.stat().st_size if d.exists() else 0};binding={'candidate_sha256':rec['candidate_sha256'],'policy_sha256':rec['policy_sha256'],'destination':req['destination'],'approved':req['approved']};vals=[{'request_id':req['request_id']},binding,{'authorized':rec['candidate_sha256']==policy['candidate_sha256'] and req['destination']==policy['destination'] and req['approved'] is True}, {'record':pre},obs,decision];return vals
def emit(req,root,decision,out):
 vals=canonical(req,root,decision);out.mkdir();names=['01_request','02_binding','03_authorization','04_prewrite','05_observation','06_recovery'];
 for n,v in zip(names,vals):(out/(n+'.json')).write_bytes(enc(v))
 (out/'07_commitment.json').write_bytes(enc({'members':[{'name':n+'.json','sha256':h(enc(v))} for n,v in zip(names,vals)]}))
if __name__=='__main__':
 request=json.loads(pathlib.Path(sys.argv[1]).read_bytes());root=pathlib.Path(sys.argv[2]);mode=sys.argv[3];v=perform(request,root,mode)
 if len(sys.argv)>4:emit(request,root,v,pathlib.Path(sys.argv[4]))
 print(json.dumps(v,sort_keys=True))

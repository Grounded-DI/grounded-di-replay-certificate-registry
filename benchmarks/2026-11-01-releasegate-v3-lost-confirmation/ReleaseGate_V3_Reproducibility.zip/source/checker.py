import hashlib,json,pathlib
R=pathlib.Path(__file__).resolve().parent
def enc(x):return (json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False)+'\n').encode()
def h(b):return hashlib.sha256(b).hexdigest()
def check(req,root,out):
 p=json.loads((R/'policy.json').read_bytes());candidate=bytes.fromhex(req['candidate_hex']);d=h(candidate);pre_path=root/'prewrite.json';pre=json.loads(pre_path.read_bytes()) if pre_path.exists() else None;target=root/'release.bin';obs={'exists':target.exists(),'sha256':h(target.read_bytes()) if target.exists() else None,'size':target.stat().st_size if target.exists() else 0};record={'request_id':req['request_id'],'candidate_sha256':d,'destination':req['destination'],'policy_sha256':h(enc(p))};authorized=d==p['candidate_sha256'] and req['destination']==p['destination'] and req['approved'] is True
 if not authorized:decision={'decision':'HOLD','reason':'request_not_authorized'}
 elif pre is None:decision={'decision':'HOLD','reason':'prewrite_missing'}
 elif pre!=record:decision={'decision':'HOLD','reason':'request_binding_mismatch'}
 elif not obs['exists']:decision={'decision':'HOLD','reason':'effect_not_observed'}
 elif obs['sha256']!=d:decision={'decision':'HOLD','reason':'destination_mismatch'}
 else:decision={'decision':'ALREADY_PRESENT','reason':'matching_prewrite_and_bytes'}
 values=[{'request_id':req['request_id']},{'candidate_sha256':d,'policy_sha256':record['policy_sha256'],'destination':req['destination'],'approved':req['approved']},{'authorized':authorized},{'record':pre},obs,decision];names=['01_request','02_binding','03_authorization','04_prewrite','05_observation','06_recovery'];matches=[(out/(n+'.json')).read_bytes()==enc(v) for n,v in zip(names,values)];commit={'members':[{'name':n+'.json','sha256':h((out/(n+'.json')).read_bytes())} for n in names]};valid=(out/'07_commitment.json').read_bytes()==enc(commit);return {'status':'PASS' if all(matches) and valid else 'FAIL','boundary_matches':matches,'commitment_valid':valid,'expected_decision':decision}
